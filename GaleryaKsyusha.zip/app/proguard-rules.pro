# Правила по умолчанию (proguard-android-optimize.txt) + consumer-правила библиотек покрывают Compose, Coil и ML Kit.
-dontwarn org.slf4j.**
