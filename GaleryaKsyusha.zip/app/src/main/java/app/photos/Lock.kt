package app.photos

import androidx.activity.compose.BackHandler
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

fun bioAvailable(act: FragmentActivity) =
    BiometricManager.from(act).canAuthenticate(BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

fun askBio(act: FragmentActivity, title: String, onOk: () -> Unit, onFail: () -> Unit) {
    val info = BiometricPrompt.PromptInfo.Builder().setTitle(title)
        .setNegativeButtonText("Пароль").setAllowedAuthenticators(BIOMETRIC_WEAK).build()
    BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onFail() }
    }).authenticate(info)
}

/** Задать / сменить / убрать защиту. Пароль и биометрию можно включить вместе. */
@Composable
fun SetupForm(act: FragmentActivity, st: Store, onDone: () -> Unit) {
    val c = LocalNt.current
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf(st.bio) }
    var err by remember { mutableStateOf("") }
    val canBio = remember { bioAvailable(act) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Cap(if (st.hasPin) "Новый пароль (пусто — оставить прежний)" else "Пароль (от 4 символов)")
        NtField(p1, { p1 = it }, "••••", Modifier.fillMaxWidth(), password = true, keyboard = KeyboardType.NumberPassword)
        NtField(p2, { p2 = it }, "Повторите", Modifier.fillMaxWidth(), password = true, keyboard = KeyboardType.NumberPassword)
        if (canBio) Pill(if (bio) "Биометрия: вкл" else "Биометрия: выкл", { bio = !bio }, filled = bio)
        if (err.isNotEmpty()) Text(err, color = c.red, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Сохранить", {
                when {
                    p1.isNotEmpty() && p1.length < 4 -> err = "Минимум 4 символа"
                    p1 != p2 -> err = "Пароли не совпадают"
                    p1.isEmpty() && !st.hasPin && !(bio && canBio) -> err = "Введите пароль или включите биометрию"
                    else -> {
                        if (p1.isNotEmpty()) st.setPin(p1)
                        st.bio = bio && canBio
                        st.skipLock = false
                        onDone()
                    }
                }
            }, filled = true)
            if (st.locked) Pill("Убрать защиту", { st.clearPin(); st.bio = false; st.skipLock = true; onDone() })
        }
    }
}

@Composable
fun ProtectDialog(act: FragmentActivity, st: Store, onClose: () -> Unit) {
    val c = LocalNt.current
    AlertDialog(
        onDismissRequest = onClose, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
        confirmButton = { Pill("Закрыть", onClose) },
        title = { DotText("Защита", size = 20.sp) },
        text = { SetupForm(act, st, onClose) }
    )
}

/** Полноэкранный замок для сейфа и корзины. */
@Composable
fun LockGate(act: FragmentActivity, st: Store, title: String, onOk: () -> Unit, onCancel: () -> Unit) {
    val c = LocalNt.current
    BackHandler(onBack = onCancel)
    // Первый вход: предлагаем настроить защиту (можно пропустить).
    var setup by remember { mutableStateOf(!st.locked) }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val canBio = remember { bioAvailable(act) }
    fun bio() { askBio(act, title, onOk, {}) }
    LaunchedEffect(Unit) { if (!setup && st.bio && canBio) bio() }

    Column(
        Modifier.fillMaxSize().background(c.bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .statusBarsPadding().padding(28.dp),
        Arrangement.Center
    ) {
        RedDot(size = 12.dp)
        Spacer(Modifier.height(14.dp))
        DotText(title, size = 40.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            if (setup) "Закройте это место паролем или биометрией. Можно пропустить, но тогда любой с телефоном его откроет."
            else "Введите пароль" + if (st.bio && canBio) " или приложите палец" else "",
            color = c.dim
        )
        Spacer(Modifier.height(20.dp))
        if (setup) {
            SetupForm(act, st) { onOk() }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Пропустить", { st.skipLock = true; onOk() })
                Pill("Назад", onCancel)
            }
        } else {
            if (st.hasPin) NtField(
                pin, { pin = it; err = "" }, "Пароль", Modifier.fillMaxWidth(), password = true,
                keyboard = KeyboardType.NumberPassword, ime = ImeAction.Done,
                onAction = { if (st.checkPin(pin)) onOk() else { err = "Неверный пароль"; pin = "" } }
            )
            if (err.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(err, color = c.red, fontSize = 13.sp) }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (st.hasPin) Pill("Открыть", { if (st.checkPin(pin)) onOk() else { err = "Неверный пароль"; pin = "" } }, filled = true)
                if (st.bio && canBio) Pill("Биометрия", { bio() }, filled = !st.hasPin)
                Pill("Назад", onCancel)
            }
        }
    }
}
