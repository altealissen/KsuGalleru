package app.photos

import java.time.LocalDate
import java.time.ZoneId

/** Ответ Ксюши: текст, найденные снимки и (опционально) команда приложению. */
class Reply(val text: String, val items: List<Item> = emptyList(), val action: String? = null)

class Found(val items: List<Item>, val note: String)

/**
 * «Мозг» Ксюши. Работает целиком на телефоне: разбор русской речи правилами + метки ML Kit.
 * Ни одного сетевого запроса — в манифесте даже нет разрешения INTERNET, так что фото физически не могут уйти.
 */
object Brain {
    private val concepts: List<Pair<List<String>, List<String>>> = listOf(
        listOf("кот", "кош", "мяу") to listOf("cat", "kitten", "feline"),
        listOf("собак", "пес", "щен") to listOf("dog", "puppy", "canine"),
        listOf("еда", "еды", "еду", "блюд", "пицц", "торт", "десерт", "кофе", "завтрак", "обед", "ужин", "вкусн") to
            listOf("food", "dish", "cuisine", "meal", "pizza", "cake", "dessert", "coffee", "fruit", "drink"),
        listOf("пляж", "мор", "океан", "волн") to listOf("beach", "sea", "ocean", "coast", "wave", "shore", "sand"),
        listOf("гор", "холм") to listOf("mountain", "hill", "alps"),
        listOf("неб", "закат", "рассвет", "облак") to listOf("sky", "sunset", "cloud", "sunrise", "dusk"),
        listOf("цвет", "роз", "букет") to listOf("flower", "plant", "petal", "rose", "bouquet"),
        listOf("машин", "авто", "тачк") to listOf("car", "vehicle", "automotive", "wheel", "truck"),
        listOf("человек", "люд", "селфи", "лиц", "улыб", "друз", "девуш", "парн") to
            listOf("person", "face", "smile", "selfie", "people", "human", "head"),
        listOf("дерев", "лес", "природ", "парк", "трав") to listOf("tree", "forest", "nature", "plant", "grass", "woodland", "park"),
        listOf("снег", "зим", "сугроб") to listOf("snow", "winter", "ice", "frost"),
        listOf("ноч", "звезд") to listOf("night", "star", "moon", "darkness"),
        listOf("город", "здани", "дом", "архитект", "улиц") to listOf("building", "city", "skyscraper", "architecture", "street", "house", "urban"),
        listOf("вод", "озер", "рек", "фонтан") to listOf("water", "lake", "river", "pond", "fountain"),
        listOf("птиц", "голуб", "утк") to listOf("bird", "pigeon", "duck", "beak"),
        listOf("лошад", "конь") to listOf("horse"),
        listOf("велосипед", "велик") to listOf("bicycle", "bike"),
        listOf("документ", "чек", "текст", "бумаг", "скан") to listOf("text", "document", "paper", "font", "receipt"),
        listOf("ребен", "дет", "малыш") to listOf("child", "baby", "toddler", "kid"),
        listOf("самолет", "аэропорт") to listOf("airplane", "aircraft", "airport"),
        listOf("концерт", "сцен") to listOf("concert", "stage", "performance", "crowd"),
        listOf("спорт", "футбол", "мяч") to listOf("sports", "football", "ball")
    )

    private val monthRx = listOf(
        Regex("январ"), Regex("феврал"), Regex("март"), Regex("апрел"), Regex("\\bма[йяе]\\b"), Regex("июн"),
        Regex("июл"), Regex("август"), Regex("сентябр"), Regex("октябр"), Regex("ноябр"), Regex("декабр")
    )
    private val monthNames = listOf("январь", "февраль", "март", "апрель", "май", "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь")

    private val stop = setOf(
        "найди", "найти", "покажи", "показать", "мне", "все", "всё", "где", "есть", "у", "меня", "за", "на", "в", "во", "с", "со",
        "и", "а", "по", "про", "о", "об", "от", "до", "из", "что", "какие", "какой", "моих", "мои", "мой", "ксюша", "пожалуйста",
        "плиз", "можешь", "хочу", "только", "этого", "этот", "эта", "последние", "недавние", "там", "где-то", "было", "были", "снятые", "сделанные"
    )
    private val dateWordPrefixes = listOf("сегодн", "вчера", "недел", "месяц", "год", "прошл", "этом", "этой", "этого")

    fun norm(q: String) = q.lowercase().replace('ё', 'е')

    private fun tokens(q: String) = Regex("[\\p{L}\\p{N}]+").findAll(q).map { it.value }.toList()

    private fun zone() = ZoneId.systemDefault()
    private fun ms(d: LocalDate) = d.atStartOfDay(zone()).toInstant().toEpochMilli()

    private fun dateRange(q: String, now: LocalDate): Pair<LocalDate, LocalDate>? {
        val year = Regex("\\b(19|20)\\d{2}\\b").find(q)?.value?.toInt()
        val month = monthRx.indexOfFirst { it.containsMatchIn(q) }
        return when {
            q.contains("сегодня") -> now to now
            q.contains("вчера") -> now.minusDays(1) to now.minusDays(1)
            month >= 0 -> {
                val y = year ?: if (month + 1 > now.monthValue) now.year - 1 else now.year
                val s = LocalDate.of(y, month + 1, 1)
                s to s.plusMonths(1).minusDays(1)
            }
            q.contains("недел") -> now.minusDays(6) to now
            q.contains("месяц") ->
                if (q.contains("прошл")) { val s = now.withDayOfMonth(1).minusMonths(1); s to s.plusMonths(1).minusDays(1) }
                else now.withDayOfMonth(1) to now
            year != null -> LocalDate.of(year, 1, 1) to LocalDate.of(year, 12, 31)
            Regex("\\bгод(а|у|ом)?\\b").containsMatchIn(q) ->
                if (q.contains("прошл")) LocalDate.of(now.year - 1, 1, 1) to LocalDate.of(now.year - 1, 12, 31)
                else LocalDate.of(now.year, 1, 1) to now
            else -> null
        }
    }

    private fun conceptFor(t: String): List<String>? =
        concepts.mapNotNull { (stems, syn) ->
            stems.filter { t.startsWith(it) }.maxOfOrNull { it.length }?.let { it to syn }
        }.maxByOrNull { it.first }?.second

    /** Понимает запросы вида «видео с морем за прошлый месяц», «скриншоты 2024», «избранное с едой». */
    fun search(st: Store, q0: String, items: List<Item>, favs: Set<Long>): Found {
        val q = norm(q0)
        val toks = tokens(q)
        var video: Boolean? = null
        var photoOnly = false
        var shots = false
        var fav = false
        val groups = ArrayList<List<String>>()
        val raw = ArrayList<String>()
        for (t in toks) {
            when {
                t.startsWith("видео") || t.startsWith("ролик") || t.startsWith("клип") -> video = true
                t.startsWith("скрин") -> shots = true
                t.startsWith("фото") || t.startsWith("фотк") || t.startsWith("снимк") || t.startsWith("картин") -> photoOnly = true
                t.startsWith("избран") || t.startsWith("любим") -> fav = true
                t in stop || t.length < 2 -> {}
                t.matches(Regex("\\d{4}")) || monthRx.any { it.containsMatchIn(t) } -> {}
                dateWordPrefixes.any { t.startsWith(it) } -> {}
                else -> conceptFor(t)?.let { groups += it } ?: run { raw += t }
            }
        }
        if (photoOnly && video != true) video = false
        val range = dateRange(q, LocalDate.now())
        val from = range?.let { ms(it.first) }
        val to = range?.let { ms(it.second.plusDays(1)) }

        val scored = ArrayList<Pair<Item, Int>>()
        for (m in items) {
            if (video != null && video != m.video) continue
            if (shots && !(m.album.contains("screenshot", true) || m.album.contains("скрин", true) ||
                    m.album.contains("снимки экрана", true) || m.name.startsWith("Screenshot", true))) continue
            if (fav && m.id !in favs) continue
            if (from != null && m.ms < from) continue
            if (to != null && m.ms >= to) continue
            if (groups.isEmpty() && raw.isEmpty()) { scored += m to 1; continue }
            val hay = st.hay(m)
            val rawHit = raw.count { hay.contains(it) }
            if (groups.isNotEmpty()) {
                val hit = groups.count { g -> g.any { hay.contains(it) } }
                if (hit < groups.size) continue
                scored += m to (hit * 10 + rawHit)
            } else if (rawHit > 0) scored += m to rawHit
        }
        scored.sortWith(compareByDescending<Pair<Item, Int>> { it.second }.thenByDescending { it.first.ms })

        val parts = ArrayList<String>()
        if (video == true) parts += "видео" else if (video == false) parts += "фото"
        if (shots) parts += "скриншоты"
        if (fav) parts += "избранное"
        if (range != null) {
            val (a, b) = range
            parts += if (a == b) a.toString() else "$a — $b"
        }
        if (groups.isNotEmpty() || raw.isNotEmpty()) parts += "про: " + (raw + groups.map { it.first() }).joinToString(", ")
        return Found(scored.map { it.first }, parts.joinToString(" · ").ifBlank { "всё подряд" })
    }

    private fun has(q: String, vararg s: String) = s.any { q.contains(it) }

    fun greeting(): String = listOf(
        "Привет! Я Ксюша ✦ Живу прямо в твоём телефоне и ничего не отправляю в интернет. Что поищем?",
        "Хей! Ксюша на связи (≧◡≦) Спрашивай про свои фото — найду, посчитаю, подскажу.",
        "Приветик ✦ Я твой оффлайн-помощник по галерее. Попробуй: «найди котиков» или «видео за прошлый месяц»."
    ).random()

    fun answer(st: Store, q0: String, items: List<Item>, favs: Set<Long>): Reply {
        val q = norm(q0)
        val photos = items.count { !it.video }
        val videos = items.size - photos
        val pending = items.count { !it.video && st.label(it.id) == null }
        val shots = items.filter { it.album.contains("screenshot", true) || it.album.contains("скрин", true) }

        return when {
            has(q, "привет", "здравств", "хай", "добрый", "хеллоу") -> Reply(greeting())
            has(q, "кто ты", "как тебя зовут", "ты кто", "как тебя") ->
                Reply("Я Ксюша ✦ ассистент этой галереи. Живу на устройстве: распознаю снимки офлайн и понимаю запросы по-русски.")
            has(q, "спасибо", "спс", "благодар") -> Reply("Всегда пожалуйста (´▽`ʃ♡ƪ)")
            has(q, "что умеешь", "помощ", "помоги", "команд", "help", "умеешь") -> Reply(
                "Вот что я умею ✦\n• искать: «найди собак», «видео за март», «скриншоты 2024»\n" +
                    "• считать: «сколько у меня видео?»\n• «в этот день», «дубликаты», «большие видео»\n" +
                    "• советовать по чистке памяти\n• после кнопки «Анализ» понимаю, что на снимках (офлайн)."
            )
            has(q, "интернет", "конфиденц", "приват", "безопас", "отправля", "облак", "утечк") -> Reply(
                "Всё остаётся на телефоне ✦ В приложении нет разрешения INTERNET — снимки физически не могут уйти. " +
                    "Распознавание делает ML Kit офлайн, а я работаю на правилах прямо в приложении. Сейф и корзину можно закрыть паролем или биометрией."
            )
            has(q, "сколько") -> {
                val t = when {
                    has(q, "видео") -> "Видео у тебя $videos."
                    has(q, "скрин") -> "Скриншотов ${shots.size}."
                    has(q, "избран") -> "В избранном ${favs.size}."
                    has(q, "альбом") -> "Альбомов ${items.map { it.album }.toSet().size}."
                    else -> "Всего ${items.size}: фото $photos и видео $videos."
                }
                Reply(t)
            }
            has(q, "самое старое", "самый старый", "самое первое", "первое фото") -> {
                val o = items.lastOrNull()
                if (o == null) Reply("Пока пусто (・_・)") else Reply("Самый старый кадр — ${fmt("d MMMM yyyy", o.ms)} ✦", listOf(o))
            }
            has(q, "дубл", "одинаков", "повтор") -> {
                val d = Smart.duplicates(items)
                if (d.isEmpty()) Reply("Дублей не вижу — чисто ✦") else Reply("Нашла ${d.size} похожих файлов (одинаковый размер и разрешение). Проверь и убери лишние:", d)
            }
            has(q, "больш") && has(q, "видео", "файл") -> {
                val b = Smart.bigVideos(items)
                if (b.isEmpty()) Reply("Тяжёлых видео (больше 200 МБ) нет ✦")
                else Reply("Тяжёлых видео ${b.size}, вместе ${b.sumOf { it.size } / 1_000_000} МБ. Вот они:", b)
            }
            has(q, "в этот день", "воспомин", "лет назад", "годы назад") -> {
                val t = Smart.onThisDay(items)
                if (t.isEmpty()) Reply("В этот день в прошлые годы снимков нет (・_・)") else Reply("В этот день в прошлом ты снимал(а) вот это ✦", t)
            }
            has(q, "чист", "освобод", "место", "мусор") -> {
                val big = Smart.bigVideos(items)
                Reply(
                    "Что можно почистить ✦\n• скриншотов: ${shots.size}\n• тяжёлых видео: ${big.size} (${big.sumOf { it.size } / 1_000_000} МБ)\n" +
                        "• похожих файлов: ${Smart.duplicates(items).size}\nСкажи «скриншоты» или «дубликаты» — покажу и помогу убрать в корзину."
                )
            }
            has(q, "проанализ", "анализ", "распозн") ->
                if (pending == 0) Reply("Я уже всё рассмотрела ✦ Меток хватает для поиска.")
                else Reply("Начинаю смотреть фото ($pending шт.) — это идёт на устройстве, прогресс сверху ✦", action = "index")
            else -> {
                val f = search(st, q0, items, favs)
                when {
                    f.items.isNotEmpty() -> Reply("Нашла ${f.items.size} ✦ (${f.note})", f.items)
                    pending > 0 -> Reply("Пока ничего (>_<) Я посмотрела не все фото — скажи «анализ», и я лучше пойму, что на снимках.")
                    else -> Reply("Ничего не нашла по запросу (${f.note}) (>_<) Попробуй другими словами или спроси «что умеешь».")
                }
            }
        }
    }
}
