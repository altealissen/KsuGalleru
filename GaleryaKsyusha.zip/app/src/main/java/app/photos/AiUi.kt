@file:OptIn(ExperimentalLayoutApi::class)

package app.photos

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

/** Состояние фоновой индексации живёт на уровне приложения: переключение вкладок её не прерывает. */
class IdxState {
    var running by mutableStateOf(false)
    var done by mutableIntStateOf(0)
    var total by mutableIntStateOf(0)
    var job: Job? = null
}

class Msg(val me: Boolean, val text: String, val items: List<Item> = emptyList())

/** Текстовое поле в стиле Nothing: скруглённая «таблетка» без рамки. */
@Composable
fun NtField(
    value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier,
    singleLine: Boolean = true, password: Boolean = false, keyboard: KeyboardType = KeyboardType.Text,
    ime: ImeAction = ImeAction.Default, onAction: () -> Unit = {}
) {
    val c = LocalNt.current
    BasicTextField(
        value, onChange,
        modifier = modifier.clip(RoundedCornerShape(24.dp)).background(c.surface).padding(horizontal = 16.dp, vertical = 12.dp),
        textStyle = TextStyle(color = c.text, fontSize = 15.sp),
        singleLine = singleLine,
        maxLines = if (singleLine) 1 else 4,
        cursorBrush = SolidColor(c.red),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard, imeAction = ime),
        keyboardActions = KeyboardActions(onSearch = { onAction() }, onSend = { onAction() }, onDone = { onAction() }),
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) Text(placeholder, color = c.dim, fontSize = 15.sp, maxLines = 1)
                inner()
            }
        }
    )
}

// ───────────────────────────── Ксюша ─────────────────────────────

/** Аватар: моргает, «дышит» и шевелит ртом, пока говорит. Три кадра — векторные рисунки в res/drawable. */
@Composable
fun KsyushaAvatar(size: Dp, modifier: Modifier = Modifier, talking: Boolean = false) {
    var blink by remember { mutableStateOf(false) }
    var mouth by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) { delay(Random.nextLong(2200, 4800)); blink = true; delay(130); blink = false }
    }
    LaunchedEffect(talking) {
        while (talking) { mouth = !mouth; delay(150) }
        mouth = false
    }
    val t by rememberInfiniteTransition(label = "breath").animateFloat(
        0f, 1f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b"
    )
    val sizePx = with(LocalDensity.current) { size.toPx() }
    val res = when {
        talking && mouth -> R.drawable.ksyusha_talk
        blink -> R.drawable.ksyusha_blink
        else -> R.drawable.ksyusha_open
    }
    Image(
        painterResource(res), null,
        modifier.size(size).graphicsLayer { translationY = -t * sizePx * 0.025f; rotationZ = (t - 0.5f) * 2f }.clip(CircleShape),
        contentScale = ContentScale.Crop
    )
}

// ───────────────────────────── ИИ по одному фото ─────────────────────────────

@Composable
fun KsyushaDialog(m: Item, st: Store, onClose: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val c = LocalNt.current
    var labels by remember { mutableStateOf<String?>(null) }
    var note by remember { mutableStateOf(st.note(m.id) ?: "") }
    var saved by remember { mutableStateOf(false) }
    LaunchedEffect(m.id) { labels = Vision.labels(ctx, st, m) }

    AlertDialog(
        onDismissRequest = onClose, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
        confirmButton = { Pill("Закрыть", onClose, filled = true) },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                KsyushaAvatar(40.dp)
                Spacer(Modifier.width(10.dp))
                DotText("Ксюша", size = 20.sp)
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Cap("Что вижу (на устройстве)")
                when {
                    m.video -> Text("С видео я пока не дружу — ищи его по дате и названию.", color = c.text)
                    labels == null -> DotProgress()
                    labels!!.isBlank() -> Text("Ничего уверенно не распознала (・_・)", color = c.text)
                    else -> Text(labels!!, color = c.text)
                }
                Cap("Моя заметка — по ней фото найдётся в поиске")
                NtField(note, { note = it; saved = false }, "Например: день рождения Маши", Modifier.fillMaxWidth(), singleLine = false)
                Pill(if (saved) "Сохранено" else "Сохранить", { st.setNote(m.id, note.trim().take(300)); saved = true }, enabled = !saved && note.isNotBlank())
            }
        }
    )
}

// ───────────────────────────── поиск ─────────────────────────────

@Composable
fun SearchTab(st: Store, items: List<Item>, favs: Set<Long>, h: Host) {
    val c = LocalNt.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var res by remember { mutableStateOf<List<Item>?>(null) }
    var note by remember { mutableStateOf("") }
    val examples = listOf("Видео за прошлый месяц", "Скриншоты этого года", "Избранное с едой", "Фото с животными")

    fun go(query: String) {
        if (query.isBlank()) return
        busy = true
        scope.launch {
            try {
                val f = withContext(Dispatchers.Default) { Brain.search(st, query, items, favs) }
                res = f.items; note = f.note
            } finally { busy = false }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            NtField(q, { q = it }, "Кот, видео за март, скриншоты 2024…", Modifier.weight(1f), ime = ImeAction.Search, onAction = { go(q) })
        }
        if (busy) DotProgress(Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        if (note.isNotEmpty() && res != null) Text(
            "Поняла так: $note", Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            color = c.dim, fontFamily = Mono, fontSize = 11.sp, maxLines = 2
        )
        val r = res
        if (r == null) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                DotText("Поиск", size = 30.sp)
                Spacer(Modifier.height(8.dp))
                Text("Ищите по названию, альбому, меткам и заметкам. Даты, «видео», «скриншоты», «избранное» я пойму сама — всё на устройстве.", color = c.dim)
                Spacer(Modifier.height(20.dp))
                Cap("Попробуйте")
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    examples.forEach { e -> Pill(e, { q = e; go(e) }) }
                }
            }
        } else {
            if (r.isNotEmpty()) Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("В избранное", { h.fav(r) })
                Pill("В сейф", { h.vault(r, true) })
                Pill("В корзину", { h.trash(r, true) })
            }
            GridScreen("Найдено", r, favs, "normal", h)
        }
    }
}

// ───────────────────────────── вкладка Ксюши ─────────────────────────────

@Composable
fun AiTab(
    st: Store, items: List<Item>, favs: Set<Long>, h: Host,
    msgs: SnapshotStateList<Msg>, idx: IdxState, onIndex: () -> Unit, onStopIndex: () -> Unit
) {
    val c = LocalNt.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    val pending = remember(items, idx.running) { items.count { !it.video && st.label(it.id) == null } }

    fun send(t: String) {
        if (busy || t.isBlank()) return
        msgs += Msg(true, t)
        busy = true
        job = scope.launch {
            try {
                msgs += Msg(false, "")
                val at = msgs.lastIndex
                delay(300)
                val r = withContext(Dispatchers.Default) { Brain.answer(st, t, items, favs) }
                if (r.action == "index") onIndex()
                var n = 0
                while (n < r.text.length) {
                    n = (n + 2).coerceAtMost(r.text.length)
                    msgs[at] = Msg(false, r.text.take(n))
                    delay(14)
                }
                msgs[at] = Msg(false, r.text, r.items)
            } catch (e: CancellationException) {
                throw e
            } finally { busy = false }
        }
    }

    val presets = listOf(
        "Что умеешь?", "Найди котиков", "Скриншоты", "Видео за прошлый месяц", "Дубликаты",
        "В этот день", "Сколько у меня фото?", "Как почистить память?", "Конфиденциально?"
    )

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            KsyushaAvatar(56.dp, talking = busy)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                DotText("Ксюша", size = 26.sp)
                Cap("оффлайн · фото не уходят из телефона")
            }
            if (!idx.running && pending > 0) Pill("Анализ", onIndex, filled = true)
        }
        if (idx.running) Column(Modifier.padding(bottom = 8.dp)) {
            DotProgress(fraction = if (idx.total == 0) 0f else idx.done.toFloat() / idx.total)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Cap("Смотрю фото ${idx.done} / ${idx.total}", Modifier.weight(1f))
                Pill("Стоп", onStopIndex)
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (msgs.isNotEmpty()) item { Pill("Очистить", { job?.cancel(); msgs.clear() }) }
            items(presets) { p -> Pill(p, { send(p) }, enabled = !busy) }
        }

        val ls = rememberLazyListState()
        LaunchedEffect(msgs.size, msgs.lastOrNull()?.text?.length) {
            if (msgs.isNotEmpty()) ls.animateScrollToItem(msgs.lastIndex)
        }
        if (msgs.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                DotGrid(Modifier.fillMaxSize())
                Column(Modifier.align(Alignment.Center).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    KsyushaAvatar(150.dp, talking = busy)
                    Spacer(Modifier.height(14.dp))
                    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(c.surface).padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text(
                            "Привет, я Ксюша ✦ Найду фото по словам, посчитаю и подскажу, что почистить. Всё считаю прямо на телефоне.",
                            color = c.text, fontSize = 14.sp
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), state = ls,
                verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 14.dp)
            ) {
                items(msgs.size) { i ->
                    val m = msgs[i]
                    // Каждое сообщение мягко «въезжает» снизу.
                    val a = remember { Animatable(0f) }
                    LaunchedEffect(Unit) { a.animateTo(1f, tween(260)) }
                    Box(Modifier.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 24f }) {
                        if (m.me) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Box(Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(20.dp)).background(c.red).padding(horizontal = 14.dp, vertical = 10.dp)) {
                                Text(m.text, color = Color.White)
                            }
                        } else Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                            KsyushaAvatar(30.dp, Modifier.padding(top = 2.dp, end = 10.dp))
                            Column(Modifier.weight(1f)) {
                                if (m.text.isEmpty()) DotProgress(Modifier.padding(top = 10.dp, end = 80.dp))
                                else Box(Modifier.clip(RoundedCornerShape(20.dp)).background(c.surface).padding(horizontal = 14.dp, vertical = 10.dp)) {
                                    SelectionContainer { Text(m.text, color = c.text) }
                                }
                                if (m.items.isNotEmpty()) {
                                    Spacer(Modifier.height(8.dp))
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        itemsIndexed(m.items.take(24), key = { _, x -> x.id }) { k, x ->
                                            Thumb(x, Modifier.size(84.dp).clip(RoundedCornerShape(14.dp)).clickable { h.open(m.items, k) }, 240)
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        item { Pill("Открыть все ${m.items.size}", { h.open(m.items, 0) }, filled = true) }
                                        item { Pill("В избранное", { h.fav(m.items) }) }
                                        item { Pill("В сейф", { h.vault(m.items, true) }) }
                                        item { Pill("В корзину", { h.trash(m.items, true) }) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            NtField(
                input, { input = it }, "Спросите Ксюшу", Modifier.weight(1f), singleLine = false,
                ime = ImeAction.Send, onAction = { if (input.isNotBlank()) { send(input.trim()); input = "" } }
            )
            Spacer(Modifier.width(8.dp))
            if (busy) Pill("Стоп", { job?.cancel() })
            else Box(
                Modifier.size(48.dp).clip(CircleShape).background(c.red)
                    .clickable { if (input.isNotBlank()) { send(input.trim()); input = "" } },
                Alignment.Center
            ) { Icon(Icons.Default.Send, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
        }
    }
}
