package app.photos

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text

/** Точечный шрифт, сгенерированный для проекта (латиница + кириллица). Лучше смотрится от 15sp. */
val Dot = FontFamily(Font(R.font.dot_matrix))
val Mono = FontFamily.Monospace

/** Палитра в духе Nothing OS: чистый чёрный/белый, серые поверхности и один красный акцент. */
class Nt(val dark: Boolean) {
    val red = Color(0xFFD71921)
    val bg = if (dark) Color(0xFF000000) else Color(0xFFFFFFFF)
    val surface = if (dark) Color(0xFF161616) else Color(0xFFF1F1F1)
    val surface2 = if (dark) Color(0xFF242424) else Color(0xFFE3E3E3)
    val text = if (dark) Color(0xFFFFFFFF) else Color(0xFF000000)
    val dim = if (dark) Color(0xFF8C8C8C) else Color(0xFF6B6B6B)
    val line = if (dark) Color(0xFF2E2E2E) else Color(0xFFD4D4D4)
}

val LocalNt = staticCompositionLocalOf { Nt(true) }

@Composable
fun NothingTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val c = remember(dark) { Nt(dark) }
    val scheme = if (dark) darkColorScheme(
        primary = c.red, onPrimary = Color.White,
        primaryContainer = c.surface2, onPrimaryContainer = c.text,
        secondary = c.red, onSecondary = Color.White,
        secondaryContainer = c.surface2, onSecondaryContainer = c.text,
        background = c.bg, onBackground = c.text,
        surface = c.surface, onSurface = c.text,
        surfaceVariant = c.surface2, onSurfaceVariant = c.dim,
        outline = c.line, outlineVariant = c.line, error = c.red
    ) else lightColorScheme(
        primary = c.red, onPrimary = Color.White,
        primaryContainer = c.surface2, onPrimaryContainer = c.text,
        secondary = c.red, onSecondary = Color.White,
        secondaryContainer = c.surface2, onSecondaryContainer = c.text,
        background = c.bg, onBackground = c.text,
        surface = c.surface, onSurface = c.text,
        surfaceVariant = c.surface2, onSurfaceVariant = c.dim,
        outline = c.line, outlineVariant = c.line, error = c.red
    )
    val typo = remember {
        Typography(
            displayLarge = TextStyle(fontFamily = Dot, fontSize = 48.sp, lineHeight = 56.sp),
            headlineLarge = TextStyle(fontFamily = Dot, fontSize = 32.sp, lineHeight = 40.sp),
            headlineMedium = TextStyle(fontFamily = Dot, fontSize = 28.sp, lineHeight = 36.sp),
            headlineSmall = TextStyle(fontFamily = Dot, fontSize = 22.sp, lineHeight = 30.sp, letterSpacing = 0.5.sp),
            titleLarge = TextStyle(fontFamily = Dot, fontSize = 20.sp, lineHeight = 28.sp),
            titleMedium = TextStyle(fontFamily = Mono, fontSize = 14.sp, lineHeight = 20.sp),
            bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
            bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
            labelLarge = TextStyle(fontFamily = Mono, fontSize = 12.sp, letterSpacing = 1.sp),
            labelMedium = TextStyle(fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp),
            labelSmall = TextStyle(fontFamily = Mono, fontSize = 10.sp, letterSpacing = 1.sp)
        )
    }
    CompositionLocalProvider(LocalNt provides c) {
        MaterialTheme(colorScheme = scheme, typography = typo, content = content)
    }
}

/** Заголовок точечным шрифтом (всегда капсом: в шрифте только заглавные формы). */
@Composable
fun DotText(text: String, modifier: Modifier = Modifier, size: TextUnit = 28.sp, color: Color = LocalNt.current.text) {
    Text(text.uppercase(), modifier, color = color, fontFamily = Dot, fontSize = size, letterSpacing = 1.sp, maxLines = 1)
}

/** Мелкая моно-подпись капсом. */
@Composable
fun Cap(text: String, modifier: Modifier = Modifier, color: Color = LocalNt.current.dim, size: TextUnit = 11.sp) {
    Text(text.uppercase(), modifier, color = color, fontFamily = Mono, fontSize = size, letterSpacing = 1.2.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
}

/** Клик с «пружинкой»: элемент слегка сжимается под пальцем и мягко возвращается. */
fun Modifier.bounceClick(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed && enabled) 0.93f else 1f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "bounce"
    )
    this.graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

/** Кнопка-«таблетка». filled = красная заливка, иначе контур. */
@Composable
fun Pill(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    filled: Boolean = false, enabled: Boolean = true
) {
    val c = LocalNt.current
    val base = modifier.bounceClick(enabled, onClick).clip(CircleShape)
    val styled = if (filled) base.background(if (enabled) c.red else c.surface2)
    else base.border(1.dp, c.line, CircleShape)
    Box(styled.padding(horizontal = 16.dp, vertical = 10.dp), Alignment.Center) {
        Text(
            text.uppercase(), maxLines = 1,
            color = if (filled) Color.White else if (enabled) c.text else c.dim,
            fontFamily = Mono, fontSize = 12.sp, letterSpacing = 1.sp
        )
    }
}

/** Точечная сетка в стиле Nothing — фон для пустых экранов. */
@Composable
fun DotGrid(modifier: Modifier = Modifier, step: Dp = 14.dp) {
    val c = LocalNt.current
    Canvas(modifier) {
        val s = step.toPx()
        val r = 1.1.dp.toPx()
        var y = s / 2
        while (y < size.height) {
            var x = s / 2
            while (x < size.width) { drawCircle(c.line, r, Offset(x, y)); x += s }
            y += s
        }
    }
}

/** Индикатор из точек: бегущая волна, а при заданной fraction — заполнение слева направо. */
@Composable
fun DotProgress(modifier: Modifier = Modifier, fraction: Float? = null) {
    val c = LocalNt.current
    val t by rememberInfiniteTransition(label = "dots").animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "t"
    )
    Canvas(modifier.fillMaxWidth().height(12.dp)) {
        val n = 28
        val step = size.width / n
        val r = minOf(step * 0.2f, size.height / 2f)
        for (i in 0 until n) {
            val on = if (fraction != null) i < fraction * n
            else ((i.toFloat() / n) - t + 1f) % 1f < 0.22f
            drawCircle(if (on) c.red else c.line, r, Offset(step * (i + 0.5f), size.height / 2f))
        }
    }
}

@Composable
fun Hairline(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(LocalNt.current.line))
}

/** Красная точка — фирменный маркер. */
@Composable
fun RedDot(modifier: Modifier = Modifier, size: Dp = 6.dp) {
    Box(modifier.size(size).clip(CircleShape).background(LocalNt.current.red))
}
