@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package app.photos

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NothingTheme {
                Surface(Modifier.fillMaxSize(), color = LocalNt.current.bg) { App(this) }
            }
        }
    }
}

class Host(
    val open: (List<Item>, Int) -> Unit, val fav: (List<Item>) -> Unit,
    val trash: (List<Item>, Boolean) -> Unit, val purge: (List<Item>) -> Unit,
    val vault: (List<Item>, Boolean) -> Unit, val wipe: (List<Item>) -> Unit,
    val share: (List<Item>) -> Unit
)

class Aset(val key: String, val name: String, val items: List<Item>) {
    val mode: String get() = when (key) { "vault" -> "vault"; "trash" -> "trash"; else -> "normal" }
    val secret: Boolean get() = key == "vault" || key == "trash"
}

fun perms(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

fun hasPerm(c: Context) = perms().all { ContextCompat.checkSelfPermission(c, it) == android.content.pm.PackageManager.PERMISSION_GRANTED }

fun dur(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

fun sizeText(b: Long): String = if (b >= 1_000_000) "%.1f МБ".format(b / 1e6) else "${b / 1024} КБ"

fun shareItems(ctx: Context, l: List<Item>) {
    val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
        type = "*/*"
        putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(l.map { it.uri }))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, null))
}

@Composable
fun PermissionScreen(onAsk: () -> Unit) {
    val c = LocalNt.current
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.Start) {
        KsyushaAvatar(120.dp)
        Spacer(Modifier.height(20.dp))
        DotText("Привет", size = 44.sp)
        Spacer(Modifier.height(12.dp))
        Text("Я Ксюша ✦ Мне нужен доступ к фото и видео, чтобы показать галерею. Всё остаётся на телефоне: в приложении даже нет доступа в интернет.", color = c.dim)
        Spacer(Modifier.height(24.dp))
        Pill("Разрешить доступ", onAsk, filled = true)
    }
}

@Composable
fun App(act: FragmentActivity) {
    val st = remember { Store(act) }
    val c = LocalNt.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(hasPerm(act)) }
    val permL = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasPerm(act) }
    LaunchedEffect(Unit) { if (!granted) permL.launch(perms()) }
    if (!granted) { PermissionScreen { permL.launch(perms()) }; return }

    var all by remember { mutableStateOf(listOf<Item>()) }
    var trash by remember { mutableStateOf(listOf<Item>()) }
    var vault by remember { mutableStateOf(listOf<Item>()) }
    var loaded by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var ver by remember { mutableIntStateOf(0) }
    fun reload() {
        if (loading) return
        loading = true
        scope.launch {
            try {
                val r = withContext(Dispatchers.IO) {
                    coroutineScope {
                        val a = async { Media.load(act) }
                        val t = async { Media.load(act, true) }
                        val v = async { Vault.load(act) }
                        Triple(a.await(), t.await(), v.await())
                    }
                }
                all = r.first; trash = r.second; vault = r.third; loaded = true; ver++
            } finally { loading = false }
        }
    }

    var tab by remember { mutableIntStateOf(0) }
    var album by remember { mutableStateOf<String?>(null) }
    var unlocked by remember { mutableStateOf(false) }
    var gate by remember { mutableStateOf<String?>(null) }
    var protect by remember { mutableStateOf(false) }
    var wipeAsk by remember { mutableStateOf<List<Item>?>(null) }
    var viewer by remember { mutableStateOf<Pair<List<Item>, Int>?>(null) }
    val sysWait = remember { booleanArrayOf(false) }

    // Обновляем при возвращении в приложение; при уходе в фон закрываем сейф и корзину.
    DisposableEffect(act) {
        val o = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) reload()
            if (e == Lifecycle.Event.ON_STOP && !sysWait[0]) {
                unlocked = false
                if (album == "vault" || album == "trash") { album = null; viewer = null }
            }
        }
        act.lifecycle.addObserver(o)
        onDispose { act.lifecycle.removeObserver(o) }
    }
    val sender = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { sysWait[0] = false; reload() }
    fun sys(p: PendingIntent) { sysWait[0] = true; sender.launch(IntentSenderRequest.Builder(p.intentSender).build()) }
    fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    val favs = remember(ver) { st.ids("fav") }
    val chat = remember { mutableStateListOf<Msg>() }
    val idx = remember { IdxState() }

    fun startIndex() {
        if (idx.running) return
        val snapshot = all
        idx.running = true; idx.done = 0; idx.total = 0
        idx.job = scope.launch {
            try { Vision.index(act, st, snapshot) { a, b -> idx.done = a; idx.total = b } }
            catch (e: CancellationException) { }
            finally { idx.running = false; ver++ }
        }
    }

    val host = Host(
        open = { l, i -> viewer = l to i },
        fav = { l -> val on = l.any { it.id !in favs }; st.toggleAll("fav", l.map { it.id }, on); ver++ },
        trash = { l, t -> sys(MediaStore.createTrashRequest(act.contentResolver, l.map { it.uri }, t)) },
        purge = { l -> sys(MediaStore.createDeleteRequest(act.contentResolver, l.map { it.uri })) },
        vault = { l, into ->
            scope.launch {
                if (into) {
                    val done = Vault.add(act, l.filter { it.file == null })
                    if (done.isEmpty()) toast("Не удалось перенести в сейф")
                    else { toast("В сейфе: ${done.size}. Подтвердите удаление оригиналов"); sys(MediaStore.createDeleteRequest(act.contentResolver, done.map { it.uri })) }
                } else toast("Возвращено: ${Vault.restore(act, l)}")
                reload()
            }
        },
        wipe = { l -> wipeAsk = l },
        share = { l -> shareItems(act, l) }
    )

    fun openAlbum(k: String) {
        if (st.locked && !unlocked) gate = k
        else if (!st.locked && !st.skipLock) gate = k   // первый вход: предложим настроить защиту
        else album = k
    }

    BackHandler(viewer != null || album != null) { if (viewer != null) viewer = null else album = null }

    val sets = remember(all, favs, trash, vault) {
        val base = listOf(
            Aset("fav", "Избранное", all.filter { it.id in favs }),
            Aset("video", "Видео", all.filter { it.video }),
            Aset("today", "В этот день", Smart.onThisDay(all)),
            Aset("shots", "Скриншоты", all.filter { it.album.contains("Screenshot", true) }),
            Aset("big", "Большие видео", Smart.bigVideos(all)),
            Aset("dups", "Дубликаты", Smart.duplicates(all))
        ).filter { it.items.isNotEmpty() || it.key in setOf("fav", "video", "shots") }
        base + Aset("vault", "Сейф", vault) + Aset("trash", "Корзина", trash) +
            all.groupBy { it.album }.map { Aset("b:" + it.key, it.key, it.value) }
    }

    val inPrivate = tab == 1 && (album == "vault" || album == "trash")
    DisposableEffect(inPrivate) {
        // В сейфе и корзине запрещаем скриншоты и превью в списке недавних.
        if (inPrivate) act.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { act.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    val imeOpen = WindowInsets.isImeVisible
    val lastViewer = remember { arrayOfNulls<Pair<List<Item>, Int>>(1) }
    if (viewer != null) lastViewer[0] = viewer
    val lastGate = remember { arrayOfNulls<String>(1) }
    if (gate != null) lastGate[0] = gate

    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = c.bg, bottomBar = {
            if (!imeOpen) NtBar(tab) { tab = it; album = null }
        }) { pad ->
            Box(Modifier.padding(pad).consumeWindowInsets(pad).imePadding()) {
                if (!loaded) {
                    Box(Modifier.fillMaxSize().padding(48.dp), Alignment.Center) { DotProgress() }
                } else AnimatedContent(
                    targetState = tab to album,
                    transitionSpec = {
                        val fwd = targetState.first > initialState.first ||
                            (targetState.first == initialState.first && targetState.second != null)
                        (fadeIn(tween(240)) + slideInHorizontally(tween(280)) { w -> if (fwd) w / 10 else -w / 10 }) togetherWith fadeOut(tween(120))
                    },
                    label = "screen"
                ) { (t, a) ->
                    when (t) {
                        0 -> GridScreen("Фото", all, favs, "normal", host)
                        1 -> {
                            val cur = sets.firstOrNull { it.key == a }
                            if (cur == null) AlbumsScreen(sets, host, { openAlbum(it) }, {
                                if (!st.locked || unlocked) protect = true else gate = "protect"
                            }) else GridScreen(cur.name, cur.items, favs, cur.mode, host) { album = null }
                        }
                        2 -> SearchTab(st, all, favs, host)
                        else -> AiTab(st, all, favs, host, chat, idx, { startIndex() }, { idx.job?.cancel() })
                    }
                }
            }
        }
        AnimatedVisibility(
            viewer != null,
            enter = fadeIn(tween(200)) + scaleIn(tween(240), initialScale = 0.9f),
            exit = fadeOut(tween(160)) + scaleOut(tween(180), targetScale = 0.95f)
        ) {
            lastViewer[0]?.let { (l, i) ->
                val mode = when { tab == 1 && album == "trash" -> "trash"; tab == 1 && album == "vault" -> "vault"; else -> "normal" }
                Viewer(l, i, favs, mode, st, host) { viewer = null }
            }
        }
        AnimatedVisibility(gate != null, enter = fadeIn(tween(180)), exit = fadeOut(tween(140))) {
            val k = lastGate[0] ?: ""
            LockGate(act, st, if (k == "trash") "Корзина" else if (k == "vault") "Сейф" else "Защита", {
                unlocked = true; gate = null
                if (k == "protect") protect = true else album = k
            }, { gate = null })
        }
    }
    if (protect) ProtectDialog(act, st) { protect = false }
    wipeAsk?.let { l ->
        AlertDialog(
            onDismissRequest = { wipeAsk = null }, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
            title = { DotText("Удалить?", size = 20.sp) },
            text = { Text("Файлов: ${l.size}. Они будут стёрты из сейфа безвозвратно.", color = c.text) },
            confirmButton = {
                Pill("Удалить", { scope.launch { Vault.remove(act, l); viewer = null; reload() }; wipeAsk = null }, filled = true)
            },
            dismissButton = { Pill("Отмена", { wipeAsk = null }) }
        )
    }
}

@Composable
fun NtBar(tab: Int, onTab: (Int) -> Unit) {
    val c = LocalNt.current
    val names = listOf("Фото", "Альбомы", "Поиск", "Ксюша")
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(c.surface).padding(4.dp)) {
            names.forEachIndexed { i, n ->
                val sel = tab == i
                val bg by animateColorAsState(if (sel) c.bg else Color.Transparent, tween(220), label = "nb")
                val fg by animateColorAsState(if (sel) c.text else c.dim, tween(220), label = "nf")
                val dot by animateDpAsState(if (sel) 6.dp else 0.dp, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow), label = "nd")
                Row(
                    Modifier.weight(1f).height(48.dp).bounceClick { onTab(i) }.clip(CircleShape).background(bg),
                    Arrangement.Center, Alignment.CenterVertically
                ) {
                    Box(Modifier.size(dot).clip(CircleShape).background(c.red))
                    if (dot > 0.dp) Spacer(Modifier.width(6.dp))
                    DotText(n, size = 13.sp, color = fg)
                }
            }
        }
    }
}

@Composable
fun AlbumsScreen(sets: List<Aset>, h: Host, onOpen: (String) -> Unit, onProtect: () -> Unit) {
    val c = LocalNt.current
    var menu by remember { mutableStateOf<Aset?>(null) }
    LazyVerticalGrid(
        GridCells.Fixed(2), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.padding(start = 8.dp, top = 16.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    DotText("Альбомы", size = 30.sp)
                    Spacer(Modifier.height(4.dp))
                    Cap("${sets.size} коллекций · удерживайте, чтобы удалить")
                }
                Pill("Защита", onProtect)
            }
        }
        items(sets, key = { it.key }) { s ->
            val src = remember { MutableInteractionSource() }
            val pressed by src.collectIsPressedAsState()
            val sc by animateFloatAsState(if (pressed) 0.95f else 1f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "tile")
            val empty = s.items.isEmpty() || s.secret
            Box(
                Modifier.animateItemPlacement().graphicsLayer { scaleX = sc; scaleY = sc }
                    .aspectRatio(1f).clip(RoundedCornerShape(24.dp)).background(c.surface)
                    .combinedClickable(
                        interactionSource = src, indication = null,
                        onClick = { onOpen(s.key) },
                        onLongClick = { if (s.key.startsWith("b:")) menu = s }
                    )
            ) {
                if (!empty) {
                    Thumb(s.items[0], Modifier.fillMaxSize(), 400)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .78f)))))
                }
                if (s.secret) Icon(Icons.Default.Lock, null, tint = c.red, modifier = Modifier.align(Alignment.TopStart).padding(14.dp).size(22.dp))
                Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
                    if (!s.secret) DotText("${s.items.size}", size = 22.sp, color = if (empty) c.text else Color.White)
                    Spacer(Modifier.height(2.dp))
                    Cap(s.name, color = if (empty) c.dim else Color.White.copy(alpha = .85f))
                }
            }
        }
    }
    menu?.let { s ->
        AlertDialog(
            onDismissRequest = { menu = null }, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
            title = { DotText(s.name, size = 20.sp) },
            text = { Text("Папка «${s.name}»: ${s.items.size} шт. В корзину они уйдут вместе с папкой (30 дней можно вернуть).", color = c.text) },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill("В сейф", { h.vault(s.items, true); menu = null })
                    Pill("В корзину", { h.trash(s.items, true); menu = null }, filled = true)
                }
            },
            dismissButton = { Pill("Отмена", { menu = null }) }
        )
    }
}

@Composable
fun Thumb(m: Item, modifier: Modifier = Modifier, px: Int = 300, scale: ContentScale = ContentScale.Crop) {
    val ctx = LocalContext.current
    val c = LocalNt.current
    // Сначала смотрим в кэш синхронно — при скролле назад превью появляются мгновенно.
    val bmp by produceState<Bitmap?>(ThumbCache.peek(m, px), m.id, px) {
        value = ThumbCache.peek(m, px) ?: ThumbCache.get(ctx, m, px) ?: value
    }
    val img = remember(bmp) { bmp?.asImageBitmap() }
    val a by animateFloatAsState(if (img != null) 1f else 0f, tween(200), label = "thumb")
    Box(modifier.background(c.surface2)) {
        img?.let { Image(it, null, Modifier.fillMaxSize().graphicsLayer { alpha = a }, contentScale = scale) }
    }
}

@Composable
fun GridScreen(title: String, items: List<Item>, favs: Set<Long>, mode: String, h: Host, onBack: (() -> Unit)? = null) {
    val c = LocalNt.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val gs = rememberLazyGridState()
    var sel by remember { mutableStateOf(setOf<Long>()) }
    var cols by remember { mutableIntStateOf(3) }
    val groups = remember(items) { items.groupBy { it.day } }
    val idx = remember(items) { items.withIndex().associate { it.value.id to it.index } }
    val itemsNow by rememberUpdatedState(items)
    val idxNow by rememberUpdatedState(idx)
    val chosen = remember(sel, items) { items.filter { it.id in sel } }
    val px = when (cols) { 2 -> 540; 3 -> 360; else -> 240 }

    // Убираем из выделения то, чего уже нет (например, после удаления).
    LaunchedEffect(items) {
        if (sel.isNotEmpty()) { val ids = items.mapTo(HashSet()) { it.id }; sel = sel.filterTo(HashSet()) { it in ids } }
    }
    BackHandler(sel.isNotEmpty()) { sel = emptySet() }

    fun hit(p: Offset): Long? {
        for (i in gs.layoutInfo.visibleItemsInfo) {
            val k = i.key as? Long ?: continue
            if (p.x >= i.offset.x && p.x < i.offset.x + i.size.width && p.y >= i.offset.y && p.y < i.offset.y + i.size.height) return k
        }
        return null
    }

    Column(Modifier.fillMaxSize()) {
        AnimatedContent(sel.isNotEmpty(), transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(100)) }, label = "bar") { selecting ->
            Row(
                Modifier.fillMaxWidth().height(68.dp).padding(start = if (onBack != null || selecting) 4.dp else 20.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (selecting) IconButton({ sel = emptySet() }) { Icon(Icons.Default.Close, null, tint = c.text) }
                else if (onBack != null) IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = c.text) }
                Column(Modifier.weight(1f)) {
                    if (!selecting) {
                        DotText(title, size = 26.sp)
                        Cap("${items.size} шт.")
                    } else {
                        DotText("%02d".format(sel.size), size = 26.sp, color = c.red)
                        Cap("выбрано · проведите по фото")
                    }
                }
                if (!selecting) {
                    if (mode == "trash" && items.isNotEmpty()) Pill("Очистить", { h.purge(items) })
                    else Pill("$cols×", { cols = when (cols) { 2 -> 3; 3 -> 5; else -> 2 } })
                } else when (mode) {
                    "trash" -> {
                        IconButton({ h.trash(chosen, false); sel = emptySet() }) { Icon(Icons.Default.Refresh, null, tint = c.text) }
                        IconButton({ h.purge(chosen); sel = emptySet() }) { Icon(Icons.Default.Delete, null, tint = c.red) }
                    }
                    "vault" -> {
                        IconButton({ h.share(chosen) }) { Icon(Icons.Default.Share, null, tint = c.text) }
                        IconButton({ h.vault(chosen, false); sel = emptySet() }) { Icon(Icons.Default.Refresh, null, tint = c.text) }
                        IconButton({ h.wipe(chosen); sel = emptySet() }) { Icon(Icons.Default.Delete, null, tint = c.red) }
                    }
                    else -> {
                        IconButton({ h.fav(chosen); sel = emptySet() }) { Icon(Icons.Default.Favorite, null, tint = c.text) }
                        IconButton({ h.share(chosen) }) { Icon(Icons.Default.Share, null, tint = c.text) }
                        IconButton({ h.vault(chosen, true); sel = emptySet() }) { Icon(Icons.Default.Lock, null, tint = c.text) }
                        IconButton({ h.trash(chosen, true); sel = emptySet() }) { Icon(Icons.Default.Delete, null, tint = c.red) }
                    }
                }
            }
        }
        if (items.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { DotText("Пусто", size = 24.sp, color = c.dim) }
        else LazyVerticalGrid(
            GridCells.Fixed(cols),
            Modifier.fillMaxSize().pointerInput(Unit) {
                // Долгое нажатие + проведение пальцем = выделение диапазона (как в Google Фото). У краёв сетка сама прокручивается.
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    val slop = viewConfiguration.touchSlop
                    val ended = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                        var res = false
                        while (true) {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                            if (!ch.pressed || (ch.position - down.position).getDistance() > slop) { res = true; break }
                        }
                        res
                    }
                    if (ended != null) return@awaitEachGesture   // это тап или обычная прокрутка
                    val startKey = hit(down.position) ?: return@awaitEachGesture
                    val anchor = idxNow[startKey] ?: return@awaitEachGesture
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    val base = sel
                    var last = down.position
                    var speed = 0f
                    fun applySel(p: Offset) {
                        val k = hit(p) ?: return
                        val i = idxNow[k] ?: return
                        val lo = minOf(anchor, i)
                        val hi = maxOf(anchor, i)
                        sel = base + itemsNow.subList(lo, hi + 1).map { it.id }
                    }
                    applySel(last)
                    val scroller = scope.launch {
                        while (isActive) {
                            if (speed != 0f) { gs.scrollBy(speed); applySel(last) }
                            delay(16)
                        }
                    }
                    try {
                        val edge = 110.dp.toPx()
                        while (true) {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                            ch.consume()
                            if (!ch.pressed) break
                            last = ch.position
                            val hgt = size.height.toFloat()
                            speed = when {
                                last.y < edge -> -((edge - last.y) / edge) * 40f
                                last.y > hgt - edge -> ((last.y - (hgt - edge)) / edge) * 40f
                                else -> 0f
                            }
                            applySel(last)
                        }
                    } finally { scroller.cancel() }
                }
            },
            state = gs,
            contentPadding = PaddingValues(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            groups.forEach { (day, list) ->
                item(key = "h:$day", span = { GridItemSpan(maxLineSpan) }, contentType = "header") {
                    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 18.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RedDot(size = 6.dp)
                        Spacer(Modifier.width(10.dp))
                        Cap(day, color = c.text)
                    }
                }
                items(list, key = { it.id }, contentType = { "media" }) { m ->
                    val isSel = m.id in sel
                    val sc by animateFloatAsState(if (isSel) 0.82f else 1f, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow), label = "sel")
                    val r by animateDpAsState(if (isSel) 16.dp else 0.dp, tween(160), label = "r")
                    Box(
                        Modifier.aspectRatio(1f).animateItemPlacement().clickable(
                            interactionSource = remember { MutableInteractionSource() }, indication = null
                        ) {
                            if (sel.isNotEmpty()) sel = if (isSel) sel - m.id else sel + m.id
                            else h.open(items, idx[m.id] ?: 0)
                        }
                    ) {
                        Box(Modifier.fillMaxSize().graphicsLayer { scaleX = sc; scaleY = sc }.clip(RoundedCornerShape(r))) {
                            Thumb(m, Modifier.fillMaxSize(), px)
                            if (m.video) Box(
                                Modifier.align(Alignment.BottomEnd).padding(5.dp).clip(RoundedCornerShape(50))
                                    .background(Color.Black.copy(alpha = .6f)).padding(horizontal = 6.dp, vertical = 2.dp)
                            ) { Text(dur(m.dur), color = Color.White, fontFamily = Mono, fontSize = 10.sp) }
                            if (m.id in favs) RedDot(Modifier.align(Alignment.BottomStart).padding(7.dp), 6.dp)
                        }
                        AnimatedVisibility(
                            isSel, Modifier.align(Alignment.TopStart).padding(10.dp),
                            enter = scaleIn(spring(dampingRatio = 0.5f)) + fadeIn(), exit = scaleOut() + fadeOut()
                        ) {
                            Box(Modifier.size(22.dp).clip(CircleShape).background(c.red), Alignment.Center) {
                                Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Viewer(list: List<Item>, start: Int, favs: Set<Long>, mode: String, st: Store, h: Host, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val c = LocalNt.current
    val ps = rememberPagerState(start) { list.size }
    val m = list[ps.currentPage.coerceIn(0, list.size - 1)]
    var info by remember { mutableStateOf(false) }
    var ai by remember { mutableStateOf(false) }
    var chrome by remember { mutableStateOf(true) }

    // Просмотрщик всегда чёрный — значки статус-бара делаем светлыми, даже в светлой теме.
    DisposableEffect(Unit) {
        val ctl = (view.context as? Activity)?.window?.let { WindowCompat.getInsetsController(it, view) }
        val prevS = ctl?.isAppearanceLightStatusBars
        val prevN = ctl?.isAppearanceLightNavigationBars
        ctl?.isAppearanceLightStatusBars = false
        ctl?.isAppearanceLightNavigationBars = false
        onDispose {
            if (ctl != null) {
                prevS?.let { ctl.isAppearanceLightStatusBars = it }
                prevN?.let { ctl.isAppearanceLightNavigationBars = it }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(ps, Modifier.fillMaxSize(), pageSpacing = 12.dp, key = { list[it].id }) { p ->
            Page(list[p]) { chrome = !chrome }
        }
        AnimatedVisibility(chrome, Modifier.align(Alignment.TopStart), enter = fadeIn(), exit = fadeOut()) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .7f), Color.Transparent)))
                    .statusBarsPadding().padding(end = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClose) { Icon(Icons.Default.Close, null, tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Cap(fmt("d MMMM yyyy", m.ms), color = Color.White)
                    Cap(fmt("HH:mm", m.ms), color = Color.White.copy(alpha = .6f))
                }
                Cap("${ps.currentPage + 1} / ${list.size}", color = Color.White.copy(alpha = .6f))
            }
        }
        AnimatedVisibility(
            chrome, Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + scaleIn(initialScale = 0.9f), exit = fadeOut() + scaleOut(targetScale = 0.9f)
        ) {
            Row(
                Modifier.navigationBarsPadding().padding(bottom = 16.dp)
                    .clip(RoundedCornerShape(32.dp)).background(Color(0xE6161616)).padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val bs = Modifier.size(44.dp)
                when (mode) {
                    "trash" -> {
                        IconButton({ h.trash(listOf(m), false); onClose() }, bs) { Icon(Icons.Default.Refresh, null, tint = Color.White) }
                        IconButton({ h.purge(listOf(m)); onClose() }, bs) { Icon(Icons.Default.Delete, null, tint = c.red) }
                    }
                    "vault" -> {
                        IconButton({ h.share(listOf(m)) }, bs) { Icon(Icons.Default.Share, null, tint = Color.White) }
                        IconButton({ info = true }, bs) { Icon(Icons.Default.Info, null, tint = Color.White) }
                        IconButton({ h.vault(listOf(m), false); onClose() }, bs) { Icon(Icons.Default.Refresh, null, tint = Color.White) }
                        IconButton({ h.wipe(listOf(m)) }, bs) { Icon(Icons.Default.Delete, null, tint = c.red) }
                    }
                    else -> {
                        IconButton({ h.share(listOf(m)) }, bs) { Icon(Icons.Default.Share, null, tint = Color.White) }
                        IconButton({ h.fav(listOf(m)) }, bs) {
                            Icon(if (m.id in favs) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (m.id in favs) c.red else Color.White)
                        }
                        IconButton({ info = true }, bs) { Icon(Icons.Default.Info, null, tint = Color.White) }
                        IconButton({ ai = true }, bs) { KsyushaAvatar(30.dp) }
                        if (!m.video) IconButton({
                            runCatching {
                                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_EDIT).setDataAndType(m.uri, "image/*")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION), null))
                            }
                        }, bs) { Icon(Icons.Default.Edit, null, tint = Color.White) }
                        IconButton({ h.vault(listOf(m), true); onClose() }, bs) { Icon(Icons.Default.Lock, null, tint = Color.White) }
                        IconButton({ h.trash(listOf(m), true); onClose() }, bs) { Icon(Icons.Default.Delete, null, tint = Color.White) }
                    }
                }
            }
        }
    }
    if (info) InfoDialog(m, st) { info = false }
    if (ai) KsyushaDialog(m, st) { ai = false }
}

@Composable
fun InfoDialog(m: Item, st: Store, onClose: () -> Unit) {
    val c = LocalNt.current
    AlertDialog(
        onDismissRequest = onClose, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
        confirmButton = { Pill("Ок", onClose, filled = true) },
        title = { Text(m.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoRow("Дата", fmt("d MMMM yyyy HH:mm", m.ms))
                InfoRow("Размер", sizeText(m.size))
                InfoRow("Разрешение", "${m.w}×${m.h}")
                InfoRow("Альбом", m.album)
                InfoRow("Метки", st.label(m.id)?.ifBlank { "—" } ?: "не анализировано")
                st.note(m.id)?.let { InfoRow("Заметка", it) }
            }
        }
    )
}

@Composable
private fun InfoRow(k: String, v: String) {
    val c = LocalNt.current
    Column {
        Cap(k)
        Text(v, color = c.text, fontSize = 14.sp)
    }
}

/** Страница просмотра: щипок для зума, перетаскивание при увеличении, двойной тап — плавный зум. */
@Composable
fun Page(m: Item, onTap: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tap by rememberUpdatedState(onTap)
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onTap = { tap() }, onDoubleTap = {
                    scope.launch {
                        val from = scale
                        val fromOff = off
                        val target = if (from > 1.05f) 1f else 2.5f
                        animate(0f, 1f, animationSpec = tween(260)) { t, _ ->
                            scale = from + (target - from) * t
                            off = if (target == 1f) fromOff * (1f - t) else off
                        }
                    }
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        // Пока не увеличено и палец один — не трогаем жест, пусть листает пейджер.
                        if (scale > 1f || ev.changes.size > 1) {
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            val mx = size.width * (scale - 1f) / 2f
                            val my = size.height * (scale - 1f) / 2f
                            off = Offset((off.x + pan.x).coerceIn(-mx, mx), (off.y + pan.y).coerceIn(-my, my))
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            },
        Alignment.Center
    ) {
        if (m.video) {
            Thumb(m, Modifier.fillMaxSize(), 1024, ContentScale.Fit)
            Box(
                Modifier.size(76.dp).clip(CircleShape).background(LocalNt.current.red).bounceClick {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(m.uri, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }, Alignment.Center
            ) { Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(44.dp)) }
        } else AsyncImage(
            m.uri, null,
            Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y },
            contentScale = ContentScale.Fit
        )
    }
}
