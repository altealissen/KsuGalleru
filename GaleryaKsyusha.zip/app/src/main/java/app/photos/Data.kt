package app.photos

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.content.ContentValues
import android.media.ThumbnailUtils
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

// ───────────────────────────── даты ─────────────────────────────

private val formatters = ConcurrentHashMap<String, DateTimeFormatter>()

/** Потокобезопасный форматтер с кэшем: раньше SimpleDateFormat создавался на КАЖДОЕ фото. */
fun fmt(p: String, ms: Long): String {
    val loc = Locale.getDefault()
    val f = formatters.getOrPut(p + "|" + loc.toLanguageTag()) { DateTimeFormatter.ofPattern(p, loc) }
    return f.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))
}

data class Item(
    val id: Long, val uri: Uri, val name: String, val ms: Long, val video: Boolean,
    val size: Long, val w: Int, val h: Int, val album: String, val dur: Long,
    val file: File? = null   // не null только у файлов из сейфа (личное хранилище приложения)
) {
    /** Считается один раз при создании, а не при каждом обращении. */
    val day: String = fmt("d MMMM yyyy", ms)
}

// ───────────────────────────── медиатека ─────────────────────────────

object Media {
    fun load(ctx: Context, trashed: Boolean = false): List<Item> {
        val proj = arrayOf(
            MediaStore.Files.FileColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.MEDIA_TYPE, MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME, MediaStore.MediaColumns.DURATION
        )
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (1,3)")
            putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, if (trashed) MediaStore.MATCH_ONLY else MediaStore.MATCH_EXCLUDE)
        }
        val out = ArrayList<Item>()
        val c = runCatching {
            ctx.contentResolver.query(MediaStore.Files.getContentUri("external"), proj, args, null)
        }.getOrNull() ?: return out
        c.use {
            out.ensureCapacity(c.count)
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val vid = c.getInt(2) == 3
                val taken = c.getLong(3)
                val added = c.getLong(4) * 1000
                val base = if (vid) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                out += Item(
                    id, ContentUris.withAppendedId(base, id), c.getString(1) ?: "",
                    if (taken > 0) taken else added, vid, c.getLong(5), c.getInt(6), c.getInt(7),
                    c.getString(8) ?: "", c.getLong(9)
                )
            }
        }
        out.sortByDescending { it.ms }
        return out
    }
}

/** LRU-кэш превью + ограничение параллельных декодирований. Без него сетка перечитывала превью при каждом скролле. */
object ThumbCache {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 6).toInt().coerceAtMost(96 shl 20)
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val gate = Semaphore(4)

    fun peek(m: Item, px: Int): Bitmap? = cache.get("${m.id}:$px")

    suspend fun get(ctx: Context, m: Item, px: Int): Bitmap? {
        peek(m, px)?.let { return it }
        val b = gate.withPermit {
            withContext(Dispatchers.IO) {
                runCatching {
                    val f = m.file
                    when {
                        f == null -> ctx.contentResolver.loadThumbnail(m.uri, Size(px, px), null)
                        m.video -> ThumbnailUtils.createVideoThumbnail(f, Size(px, px), null)
                        else -> ThumbnailUtils.createImageThumbnail(f, Size(px, px), null)
                    }
                }.getOrNull()
            }
        } ?: return null
        cache.put("${m.id}:$px", b)
        return b
    }
}

// ───────────────────────────── хранилище ─────────────────────────────

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("gallery", Context.MODE_PRIVATE)
    /** Метки и заметки лежат в отдельном файле: основной больше не раздувается тысячами ключей. */
    private val lp = ctx.getSharedPreferences("labels", Context.MODE_PRIVATE)

    init {
        if (!p.getBoolean("mig1", false)) {
            val e = p.edit()
            val le = lp.edit()
            for ((k, v) in p.all) {
                if (k.length > 1 && k[0] == 'l' && k.substring(1).all { it.isDigit() } && v is String) {
                    le.putString(k, v); e.remove(k)
                }
            }
            le.apply()
            e.putBoolean("mig1", true).apply()
        }
    }

    fun ids(k: String): Set<Long> = (p.getStringSet(k, emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()

    fun toggle(k: String, id: Long, on: Boolean) = toggleAll(k, listOf(id), on)

    /** Одна запись на всю пачку, а не по одной на каждое фото. */
    fun toggleAll(k: String, ids: List<Long>, on: Boolean) {
        val s = (p.getStringSet(k, emptySet()) ?: emptySet()).toMutableSet()
        ids.forEach { if (on) s.add(it.toString()) else s.remove(it.toString()) }
        p.edit().putStringSet(k, s).apply()
    }

    // ── защита сейфа и корзины: пароль (хэш с солью) и/или биометрия ──
    private fun hash(salt: String, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }

    fun setPin(pin: String) {
        val salt = UUID.randomUUID().toString()
        p.edit().putString("salt", salt).putString("pin", hash(salt, pin)).apply()
    }
    fun clearPin() { p.edit().remove("salt").remove("pin").apply() }
    val hasPin: Boolean get() = !p.getString("pin", "").isNullOrEmpty()
    fun checkPin(pin: String): Boolean = hasPin && hash(p.getString("salt", "") ?: "", pin) == p.getString("pin", "")

    var bio: Boolean
        get() = p.getBoolean("bio", false)
        set(v) { p.edit().putBoolean("bio", v).apply() }

    /** Пользователь осознанно выбрал «без защиты». */
    var skipLock: Boolean
        get() = p.getBoolean("skip", false)
        set(v) { p.edit().putBoolean("skip", v).apply() }

    val locked: Boolean get() = hasPin || bio

    fun label(id: Long): String? = lp.getString("l$id", null)
    fun setLabel(id: Long, v: String) = setLabels(mapOf(id to v))
    fun setLabels(m: Map<Long, String>) {
        if (m.isEmpty()) return
        val e = lp.edit()
        m.forEach { (id, v) -> e.putString("l$id", v) }
        e.apply()
    }

    /** Заметка (например, подпись от Ксюши) — участвует в поиске. */
    fun note(id: Long): String? = lp.getString("n$id", null)
    fun setNote(id: Long, v: String) { lp.edit().putString("n$id", v).apply() }

    fun hay(m: Item): String = "${m.name} ${m.album} ${label(m.id).orEmpty()} ${note(m.id).orEmpty()}".lowercase()
}

// ───────────────────────────── локальная «умность» ─────────────────────────────

object Smart {
    /** Одинаковые размер в байтах + разрешение + длительность — почти наверняка копии. */
    fun duplicates(items: List<Item>): List<Item> =
        items.filter { it.size > 0 }
            .groupBy { Triple(it.size, it.w.toLong() * 100_000L + it.h, it.dur) }
            .values.filter { it.size > 1 }.flatten()
            .sortedWith(compareBy<Item> { it.size }.thenByDescending { it.ms })

    fun bigVideos(items: List<Item>, minBytes: Long = 200_000_000L): List<Item> =
        items.filter { it.video && it.size > minBytes }.sortedByDescending { it.size }

    /** Кадры, снятые в этот же день и месяц в прошлые годы. */
    fun onThisDay(items: List<Item>): List<Item> {
        val today = LocalDate.now()
        val zone = ZoneId.systemDefault()
        return items.filter {
            val d = Instant.ofEpochMilli(it.ms).atZone(zone).toLocalDate()
            d.monthValue == today.monthValue && d.dayOfMonth == today.dayOfMonth && d.year < today.year
        }
    }
}

// ───────────────────────────── сейф ─────────────────────────────

/** Секретная папка: файлы копируются в личное хранилище приложения (другие приложения и системная галерея их не видят). */
object Vault {
    const val AUTH = "app.photos.deepgallery.fp"
    private fun dir(ctx: Context) = File(ctx.filesDir, "vault").also { it.mkdirs() }
    private fun idxFile(ctx: Context) = File(dir(ctx), "index.json")
    private fun read(ctx: Context): JSONArray = runCatching { JSONArray(idxFile(ctx).readText()) }.getOrDefault(JSONArray())
    private fun write(ctx: Context, a: JSONArray) { idxFile(ctx).writeText(a.toString()) }

    fun load(ctx: Context): List<Item> {
        val a = read(ctx)
        val out = ArrayList<Item>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val f = File(dir(ctx), o.getString("f"))
            if (!f.exists()) continue
            out += Item(
                o.getLong("id"), FileProvider.getUriForFile(ctx, AUTH, f), o.getString("name"), o.getLong("ms"),
                o.getBoolean("v"), f.length(), o.getInt("w"), o.getInt("h"), "Сейф", o.getLong("d"), f
            )
        }
        out.sortByDescending { it.ms }
        return out
    }

    /** Копирует файлы в сейф и возвращает те, что скопировались успешно (оригиналы потом удаляются системным запросом). */
    suspend fun add(ctx: Context, items: List<Item>): List<Item> = withContext(Dispatchers.IO) {
        val a = read(ctx)
        val done = ArrayList<Item>()
        var seq = 0
        for (m in items) {
            val id = -(System.currentTimeMillis() * 100 + seq++)
            val ext = m.name.substringAfterLast('.', if (m.video) "mp4" else "jpg")
            val f = File(dir(ctx), "v${-id}.$ext")
            try {
                ctx.contentResolver.openInputStream(m.uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                a.put(JSONObject().put("id", id).put("f", f.name).put("name", m.name).put("ms", m.ms)
                    .put("v", m.video).put("w", m.w).put("h", m.h).put("d", m.dur))
                done += m
            } catch (e: Exception) { f.delete() }
        }
        write(ctx, a)
        done
    }

    private fun drop(ctx: Context, ids: Set<Long>) {
        val a = read(ctx)
        val keep = JSONArray()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getLong("id") in ids) File(dir(ctx), o.getString("f")).delete() else keep.put(o)
        }
        write(ctx, keep)
    }

    /** Окончательное удаление из сейфа. */
    suspend fun remove(ctx: Context, items: List<Item>) = withContext(Dispatchers.IO) { drop(ctx, items.map { it.id }.toSet()) }

    /** Возвращает файлы в общую галерею (Pictures/Restored, Movies/Restored). */
    suspend fun restore(ctx: Context, items: List<Item>): Int = withContext(Dispatchers.IO) {
        val ok = HashSet<Long>()
        for (m in items) runCatching {
            val f = m.file ?: return@runCatching
            val ext = m.name.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: if (m.video) "video/mp4" else "image/jpeg"
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, m.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, if (m.video) "Movies/Restored" else "Pictures/Restored")
                put(MediaStore.MediaColumns.DATE_TAKEN, m.ms)
            }
            val base = if (m.video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val u = ctx.contentResolver.insert(base, v)!!
            ctx.contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
            ok += m.id
        }
        drop(ctx, ok)
        ok.size
    }
}

// ───────────────────────────── распознавание на устройстве ─────────────────────────────

/** ML Kit Image Labeling работает полностью офлайн: снимки никуда не уходят. */
object Vision {
    private val labeler by lazy { ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS) }
    private val gate = Semaphore(3)

    private suspend fun labelOne(ctx: Context, m: Item): String? = gate.withPermit {
        runCatching {
            val bmp = withContext(Dispatchers.IO) { ctx.contentResolver.loadThumbnail(m.uri, Size(480, 480), null) }
            labeler.process(InputImage.fromBitmap(bmp, 0)).await()
                .filter { it.confidence > 0.6f }.take(8).joinToString { it.text }
        }.onFailure { if (it is CancellationException) throw it }.getOrNull()
    }

    suspend fun labels(ctx: Context, st: Store, m: Item): String {
        st.label(m.id)?.let { return it }
        if (m.video || m.file != null) return ""
        val r = labelOne(ctx, m) ?: return ""
        st.setLabel(m.id, r)
        return r
    }

    /** Параллельная индексация (3 потока), запись на диск пачками по 25 фото. */
    suspend fun index(ctx: Context, st: Store, items: List<Item>, limit: Int = 500, progress: (Int, Int) -> Unit) =
        coroutineScope {
            val todo = items.filter { !it.video && st.label(it.id) == null }.take(limit)
            val cnt = AtomicInteger(0)
            val buf = ConcurrentHashMap<Long, String>()
            fun flush() {
                val snap = HashMap(buf)
                st.setLabels(snap)
                snap.keys.forEach { buf.remove(it) }
            }
            try {
                todo.map { m ->
                    async {
                        ensureActive()
                        labelOne(ctx, m)?.let { buf[m.id] = it }
                        val n = cnt.incrementAndGet()
                        if (n % 25 == 0) flush()
                        withContext(Dispatchers.Main) { progress(n, todo.size) }
                    }
                }.awaitAll()
            } finally { flush() }
        }
}
