plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "app.photos"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.photos.deepgallery"; minSdk = 30; targetSdk = 34; versionCode = 3; versionName = "3.0"
        resourceConfigurations += listOf("ru", "en")
        // Только arm64 (все современные телефоны, включая Nothing): APK заметно легче. Для эмулятора x86 уберите строку.
        ndk { abiFilters += "arm64-v8a" }
    }
    buildTypes {
        release {
            // R8 + сжатие ресурсов: в release Compose работает в разы плавнее, чем в debug.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug") // чтобы APK ставился без своего keystore
        }
    }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            "-opt-in=androidx.compose.ui.ExperimentalComposeUiApi",
            "-opt-in=androidx.compose.animation.ExperimentalAnimationApi"
        )
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
}
