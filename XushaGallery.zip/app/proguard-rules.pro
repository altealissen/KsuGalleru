# Compose, Coil, OkHttp и ML Kit покрыты consumer-правилами библиотек.
-dontwarn org.slf4j.**
# MediaPipe (нейросеть Ксюши): нативный код обращается к Java-классам по имени
-keep class com.google.mediapipe.** { *; }
-dontwarn com.google.mediapipe.**
-keep class com.google.protobuf.** { *; }
-dontwarn com.google.protobuf.**
# security-crypto / Tink
-keepclassmembers class * extends com.google.crypto.tink.shaded.protobuf.GeneratedMessageLite { <fields>; }
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn javax.annotation.concurrent.**
-dontwarn com.google.auto.value.**
-dontwarn org.checkerframework.**
