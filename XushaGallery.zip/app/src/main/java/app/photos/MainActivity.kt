@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package app.photos

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.WindowManager
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NothingTheme {
                Surface(Modifier.fillMaxSize(), color = LocalNt.current.bg) { App(this) }
            }
        }
    }

    override fun onDestroy() {
        Vault.clearCache(this)               // расшифрованные для просмотра видео не должны оставаться на диске
        if (isFinishing) LocalLlm.unload()   // освобождаем память под нейросеть
        super.onDestroy()
    }
}

class Host(
    val open: (List<Item>, Int) -> Unit,
    val fav: (List<Item>) -> Unit,
    val trash: (List<Item>, Boolean) -> Unit,
    val purge: (List<Item>) -> Unit,
    val toVault: (List<Item>) -> Unit,
    val fromVault: (List<Item>) -> Unit,
    val delVault: (List<Item>) -> Unit,
    val share: (List<Item>) -> Unit,
    /** Подтверждение опасного действия: заголовок, текст, подпись кнопки, действие. */
    val ask: (String, String, String, () -> Unit) -> Unit,
    val addToGroup: (List<Item>) -> Unit,
    val removeFromGroup: (String, List<Item>) -> Unit
)

class Confirm(val title: String, val text: String, val yes: String, val action: () -> Unit)
class LockReq(val title: String, val mode: LockMode, val onOk: () -> Unit)
class NameReq(val title: String, val initial: String, val hint: String, val onOk: (String) -> Unit)

/** Операция над пачкой файлов через системный диалог: 0 — в корзину, 1 — из корзины, 2 — удалить навсегда. */
private class TrashReq(val uris: List<Uri>, val op: Int)

fun perms(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

fun hasPerm(c: Context) = perms().all { ContextCompat.checkSelfPermission(c, it) == android.content.pm.PackageManager.PERMISSION_GRANTED }

fun dur(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

fun sizeText(b: Long): String = if (b >= 1_000_000) "%.1f МБ".format(b / 1e6) else "${b / 1024} КБ"

fun shareItems(ctx: Context, l: List<Item>) {
    val real = l.filter { it.vaultId == null }
    if (real.isEmpty()) return
    val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
        type = "*/*"
        putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(real.map { it.uri }))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, null))
}

@Composable
fun PermissionScreen(onAsk: () -> Unit) {
    val c = LocalNt.current
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.Start) {
        RedDot(size = 12.dp)
        Spacer(Modifier.height(16.dp))
        DotText("Фото", size = 48.sp)
        Spacer(Modifier.height(12.dp))
        Text("Нужен доступ к фото и видео, чтобы показать вашу галерею. Сами снимки не покидают устройство.", color = c.dim)
        Spacer(Modifier.height(24.dp))
        Pill("Разрешить доступ", onAsk, filled = true)
    }
}

// ───────────────────────────── приложение ─────────────────────────────

@Composable
fun App(act: FragmentActivity) {
    val st = remember { Store(act) }
    remember { Vault.init(act) }
    val c = LocalNt.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(hasPerm(act)) }
    val permL = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasPerm(act) }
    LaunchedEffect(Unit) { if (!granted) permL.launch(perms()) }
    if (!granted) { PermissionScreen { permL.launch(perms()) }; return }

    fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    var all by remember { mutableStateOf(listOf<Item>()) }
    var trash by remember { mutableStateOf(listOf<Item>()) }
    var vault by remember { mutableStateOf(Vault.items()) }
    var loaded by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var ver by remember { mutableIntStateOf(0) }
    var gver by remember { mutableIntStateOf(0) }
    fun reload() {
        vault = Vault.items()
        if (loading) return
        loading = true
        scope.launch {
            try {
                val (a, t) = withContext(Dispatchers.IO) {
                    coroutineScope {
                        val a = async { Media.load(act) }
                        val t = async { Media.load(act, true) }
                        a.await() to t.await()
                    }
                }
                all = a; trash = t; loaded = true; ver++
            } finally { loading = false }
        }
    }

    // 0 — Медиатека, 1 — Коллекции, 2 — Ксюша, 3 — Поиск
    var tab by remember { mutableIntStateOf(0) }
    var album by remember { mutableStateOf<String?>(null) }
    var unlocked by remember { mutableStateOf(setOf<String>()) }
    var lockReq by remember { mutableStateOf<LockReq?>(null) }
    var lastLock by remember { mutableStateOf<LockReq?>(null) }
    var lockTrash by remember { mutableStateOf(st.lockTrash) }
    var showSecurity by remember { mutableStateOf(false) }
    var vShow by remember { mutableStateOf(false) }
    var vData by remember { mutableStateOf<Pair<List<Item>, Int>?>(null) }
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    var pendingRecs by remember { mutableStateOf<List<String>>(emptyList()) }
    var selecting by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var collapsed by remember { mutableStateOf(setOf<String>()) }
    var sheet by remember { mutableStateOf<Pair<Section, Aset>?>(null) }
    var nameDlg by remember { mutableStateOf<NameReq?>(null) }
    var picker by remember { mutableStateOf<List<Item>?>(null) }
    var addTo by remember { mutableStateOf<String?>(null) }
    var searchQ by remember { mutableStateOf("") }
    var searchKey by remember { mutableIntStateOf(0) }
    var libFilter by remember { mutableIntStateOf(0) }
    var libSort by remember { mutableIntStateOf(0) }
    var libGroup by remember { mutableIntStateOf(0) }
    var libCols by remember { mutableIntStateOf(4) }
    val chat = remember { mutableStateListOf<Pair<String, String>>() }
    val idx = remember { IdxState() }
    val inst = remember { InstallState() }

    DisposableEffect(act) {
        val o = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) reload()
            if (e == Lifecycle.Event.ON_STOP) {
                unlocked = emptySet()
                lockReq = null
                if (album == "vault" || (album == "trash" && st.lockTrash)) album = null
                if (vData?.first?.firstOrNull()?.vaultId != null) vShow = false
            }
        }
        act.lifecycle.addObserver(o)
        onDispose { act.lifecycle.removeObserver(o) }
    }

    // ── удаление/возврат через системные диалоги. Большие пачки режем на куски, чтобы не упереться в лимит Binder. ──
    val queue = remember { ArrayDeque<TrashReq>() }
    val senderRef = remember { arrayOfNulls<ActivityResultLauncher<IntentSenderRequest>>(1) }
    fun pump() {
        val r = queue.removeFirstOrNull() ?: return
        try {
            val pi = when (r.op) {
                0 -> MediaStore.createTrashRequest(act.contentResolver, r.uris, true)
                1 -> MediaStore.createTrashRequest(act.contentResolver, r.uris, false)
                else -> MediaStore.createDeleteRequest(act.contentResolver, r.uris)
            }
            senderRef[0]?.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } catch (e: Throwable) {
            queue.clear()
            toast("Не удалось: ${e.message}")
        }
    }
    val sender = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) pump() else queue.clear()
        reload()
    }
    senderRef[0] = sender
    fun enqueue(l: List<Item>, op: Int) {
        val real = l.filter { it.vaultId == null }
        if (real.isEmpty()) return
        real.map { it.uri }.chunked(1500).forEach { queue.addLast(TrashReq(it, op)) }
        pump()
    }

    val vaultSender = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (pendingRecs.isNotEmpty()) {
            if (r.resultCode != Activity.RESULT_OK) {
                Vault.delete(act, pendingRecs)   // оригиналы не разрешили удалить — откатываем копии, чтобы не плодить дубли
                toast("Отменено: файлы остались в галерее")
            } else toast("Перенесено в сейф")
        }
        pendingRecs = emptyList()
        reload()
    }

    val favs = remember(ver) { st.ids("fav") }
    val groups = remember(gver) { st.groups() }
    val pinnedKeys = remember(gver) { st.pinned() }

    fun moveToVault(l: List<Item>) {
        val real = l.filter { it.vaultId == null }
        if (real.isEmpty() || busy != null) return
        if (real.size > 1500) { toast("За раз можно перенести не больше 1500 файлов"); return }
        scope.launch {
            busy = "Шифрую 0 / ${real.size}"
            try {
                val recs = withContext(Dispatchers.IO) {
                    Vault.import(act, real) { n -> act.runOnUiThread { busy = "Шифрую $n / ${real.size}" } }
                }
                pendingRecs = recs.map { it.second }
                vault = Vault.items()
                vaultSender.launch(
                    IntentSenderRequest.Builder(
                        MediaStore.createDeleteRequest(act.contentResolver, recs.map { it.first.uri }).intentSender
                    ).build()
                )
            } catch (e: Throwable) {
                toast("Не удалось перенести в сейф: ${e.message}")
            } finally { busy = null }
        }
    }

    fun restoreFromVault(l: List<Item>) {
        val ids = l.mapNotNull { it.vaultId }
        if (ids.isEmpty() || busy != null) return
        scope.launch {
            busy = "Возвращаю в галерею…"
            try {
                withContext(Dispatchers.IO) { Vault.restore(act, ids) }
                toast("Возвращено в галерею (папка Restored)")
            } catch (e: Throwable) {
                toast("Ошибка: ${e.message}")
            } finally { busy = null; reload() }
        }
    }

    val host = Host(
        open = { l, i -> vData = l to i; vShow = true },
        fav = { l -> val on = l.any { it.id !in favs }; st.toggleAll("fav", l.map { it.id }, on); ver++ },
        trash = { l, t -> enqueue(l, if (t) 0 else 1) },
        purge = { l -> enqueue(l, 2) },
        toVault = { l -> moveToVault(l) },
        fromVault = { l -> restoreFromVault(l) },
        delVault = { l ->
            val ids = l.mapNotNull { it.vaultId }
            confirm = Confirm("Удалить навсегда?", "${ids.size} шт. будут удалены из сейфа без возможности восстановления.", "Удалить") {
                Vault.delete(act, ids); vault = Vault.items(); vShow = false
            }
        },
        share = { l -> shareItems(act, l) },
        ask = { t, x, y, a -> confirm = Confirm(t, x, y, a) },
        addToGroup = { l -> picker = l },
        removeFromGroup = { id, l -> st.removeFromGroup(id, l.map { it.id }); gver++ }
    )

    fun openSecure(kind: String) {
        val needs = kind == "vault" || (kind == "trash" && lockTrash)
        if (!needs || kind in unlocked) { album = kind; return }
        val mode = if (!st.hasPin()) LockMode.SETUP else LockMode.ENTER
        val req = LockReq(if (kind == "vault") "Сейф" else "Корзина", mode) {
            unlocked = unlocked + kind; album = kind; lockReq = null
        }
        lastLock = req; lockReq = req
    }

    fun deleteSet(s: Aset) {
        if (s.key.startsWith("b:")) confirm = Confirm(
            "Удалить папку «${s.name}»?",
            "${s.items.size} шт. отправятся в корзину и хранятся там 30 дней. Если файлов много, Android спросит подтверждение несколько раз.",
            "В корзину"
        ) { enqueue(s.items, 0); if (album == s.key) album = null }
        else if (s.key.startsWith("g:")) confirm = Confirm(
            "Удалить «${s.name}»?", "Удалится только подборка, сами фото останутся в галерее.", "Удалить"
        ) { st.deleteGroup(s.key.substring(2)); gver++; if (album == s.key) album = null }
    }

    fun newGroup(type: String) {
        nameDlg = NameReq(
            if (type == "person") "Новый человек" else "Новая папка", "", if (type == "person") "Имя" else "Название"
        ) { name ->
            val id = st.createGroup(name, type)
            gver++; nameDlg = null; tab = 1; album = "g:$id"
        }
    }

    val secure = lockReq != null || (tab == 1 && (album == "vault" || (album == "trash" && lockTrash))) ||
        (vShow && vData?.first?.firstOrNull()?.vaultId != null)
    DisposableEffect(secure) {
        if (secure) act.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { act.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    BackHandler(enabled = lockReq != null || vShow || addTo != null || (tab == 1 && album != null)) {
        if (lockReq != null) lockReq = null
        else if (vShow) vShow = false
        else if (addTo != null) addTo = null
        else album = null
    }

    val catalog = remember(all, favs, trash, vault, groups, ver) { buildCatalog(st, all, favs, trash, vault, groups) }
    val sections = remember(catalog, groups, pinnedKeys) { buildSections(catalog, groups, pinnedKeys) }

    val libItems = remember(all, libFilter, libSort, favs) {
        val f = when (libFilter) {
            1 -> all.filter { it.id in favs }
            2 -> all.filter { !it.video }
            3 -> all.filter { it.video }
            4 -> all.filter { Smart.isShot(it) }
            else -> all
        }
        if (libSort == 1) f.reversed() else f
    }
    val filterNames = listOf("Все элементы", "Избранное", "Фото", "Видео", "Скриншоты")
    val libSubtitle = if (libFilter == 0) "${all.count { !it.video }} фото · ${all.count { it.video }} видео" else filterNames[libFilter] + " · ${libItems.size}"

    val libExtra: @Composable RowScope.() -> Unit = {
        var menu by remember { mutableStateOf(false) }
        Box {
            Box(Modifier.size(44.dp).clip(CircleShape).background(c.surface).pressable { menu = true }, Alignment.Center) {
                NtIcon(3, c.text, Modifier.size(22.dp))
            }
            DropdownMenu(menu, { menu = false }, Modifier.background(c.surface)) {
                filterNames.forEachIndexed { i, n ->
                    DropdownMenuItem({ Text((if (libFilter == i) "● " else "○ ") + n) }, { libFilter = i; menu = false })
                }
                Hairline()
                listOf("Сначала новые", "Сначала старые").forEachIndexed { i, n ->
                    DropdownMenuItem({ Text((if (libSort == i) "● " else "○ ") + n) }, { libSort = i; menu = false })
                }
                Hairline()
                listOf("По дням", "По месяцам", "По годам").forEachIndexed { i, n ->
                    DropdownMenuItem({ Text((if (libGroup == i) "● " else "○ ") + n) }, { libGroup = i; menu = false })
                }
                Hairline()
                listOf(3, 4, 5).forEach { n ->
                    DropdownMenuItem({ Text((if (libCols == n) "● " else "○ ") + "Плитки: $n в ряд") }, { libCols = n; menu = false })
                }
            }
        }
        Spacer(Modifier.width(8.dp))
    }

    val imeOpen = WindowInsets.isImeVisible
    val barPad by animateDpAsState(if (imeOpen || selecting) 0.dp else 90.dp, tween(200), label = "barPad")

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            if (!loaded) {
                Box(Modifier.fillMaxSize().padding(48.dp), Alignment.Center) { DotProgress() }
            } else AnimatedContent(
                targetState = tab to (album ?: ""),
                transitionSpec = {
                    val deeper = targetState.second.isNotEmpty() && initialState.second.isEmpty() && targetState.first == initialState.first
                    val back = targetState.second.isEmpty() && initialState.second.isNotEmpty() && targetState.first == initialState.first
                    when {
                        deeper -> (slideInHorizontally(tween(280)) { it / 5 } + fadeIn(tween(280))) togetherWith fadeOut(tween(140))
                        back -> fadeIn(tween(240)) togetherWith (slideOutHorizontally(tween(240)) { it / 5 } + fadeOut(tween(200)))
                        else -> fadeIn(tween(240)) togetherWith fadeOut(tween(140))
                    }
                },
                label = "nav"
            ) { (t, a) ->
                when (t) {
                    0 -> GridScreen(
                        "Медиатека", libItems, favs, "normal", host, big = true, group = libGroup, subtitle = libSubtitle,
                        fixedCols = libCols, onSelMode = { selecting = it }, headerExtra = libExtra
                    )
                    1 -> {
                        val cur = catalog[a]
                        val secKey = if (a.startsWith("sec:")) a.substring(4) else null
                        val sec = sections.firstOrNull { it.key == secKey }
                        if (sec != null) SetsGrid(
                            sec.title, sec.sets, lockTrash, editing,
                            onBack = { album = null },
                            onOpen = { s -> if (s.key == "vault" || s.key == "trash") openSecure(s.key) else album = s.key },
                            onLong = { s -> sheet = sec to s },
                            onBadge = { s -> if (sec.key == "pinned") { st.setPinned(pinnedKeys - s.key); gver++ } else deleteSet(s) }
                        ) else if (cur == null || a.isEmpty()) CollectionsScreen(
                            sections, lockTrash, editing, collapsed,
                            "${sections.firstOrNull { it.key == "albums" }?.sets?.size ?: 0} альбомов · ${groups.count { it.type == "person" }} чел.",
                            onEditing = { editing = it },
                            onToggle = { k -> collapsed = if (k in collapsed) collapsed - k else collapsed + k },
                            onOpen = { s -> if (s.key == "vault" || s.key == "trash") openSecure(s.key) else album = s.key },
                            onSection = { s -> album = "sec:${s.key}" },
                            onLong = { s, x -> sheet = s to x },
                            onBadge = { s, x -> if (s.key == "pinned") { st.setPinned(pinnedKeys - x.key); gver++ } else deleteSet(x) },
                            onNew = { type -> newGroup(type) },
                            onSecurity = { showSecurity = true }
                        ) else {
                            val isB = cur.key.startsWith("b:")
                            val isG = cur.key.startsWith("g:")
                            GridScreen(
                                cur.name, cur.items, favs, cur.mode, host, onBack = { album = null },
                                onSelMode = { selecting = it },
                                headerExtra = if (isB || isG) ({
                                    if (isG) {
                                        Pill("Добавить", { addTo = cur.key.substring(2) }, filled = true)
                                        Spacer(Modifier.width(6.dp))
                                    }
                                    IconButton({ deleteSet(cur) }, Modifier.size(42.dp)) { Icon(Icons.Default.Delete, null, tint = c.red) }
                                }) else null
                            )
                        }
                    }
                    2 -> Box(Modifier.fillMaxSize().padding(bottom = barPad)) {
                        AiTab(
                            st, all, favs, chat, idx, inst, scope,
                            onIndex = {
                                if (!idx.running) {
                                    val snapshot = all
                                    idx.running = true; idx.done = 0; idx.total = 0
                                    idx.job = scope.launch {
                                        try { AI.index(act, st, snapshot) { x, y -> idx.done = x; idx.total = y } }
                                        catch (e: CancellationException) { }
                                        finally { idx.running = false; ver++ }
                                    }
                                }
                            },
                            onStopIndex = { idx.job?.cancel() },
                            onSearch = { q -> searchQ = q; searchKey++; tab = 3 }
                        )
                    }
                    else -> Box(Modifier.fillMaxSize().padding(bottom = barPad)) {
                        SearchTab(st, all, favs, host, groups, searchQ, searchKey) { selecting = it }
                    }
                }
            }
        }

        // Плавающая панель вкладок как в айфоне. Скрывается при выборе фото и при вводе текста.
        AnimatedVisibility(
            !selecting && !imeOpen && !vShow && addTo == null,
            Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(260)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(200)) { it } + fadeOut(tween(150))
        ) {
            Box(Modifier.navigationBarsPadding()) {
                Box(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(120.dp)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, c.bg.copy(alpha = 0.92f))))
                )
                FloatingBar(tab) { tab = it; album = null; editing = false }
            }
        }

        // Выбор фото для человека/папки
        AnimatedVisibility(
            addTo != null,
            enter = fadeIn(tween(200)) + slideInVertically(tween(280)) { it / 6 },
            exit = fadeOut(tween(160)) + slideOutVertically(tween(200)) { it / 8 }
        ) {
            val gid = addTo
            if (gid != null) {
                val already = groups.firstOrNull { it.id == gid }?.ids ?: emptySet()
                Box(Modifier.fillMaxSize().background(c.bg).statusBarsPadding()) {
                    GridScreen(
                        "Выберите фото", all.filter { it.id !in already }, favs, "pick", host,
                        onBack = { addTo = null },
                        onPick = { l -> st.addToGroup(gid, l.map { it.id }); gver++; addTo = null; toast("Добавлено: ${l.size}") }
                    )
                }
            }
        }

        AnimatedVisibility(
            vShow,
            enter = fadeIn(tween(200)) + scaleIn(tween(260), initialScale = 0.92f),
            exit = fadeOut(tween(180)) + scaleOut(tween(220), targetScale = 0.94f)
        ) {
            val d = vData
            if (d != null) Viewer(d.first, d.second, favs, tab == 1 && album == "trash", st, host) { vShow = false }
        }

        AnimatedVisibility(
            lockReq != null,
            enter = fadeIn(tween(200)) + slideInVertically(tween(280)) { it / 8 },
            exit = fadeOut(tween(160)) + slideOutVertically(tween(200)) { it / 10 }
        ) {
            val r = lastLock
            if (r != null) LockScreen(r.title, r.mode, st, act, r.onOk) { lockReq = null }
        }

        AnimatedVisibility(busy != null, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)).pointerInput(Unit) { detectTapGestures { } },
                Alignment.Center
            ) {
                Column(
                    Modifier.padding(32.dp).clip(RoundedCornerShape(28.dp)).background(c.surface).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    DotProgress(Modifier.width(220.dp))
                    Spacer(Modifier.height(14.dp))
                    Cap(busy ?: "", color = c.text)
                }
            }
        }
    }

    // ── диалоги ──
    confirm?.let { cf ->
        AlertDialog(
            onDismissRequest = { confirm = null }, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
            title = { Text(cf.title, style = MaterialTheme.typography.titleMedium) },
            text = { Text(cf.text, color = c.dim) },
            confirmButton = { Pill(cf.yes, { confirm = null; cf.action() }, filled = true) },
            dismissButton = { Pill("Отмена", { confirm = null }) }
        )
    }

    nameDlg?.let { n -> NameDialog(n.title, n.initial, n.hint, n.onOk) { nameDlg = null } }

    picker?.let { list ->
        GroupPickerDialog(
            groups, list.size,
            onPick = { g ->
                st.addToGroup(g.id, list.map { it.id }); gver++; picker = null
                toast("Добавлено в «${g.name}»")
            },
            onNew = { type ->
                picker = null
                nameDlg = NameReq(
                    if (type == "person") "Новый человек" else "Новая папка", "", if (type == "person") "Имя" else "Название"
                ) { name ->
                    val id = st.createGroup(name, type)
                    st.addToGroup(id, list.map { it.id })
                    gver++; nameDlg = null
                    toast("Добавлено в «$name»")
                }
            },
            onClose = { picker = null }
        )
    }

    sheet?.let { (sec, s) ->
        val isPinned = s.key in pinnedKeys
        val actions = buildList<Triple<String, Boolean, () -> Unit>> {
            add(Triple(if (isPinned) "Открепить" else "Закрепить", false) {
                st.setPinned(if (isPinned) pinnedKeys - s.key else pinnedKeys + s.key); gver++
            })
            if (s.key.startsWith("g:")) add(Triple("Переименовать", false) {
                nameDlg = NameReq("Переименовать", s.name, "Имя") { name ->
                    st.renameGroup(s.key.substring(2), name); gver++; nameDlg = null
                }
            })
            if (s.key.startsWith("b:") || s.key.startsWith("g:")) add(Triple("Удалить", true) { deleteSet(s) })
        }
        ActionSheet(s.name, actions) { sheet = null }
    }

    if (showSecurity) SecurityDialog(
        st, act, lockTrash,
        onLockTrash = { on -> st.lockTrash = on; lockTrash = on },
        onPin = { mode ->
            showSecurity = false
            val req = LockReq("ПИН-код", mode) { lockReq = null; toast("ПИН-код сохранён") }
            lastLock = req; lockReq = req
        },
        onClose = { showSecurity = false }
    )
}

// ───────────────────────────── сетка ─────────────────────────────

@Composable
fun Thumb(m: Item, modifier: Modifier = Modifier, px: Int = 300, scale: ContentScale = ContentScale.Crop) {
    val ctx = LocalContext.current
    val c = LocalNt.current
    val bmp by produceState(ThumbCache.peek(m, px), m.id, px) {
        if (value == null) value = ThumbCache.get(ctx, m, px)
    }
    val img = remember(bmp) { bmp?.asImageBitmap() }
    val a by animateFloatAsState(if (img != null) 1f else 0f, tween(220), label = "thumbFade")
    Box(modifier.background(c.surface2)) {
        img?.let { Image(it, null, Modifier.fillMaxSize().graphicsLayer { alpha = a }, contentScale = scale) }
    }
}

@Composable
private fun Cell(m: Item, px: Int, selected: Boolean, fav: Boolean, modifier: Modifier) {
    val c = LocalNt.current
    val sc by animateFloatAsState(if (selected) 0.84f else 1f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "cellSel")
    val r by animateDpAsState(if (selected) 14.dp else 0.dp, tween(180), label = "cellRadius")
    Box(modifier) {
        Box(Modifier.fillMaxSize().graphicsLayer { scaleX = sc; scaleY = sc }.clip(RoundedCornerShape(r))) {
            Thumb(m, Modifier.fillMaxSize(), px)
            if (m.video) Box(
                Modifier.align(Alignment.BottomEnd).padding(5.dp).clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = .6f)).padding(horizontal = 6.dp, vertical = 2.dp)
            ) { Text(dur(m.dur), color = Color.White, fontFamily = Mono, fontSize = 10.sp) }
            if (fav) RedDot(Modifier.align(Alignment.BottomStart).padding(7.dp), 6.dp)
        }
        AnimatedVisibility(
            selected, Modifier.align(Alignment.TopEnd).padding(6.dp),
            enter = scaleIn(spring(dampingRatio = 0.5f, stiffness = 600f)) + fadeIn(tween(100)),
            exit = scaleOut(tween(100)) + fadeOut(tween(100))
        ) {
            Box(Modifier.size(22.dp).clip(CircleShape).background(c.red), Alignment.Center) {
                Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
            }
        }
    }
}

/**
 * Сетка как в айфоне: кнопка «Выбрать», фильтр, группировка по дням/месяцам/годам. Выделение: «Выбрать» и тапы,
 * либо долгое нажатие и, не отрывая палец, проводим по соседним (у края список сам прокручивается).
 * mode: normal | trash | vault | g:<id> (человек/папка) | pick (выбор фото для добавления).
 */
@Composable
fun GridScreen(
    title: String, items: List<Item>, favs: Set<Long>, mode: String, h: Host,
    onBack: (() -> Unit)? = null, big: Boolean = false, group: Int = 0, subtitle: String? = null,
    fixedCols: Int? = null, onSelMode: (Boolean) -> Unit = {}, onPick: ((List<Item>) -> Unit)? = null,
    headerExtra: (@Composable RowScope.() -> Unit)? = null
) {
    val c = LocalNt.current
    val haptic = LocalHapticFeedback.current
    var sel by remember { mutableStateOf(setOf<Long>()) }
    var selecting by remember { mutableStateOf(false) }
    var colsInner by remember { mutableIntStateOf(3) }
    val cols = fixedCols ?: colsInner
    val gridState = rememberLazyGridState()
    val groups = remember(items, group) { items.groupBy { it.label(group) } }
    val idx = remember(items) { items.withIndex().associate { it.value.id to it.index } }
    val chosen = remember(sel, items) { items.filter { it.id in sel } }
    val active = selecting || sel.isNotEmpty() || mode == "pick"
    val px = when (cols) { 2 -> 540; 3 -> 360; 4 -> 300; else -> 240 }

    LaunchedEffect(active) { onSelMode(active && mode != "pick") }
    DisposableEffect(Unit) { onDispose { onSelMode(false) } }

    val itemsNow by rememberUpdatedState(items)
    val idxNow by rememberUpdatedState(idx)
    val groupsNow by rememberUpdatedState(groups)
    val hNow by rememberUpdatedState(h)
    val activeNow by rememberUpdatedState(active)

    var anchor by remember { mutableIntStateOf(-1) }
    var base by remember { mutableStateOf(setOf<Long>()) }
    var adding by remember { mutableStateOf(true) }
    var lastIdx by remember { mutableIntStateOf(-1) }
    var lastPos by remember { mutableStateOf(Offset.Zero) }
    var scrollDir by remember { mutableIntStateOf(0) }

    LaunchedEffect(items) {
        if (sel.isNotEmpty()) {
            val ids = items.map { it.id }.toSet()
            val kept = sel.filter { it in ids }.toSet()
            if (kept.size != sel.size) sel = kept
        }
    }

    fun done() { sel = emptySet(); selecting = false }

    fun hit(pos: Offset): Int {
        for (info in gridState.layoutInfo.visibleItemsInfo) {
            val k = info.key
            if (k is Long &&
                pos.x >= info.offset.x && pos.x < info.offset.x + info.size.width &&
                pos.y >= info.offset.y && pos.y < info.offset.y + info.size.height
            ) return idxNow[k] ?: -1
        }
        return -1
    }

    fun applyRange(cur: Int) {
        val list = itemsNow
        if (anchor < 0 || anchor >= list.size || cur < 0 || cur >= list.size) return
        val ids = (minOf(anchor, cur)..maxOf(anchor, cur)).map { list[it].id }
        sel = if (adding) base + ids else base - ids.toSet()
        if (cur != lastIdx) { lastIdx = cur; haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    }

    fun onTapAt(pos: Offset) {
        val i = hit(pos)
        if (i >= 0) {
            val m = itemsNow[i]
            if (activeNow) sel = if (m.id in sel) sel - m.id else sel + m.id
            else hNow.open(itemsNow, i)
            return
        }
        if (!activeNow) return
        for (info in gridState.layoutInfo.visibleItemsInfo) {
            val k = info.key
            if (k is String && k.startsWith("h:") && pos.y >= info.offset.y && pos.y < info.offset.y + info.size.height) {
                val ids = groupsNow[k.substring(2)]?.map { it.id } ?: return
                sel = if (ids.all { it in sel }) sel - ids.toSet() else sel + ids
                return
            }
        }
    }

    LaunchedEffect(scrollDir) {
        while (scrollDir != 0) {
            gridState.scrollBy(scrollDir * 14f)
            val i = hit(lastPos)
            if (i >= 0) applyRange(i)
            delay(16)
        }
    }

    val gesture = Modifier.pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val slop = viewConfiguration.touchSlop
            val outcome = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                var r = 0
                while (r == 0) {
                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                    val ch = ev.changes.firstOrNull { it.id == down.id }
                    r = when {
                        ch == null -> 3
                        ch.changedToUpIgnoreConsumed() -> 1
                        (ch.position - down.position).getDistance() > slop -> 2
                        else -> 0
                    }
                }
                r
            }
            when (outcome) {
                null -> {
                    val start = hit(down.position)
                    if (start >= 0) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        selecting = true
                        anchor = start; base = sel; lastIdx = -1
                        adding = itemsNow[start].id !in sel
                        lastPos = down.position
                        applyRange(start)
                        while (true) {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                            ch.consume()
                            if (ch.changedToUpIgnoreConsumed() || !ch.pressed) break
                            lastPos = ch.position
                            val j = hit(ch.position)
                            if (j >= 0) applyRange(j)
                            val vh = gridState.layoutInfo.viewportSize.height
                            scrollDir = when {
                                ch.position.y < 90f -> -2
                                ch.position.y < 220f -> -1
                                ch.position.y > vh - 90f -> 2
                                ch.position.y > vh - 220f -> 1
                                else -> 0
                            }
                        }
                        scrollDir = 0; anchor = -1
                    }
                }
                1 -> onTapAt(down.position)
                else -> Unit
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().height(if (big && !active) 84.dp else 68.dp)
                    .padding(start = if (onBack != null || mode == "pick") 4.dp else 20.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (mode == "pick") IconButton({ onBack?.invoke() }, Modifier.size(42.dp)) { Icon(Icons.Default.Close, null, tint = c.text) }
                else if (onBack != null && !active) IconButton(onBack, Modifier.size(42.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = c.text) }
                Crossfade(if (active) sel.size else -1, Modifier.weight(1f), label = "gridTitle") { n ->
                    Column {
                        if (n < 0) {
                            DotText(title, size = if (big) 30.sp else 24.sp)
                            Cap(subtitle ?: "${items.size} шт.")
                        } else {
                            DotText("%02d".format(n), size = 26.sp, color = c.red)
                            Cap(if (mode == "pick") "выберите фото" else "выбрано")
                        }
                    }
                }
                if (mode == "pick") {
                    Pill("Добавить", { onPick?.invoke(chosen) }, filled = true, enabled = chosen.isNotEmpty())
                } else if (active) {
                    Pill("Все", { sel = if (sel.size == items.size) emptySet() else items.map { it.id }.toSet() })
                    Spacer(Modifier.width(6.dp))
                    Pill("Готово", { done() }, filled = true)
                } else {
                    headerExtra?.invoke(this)
                    if (mode == "trash" && items.isNotEmpty()) {
                        Pill("Очистить", {
                            h.ask("Очистить корзину?", "${items.size} шт. будут удалены навсегда. Android попросит подтвердить.", "Очистить") { h.purge(items) }
                        })
                        Spacer(Modifier.width(6.dp))
                    }
                    if (fixedCols == null) {
                        Pill("$cols×", { colsInner = when (colsInner) { 2 -> 3; 3 -> 4; 4 -> 5; else -> 2 } })
                        Spacer(Modifier.width(6.dp))
                    }
                    if (items.isNotEmpty()) Pill("Выбрать", { selecting = true })
                }
            }
            if (items.isEmpty()) Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    DotText("Пусто", size = 24.sp, color = c.dim)
                    if (mode.startsWith("g:")) {
                        Spacer(Modifier.height(8.dp))
                        Text("Нажми «Добавить» вверху и выбери фото.", color = c.dim, fontSize = 13.sp)
                    }
                }
            } else LazyVerticalGrid(
                columns = GridCells.Fixed(cols), modifier = Modifier.fillMaxSize().then(gesture), state = gridState,
                contentPadding = PaddingValues(bottom = if (mode == "pick") 16.dp else 120.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                groups.forEach { (label, list) ->
                    item(key = "h:$label", span = { GridItemSpan(maxLineSpan) }, contentType = "header") {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 18.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RedDot(size = 6.dp)
                            Spacer(Modifier.width(10.dp))
                            Cap(label, color = c.text)
                        }
                    }
                    items(list, key = { it.id }, contentType = { "media" }) { m ->
                        Cell(m, px, m.id in sel, m.id in favs, Modifier.animateItemPlacement().aspectRatio(1f))
                    }
                }
            }
        }

        // Нижняя панель действий при выборе — как в айфоне
        AnimatedVisibility(
            active && mode != "pick", Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.8f, stiffness = 400f)) { it } + fadeIn(tween(150)),
            exit = slideOutVertically(tween(180)) { it } + fadeOut(tween(120))
        ) {
            Row(
                Modifier.navigationBarsPadding().padding(bottom = 14.dp).clip(RoundedCornerShape(32.dp))
                    .background(c.surface).padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val on = chosen.isNotEmpty()
                val bs = Modifier.size(48.dp)
                val tint = if (on) c.text else c.dim
                when {
                    mode == "trash" -> {
                        IconButton({ h.trash(chosen, false); done() }, bs, enabled = on) { Icon(Icons.Default.Refresh, null, tint = tint) }
                        IconButton({
                            h.ask("Удалить навсегда?", "${chosen.size} шт. будут удалены без возможности восстановления.", "Удалить") { h.purge(chosen) }
                            done()
                        }, bs, enabled = on) { Icon(Icons.Default.Delete, null, tint = if (on) c.red else c.dim) }
                    }
                    mode == "vault" -> {
                        IconButton({ h.fromVault(chosen); done() }, bs, enabled = on) { Icon(Icons.Default.Refresh, null, tint = tint) }
                        IconButton({ h.delVault(chosen); done() }, bs, enabled = on) { Icon(Icons.Default.Delete, null, tint = if (on) c.red else c.dim) }
                    }
                    else -> {
                        IconButton({ h.share(chosen) }, bs, enabled = on) { Icon(Icons.Default.Share, null, tint = tint) }
                        IconButton({ h.fav(chosen); done() }, bs, enabled = on) { Icon(Icons.Default.Favorite, null, tint = tint) }
                        IconButton({ h.addToGroup(chosen); done() }, bs, enabled = on) { Icon(Icons.Default.Add, null, tint = tint) }
                        if (mode.startsWith("g:")) IconButton({ h.removeFromGroup(mode.substring(2), chosen); done() }, bs, enabled = on) {
                            Icon(Icons.Default.Close, null, tint = tint)
                        }
                        IconButton({ h.toVault(chosen); done() }, bs, enabled = on) { Icon(Icons.Default.Lock, null, tint = tint) }
                        IconButton({ h.trash(chosen, true); done() }, bs, enabled = on) { Icon(Icons.Default.Delete, null, tint = if (on) c.red else c.dim) }
                    }
                }
            }
        }
    }
}

// ───────────────────────────── просмотр ─────────────────────────────

@Composable
fun Viewer(list: List<Item>, start: Int, favs: Set<Long>, trashMode: Boolean, st: Store, h: Host, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val c = LocalNt.current
    val ps = rememberPagerState(start.coerceIn(0, list.size - 1)) { list.size }
    val m = list[ps.currentPage.coerceIn(0, list.size - 1)]
    val inVault = m.vaultId != null
    var info by remember { mutableStateOf(false) }
    var ai by remember { mutableStateOf(false) }
    var chrome by remember { mutableStateOf(true) }
    var dragPx by remember { mutableFloatStateOf(0f) }
    val bgA = 1f - (dragPx / 700f).coerceIn(0f, 0.9f)

    DisposableEffect(Unit) {
        val ctl = (view.context as? Activity)?.window?.let { WindowCompat.getInsetsController(it, view) }
        val prevS = ctl?.isAppearanceLightStatusBars
        val prevN = ctl?.isAppearanceLightNavigationBars
        ctl?.isAppearanceLightStatusBars = false
        ctl?.isAppearanceLightNavigationBars = false
        onDispose {
            if (ctl != null) {
                prevS?.let { ctl.isAppearanceLightStatusBars = it }
                prevN?.let { ctl.isAppearanceLightNavigationBars = it }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgA))) {
        HorizontalPager(ps, Modifier.fillMaxSize(), pageSpacing = 12.dp, key = { list[it].id }) { p ->
            Page(list[p], onTap = { chrome = !chrome }, onDrag = { dragPx = it }, onDismiss = onClose)
        }
        AnimatedVisibility(
            chrome && dragPx == 0f, Modifier.align(Alignment.TopStart),
            enter = fadeIn(tween(180)) + slideInVertically(tween(220)) { -it / 3 },
            exit = fadeOut(tween(150)) + slideOutVertically(tween(180)) { -it / 3 }
        ) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .7f), Color.Transparent)))
                    .statusBarsPadding().padding(end = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClose) { Icon(Icons.Default.Close, null, tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Cap(fmt("d MMMM yyyy", m.ms), color = Color.White)
                    Cap(fmt("HH:mm", m.ms), color = Color.White.copy(alpha = .6f))
                }
                Cap("${ps.currentPage + 1} / ${list.size}", color = Color.White.copy(alpha = .6f))
            }
        }
        AnimatedVisibility(
            chrome && dragPx == 0f, Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(180)) + slideInVertically(tween(220)) { it / 2 },
            exit = fadeOut(tween(150)) + slideOutVertically(tween(180)) { it / 2 }
        ) {
            Row(
                Modifier.navigationBarsPadding().padding(bottom = 16.dp)
                    .clip(RoundedCornerShape(32.dp)).background(Color(0xE6161616)).padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val bs = Modifier.size(44.dp)
                when {
                    trashMode -> {
                        IconButton({ h.trash(listOf(m), false); onClose() }, bs) { Icon(Icons.Default.Refresh, null, tint = Color.White) }
                        IconButton({
                            h.ask("Удалить навсегда?", "Файл будет удалён без возможности восстановления.", "Удалить") { h.purge(listOf(m)) }
                        }, bs) { Icon(Icons.Default.Delete, null, tint = c.red) }
                    }
                    inVault -> {
                        IconButton({ info = true }, bs) { Icon(Icons.Default.Info, null, tint = Color.White) }
                        IconButton({ h.fromVault(listOf(m)); onClose() }, bs) { Icon(Icons.Default.Refresh, null, tint = Color.White) }
                        IconButton({ h.delVault(listOf(m)) }, bs) { Icon(Icons.Default.Delete, null, tint = c.red) }
                    }
                    else -> {
                        IconButton({ h.share(listOf(m)) }, bs) { Icon(Icons.Default.Share, null, tint = Color.White) }
                        IconButton({ h.fav(listOf(m)) }, bs) {
                            Icon(if (m.id in favs) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (m.id in favs) c.red else Color.White)
                        }
                        IconButton({ h.addToGroup(listOf(m)) }, bs) { Icon(Icons.Default.Add, null, tint = Color.White) }
                        IconButton({ info = true }, bs) { Icon(Icons.Default.Info, null, tint = Color.White) }
                        IconButton({ ai = true }, bs) { DotText("AI", size = 17.sp, color = c.red) }
                        if (!m.video) IconButton({
                            runCatching {
                                ctx.startActivity(
                                    Intent.createChooser(
                                        Intent(Intent.ACTION_EDIT).setDataAndType(m.uri, "image/*")
                                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION), null
                                    )
                                )
                            }
                        }, bs) { Icon(Icons.Default.Edit, null, tint = Color.White) }
                        IconButton({ h.toVault(listOf(m)); onClose() }, bs) { Icon(Icons.Default.Lock, null, tint = Color.White) }
                        IconButton({ h.trash(listOf(m), true); onClose() }, bs) { Icon(Icons.Default.Delete, null, tint = Color.White) }
                    }
                }
            }
        }
    }
    if (info) InfoDialog(m, st) { info = false }
    if (ai) AiDialog(m, st) { ai = false }
}

@Composable
fun InfoDialog(m: Item, st: Store, onClose: () -> Unit) {
    val c = LocalNt.current
    AlertDialog(
        onDismissRequest = onClose, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
        confirmButton = { Pill("Ок", onClose, filled = true) },
        title = { Text(m.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoRow("Дата", fmt("d MMMM yyyy HH:mm", m.ms))
                InfoRow("Размер", sizeText(m.size))
                InfoRow("Разрешение", "${m.w}×${m.h}")
                InfoRow("Альбом", m.album)
                if (m.vaultId == null) {
                    InfoRow("Метки", st.label(m.id)?.ifBlank { "—" } ?: "не анализировано")
                    st.note(m.id)?.let { InfoRow("Заметка", it) }
                } else InfoRow("Где лежит", "в сейфе, зашифровано")
            }
        }
    )
}

@Composable
private fun InfoRow(k: String, v: String) {
    val c = LocalNt.current
    Column {
        Cap(k)
        Text(v, color = c.text, fontSize = 14.sp)
    }
}

/**
 * Одна страница просмотра: щипок — масштаб, пальцем при увеличении — перемещение, двойной тап — плавный зум,
 * свайп вниз — закрыть (фон бледнеет, как в айфоне). Пока масштаб = 1, горизонтальные свайпы отдаются пейджеру.
 */
@Composable
fun Page(m: Item, onTap: () -> Unit, onDrag: (Float) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalNt.current
    val scope = rememberCoroutineScope()
    val tap by rememberUpdatedState(onTap)
    val dragCb by rememberUpdatedState(onDrag)
    val dismissCb by rememberUpdatedState(onDismiss)
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var dragY by remember { mutableFloatStateOf(0f) }
    var playing by remember { mutableStateOf<File?>(null) }
    val vid = m.vaultId

    val vaultBmp by produceState<android.graphics.Bitmap?>(null, vid) {
        if (vid != null && !m.video) value = withContext(Dispatchers.IO) { Vault.decode(ctx, vid) }
    }

    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { tap() },
                    onDoubleTap = {
                        scope.launch {
                            val target = if (scale > 1.05f) 1f else 2.5f
                            animate(scale, target, animationSpec = spring(stiffness = 300f)) { v, _ ->
                                scale = v
                                if (target == 1f) offset = Offset.Zero
                            }
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var dragging = false
                    var tx = 0f
                    var ty = 0f
                    val slop = viewConfiguration.touchSlop
                    do {
                        val ev = awaitPointerEvent()
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        val pressed = ev.changes.count { it.pressed }
                        if (pressed >= 2 || scale > 1.01f) {
                            val ns = (scale * zoom).coerceIn(1f, 6f)
                            val maxX = size.width * (ns - 1f) / 2f
                            val maxY = size.height * (ns - 1f) / 2f
                            offset = Offset((offset.x + pan.x).coerceIn(-maxX, maxX), (offset.y + pan.y).coerceIn(-maxY, maxY))
                            scale = ns
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        } else if (pressed == 1) {
                            tx += pan.x; ty += pan.y
                            if (!dragging && ty > slop * 2 && ty > abs(tx) * 1.5f) dragging = true
                            if (dragging) {
                                dragY = (dragY + pan.y).coerceAtLeast(0f)
                                dragCb(dragY)
                                ev.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                        }
                    } while (ev.changes.any { it.pressed })
                    if (dragging) {
                        if (dragY > 200f) dismissCb()
                        else scope.launch {
                            animate(dragY, 0f, animationSpec = spring(stiffness = 400f)) { v, _ -> dragY = v; dragCb(v) }
                        }
                    }
                    if (scale < 1.02f) { scale = 1f; offset = Offset.Zero }
                }
            },
        Alignment.Center
    ) {
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                val k = 1f - (dragY / 2400f).coerceIn(0f, 0.2f)
                scaleX = scale * k; scaleY = scale * k
                translationX = offset.x; translationY = offset.y + dragY
            },
            Alignment.Center
        ) {
            if (m.video) {
                Thumb(m, Modifier.fillMaxSize(), 1024, ContentScale.Fit)
                Box(
                    Modifier.size(76.dp).clip(CircleShape).background(c.red).pressable {
                        if (vid != null) scope.launch {
                            runCatching { withContext(Dispatchers.IO) { Vault.videoFile(ctx, vid) } }
                                .onSuccess { playing = it }
                                .onFailure { Toast.makeText(ctx, "Не удалось расшифровать видео", Toast.LENGTH_SHORT).show() }
                        } else ctx.startActivity(
                            Intent(Intent.ACTION_VIEW).setDataAndType(m.uri, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        )
                    }, Alignment.Center
                ) { Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(44.dp)) }
            } else if (vid != null) {
                val b = vaultBmp
                if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                else DotProgress(Modifier.padding(64.dp))
            } else AsyncImage(m.uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        }
        playing?.let { f -> VideoOverlay(f) { playing = null } }
    }
}

@Composable
private fun VideoOverlay(file: File, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                VideoView(ctx).apply {
                    val mc = MediaController(ctx)
                    mc.setAnchorView(this)
                    setMediaController(mc)
                    setVideoPath(file.absolutePath)
                    setOnPreparedListener { start() }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        IconButton(onClose, Modifier.statusBarsPadding().align(Alignment.TopStart)) { Icon(Icons.Default.Close, null, tint = Color.White) }
    }
}
