package app.photos

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Size
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.util.UUID

class VRec(
    val id: String, val num: Long, val name: String, val video: Boolean, val ms: Long, val size: Long,
    val w: Int, val h: Int, val album: String, val dur: Long, val mime: String
)

/**
 * Сейф. Файл копируется в приватную папку приложения и шифруется AES-256-GCM (ключ — в Android Keystore),
 * а оригинал удаляется из системной галереи: другие приложения его больше не видят.
 * Имена файлов и даты тоже зашифрованы (индекс). PIN/биометрия защищают вход в интерфейс.
 *
 * ВАЖНО: EncryptedFile привязывает шифротекст к имени файла, поэтому файлы нельзя переименовывать.
 */
object Vault {
    private var dir: File? = null
    private val recs = ArrayList<VRec>()
    private var mk: MasterKey? = null
    private var counter = -1L
    private var gen = 0
    private val lock = Any()

    fun init(ctx: Context) {
        synchronized(lock) {
            if (dir != null) return
            val d = File(ctx.filesDir, "vault")
            d.mkdirs()
            dir = d
            load(ctx)
        }
    }

    // ── шифрование ──
    private fun key(ctx: Context): MasterKey = mk ?: MasterKey.Builder(ctx.applicationContext)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build().also { mk = it }

    private fun ef(ctx: Context, f: File) = EncryptedFile.Builder(
        ctx.applicationContext, f, key(ctx), EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
    ).build()

    private fun writeEnc(ctx: Context, f: File, block: (OutputStream) -> Unit) {
        if (f.exists()) f.delete()
        ef(ctx, f).openFileOutput().use { block(it) }
    }

    private fun readEnc(ctx: Context, f: File): ByteArray = ef(ctx, f).openFileInput().use { it.readBytes() }

    // ── индекс (две поколения файлов: сбой посреди записи не убьёт сейф) ──
    private fun indexFiles(): List<Pair<Int, File>> =
        (dir?.listFiles() ?: emptyArray()).mapNotNull { f ->
            Regex("index\\.(\\d+)\\.enc").matchEntire(f.name)?.let { it.groupValues[1].toInt() to f }
        }.sortedByDescending { it.first }

    private fun load(ctx: Context) {
        for ((g, f) in indexFiles()) {
            val ok = runCatching {
                val arr = JSONArray(String(readEnc(ctx, f), Charsets.UTF_8))
                val tmp = ArrayList<VRec>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    tmp += VRec(
                        o.getString("id"), o.getLong("num"), o.getString("name"), o.getBoolean("video"),
                        o.getLong("ms"), o.getLong("size"), o.getInt("w"), o.getInt("h"),
                        o.getString("album"), o.getLong("dur"), o.getString("mime")
                    )
                }
                recs.clear(); recs.addAll(tmp)
            }.isSuccess
            if (ok) { gen = g; break }
        }
        counter = (recs.minOfOrNull { it.num } ?: 0L) - 1
        if (counter >= 0) counter = -1
    }

    private fun save(ctx: Context) {
        val arr = JSONArray()
        recs.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("num", it.num).put("name", it.name).put("video", it.video)
                    .put("ms", it.ms).put("size", it.size).put("w", it.w).put("h", it.h)
                    .put("album", it.album).put("dur", it.dur).put("mime", it.mime)
            )
        }
        val old = indexFiles()
        gen += 1
        val f = File(dir, "index.$gen.enc")
        writeEnc(ctx, f) { it.write(arr.toString().toByteArray(Charsets.UTF_8)) }
        old.forEach { if (it.first < gen - 1) it.second.delete() }   // предыдущую копию оставляем про запас
    }

    // ── список ──
    fun items(): List<Item> = synchronized(lock) {
        recs.map {
            Item(it.num, Uri.EMPTY, it.name, it.ms, it.video, it.size, it.w, it.h, it.album, it.dur, vaultId = it.id)
        }.sortedByDescending { it.ms }
    }

    private fun rec(id: String): VRec? = synchronized(lock) { recs.firstOrNull { it.id == id } }

    // ── перенос в сейф ──
    /**
     * Копирует и шифрует файлы. Оригиналы НЕ трогает: их удаляет вызывающий код через системный диалог,
     * и только если пользователь согласился. При ошибке откатывает всё, что успело скопироваться.
     * Возвращает пары (оригинал, id записи в сейфе).
     */
    fun import(ctx: Context, items: List<Item>, progress: (Int) -> Unit): List<Pair<Item, String>> {
        val d = dir ?: throw IOException("Сейф не инициализирован")
        val done = ArrayList<Pair<Item, String>>()
        for ((n, m) in items.withIndex()) {
            val id = UUID.randomUUID().toString()
            try {
                writeEnc(ctx, File(d, id)) { o ->
                    val ins = ctx.contentResolver.openInputStream(m.uri) ?: throw IOException("Не открыть ${m.name}")
                    ins.use { it.copyTo(o, 64 * 1024) }
                }
                val tb = runCatching { ctx.contentResolver.loadThumbnail(m.uri, Size(512, 512), null) }.getOrNull()
                if (tb != null) writeEnc(ctx, File(d, "$id.t")) { tb.compress(Bitmap.CompressFormat.JPEG, 86, it) }
                val mime = ctx.contentResolver.getType(m.uri) ?: if (m.video) "video/mp4" else "image/jpeg"
                synchronized(lock) {
                    recs += VRec(id, counter--, m.name, m.video, m.ms, m.size, m.w, m.h, m.album, m.dur, mime)
                }
                done += m to id
            } catch (e: Throwable) {
                File(d, id).delete(); File(d, "$id.t").delete()
                delete(ctx, done.map { it.second })
                throw e
            }
            progress(n + 1)
        }
        synchronized(lock) { save(ctx) }
        return done
    }

    // ── чтение ──
    fun thumb(ctx: Context, id: String): Bitmap? = runCatching {
        val b = readEnc(ctx, File(dir, "$id.t"))
        BitmapFactory.decodeByteArray(b, 0, b.size)
    }.getOrNull()

    /** Расшифровывает фото в память и сразу уменьшает до maxPx по длинной стороне. */
    fun decode(ctx: Context, id: String, maxPx: Int = 2048): Bitmap? = runCatching {
        val b = readEnc(ctx, File(dir, id))
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= maxPx) s *= 2
        BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
    }.getOrNull()

    /** Для воспроизведения видео расшифровываем во временный файл в кэше; кэш чистится при выходе. */
    fun videoFile(ctx: Context, id: String): File {
        val r = rec(id) ?: throw IOException("Нет записи")
        val ext = if (r.mime.contains("webm")) "webm" else if (r.mime.contains("3gpp")) "3gp" else "mp4"
        val out = File(ctx.cacheDir, "vp/$id.$ext")
        if (!out.exists()) {
            out.parentFile?.mkdirs()
            ef(ctx, File(dir, id)).openFileInput().use { i -> out.outputStream().use { i.copyTo(it, 64 * 1024) } }
        }
        return out
    }

    fun clearCache(ctx: Context) { File(ctx.cacheDir, "vp").deleteRecursively() }

    // ── возврат и удаление ──
    /** Возвращает файлы в системную галерею (Pictures/Восстановленные или Movies/Восстановленные) и удаляет их из сейфа. */
    fun restore(ctx: Context, ids: List<String>) {
        for (id in ids) {
            val r = rec(id) ?: continue
            val base = if (r.video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val dirName = if (r.video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, r.name)
                put(MediaStore.MediaColumns.MIME_TYPE, r.mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$dirName/Restored")
                put(MediaStore.MediaColumns.DATE_TAKEN, r.ms)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(base, cv) ?: throw IOException("Не удалось создать файл")
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { out ->
                    ef(ctx, File(dir, id)).openFileInput().use { it.copyTo(out, 64 * 1024) }
                } ?: throw IOException("Не удалось записать файл")
                ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (e: Throwable) {
                ctx.contentResolver.delete(uri, null, null)
                throw e
            }
            delete(ctx, listOf(id))
        }
        ThumbCache.evictVault()
    }

    fun delete(ctx: Context, ids: List<String>) {
        if (ids.isEmpty()) return
        val d = dir ?: return
        ids.forEach { File(d, it).delete(); File(d, "$it.t").delete() }
        synchronized(lock) {
            recs.removeAll { it.id in ids }
            save(ctx)
        }
        ThumbCache.evictVault()
    }
}
