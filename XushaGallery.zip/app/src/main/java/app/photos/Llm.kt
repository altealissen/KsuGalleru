package app.photos

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Готовые к скачиванию модели: открытые (Apache-2.0), не требуют входа в аккаунт, работают на телефоне офлайн. */
object Models {
    class Opt(val label: String, val sub: String, val url: String, val kind: String)

    private const val BASE = "https://huggingface.co/litert-community/"
    val Q15 = Opt(
        "Qwen 2.5 · 1.5B", "умнее, но медленнее · ≈1,6 ГБ",
        BASE + "Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task", "qwen"
    )
    val Q05 = Opt(
        "Qwen 2.5 · 0.5B", "быстро · ≈0,55 ГБ · рекомендую",
        BASE + "Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task", "qwen"
    )
}

/** Характер Ксюши и сборка диалога в формате, который понимает модель. */
object Persona {
    const val SYSTEM = "Ты Ксюша, милая аниме-девушка, ассистент фотогалереи. Отвечай по-русски, тепло и очень коротко " +
        "(1–3 предложения), иногда «ня». Ты видишь только метаданные и метки, не пиксели. Не выдумывай."

    val GREETING = "Привет! Я Ксюша ✦ Живу прямо в твоём телефоне, и твои фото никуда не уходят. Спрашивай что хочешь о галерее, ня!"

    /** turns: роли "user" / "assistant". */
    fun build(kind: String, system: String, turns: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        if (kind == "gemma") {
            // У Gemma нет роли system — вшиваем её в первую реплику пользователя.
            var sys = system
            for ((r, t) in turns) {
                sb.append("<start_of_turn>").append(if (r == "user") "user" else "model").append('\n')
                if (sys.isNotEmpty() && r == "user") { sb.append(sys).append("\n\n"); sys = "" }
                sb.append(t.trim()).append("<end_of_turn>\n")
            }
            sb.append("<start_of_turn>model\n")
        } else {
            sb.append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
            for ((r, t) in turns) sb.append("<|im_start|>").append(r).append('\n').append(t.trim()).append("<|im_end|>\n")
            sb.append("<|im_start|>assistant\n")
        }
        return sb.toString()
    }
}

/**
 * Нейросеть живёт в процессе приложения: никаких серверов. Единственный сетевой запрос во всём приложении —
 * разовая загрузка файла модели; ни фото, ни метки, ни вопросы никуда не отправляются.
 */
object LocalLlm {
    enum class S { NONE, LOADING, READY, ERROR }

    var state by mutableStateOf(S.NONE)
        private set
    var error by mutableStateOf("")
        private set

    private var engine: LlmInference? = null
    private val gate = Mutex()

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    fun file(ctx: Context) = File(ctx.filesDir, "model/xusha.task")
    fun installed(ctx: Context) = file(ctx).let { it.exists() && it.length() > 50_000_000L }

    var usingGpu by mutableStateOf(false)
        private set

    suspend fun load(ctx: Context, gpu: Boolean = false) {
        if (state == S.READY || state == S.LOADING) return
        state = S.LOADING; error = ""
        try {
            engine = withContext(Dispatchers.Default) {
                fun make(useGpu: Boolean): LlmInference {
                    val b = LlmInference.LlmInferenceOptions.builder()
                        .setModelPath(file(ctx).absolutePath)
                        .setMaxTokens(1024)       // меньше окно — меньше работы на каждый ответ
                        .setMaxTopK(40)
                    if (useGpu) runCatching {
                        val be = Class.forName("com.google.mediapipe.tasks.genai.llminference.LlmInference\$Backend")
                        val g = be.enumConstants!!.first { it.toString() == "GPU" }
                        b.javaClass.getMethod("setPreferredBackend", be).invoke(b, g)
                    }
                    return LlmInference.createFromOptions(ctx.applicationContext, b.build())
                }
                if (gpu) {
                    try { usingGpu = true; make(true) } catch (t: Throwable) { usingGpu = false; make(false) }
                } else { usingGpu = false; make(false) }
            }
            state = S.READY
        } catch (e: CancellationException) {
            state = S.NONE; throw e
        } catch (e: Throwable) {
            error = e.message ?: e.toString(); state = S.ERROR
        }
    }

    fun unload() {
        runCatching { engine?.close() }
        engine = null
        state = S.NONE
    }

    fun remove(ctx: Context) {
        unload()
        File(ctx.filesDir, "model").deleteRecursively()
    }

    private fun clean(s: String) = s.replace("<|im_end|>", "").replace("<end_of_turn>", "").replace("<|endoftext|>", "").trimStart()

    /**
     * Потоковая генерация: каждый элемент — весь текст, накопленный к этому моменту.
     * Отмена коллектора останавливает генерацию (если версия библиотеки это умеет), затем закрывает сессию.
     */
    fun generate(prompt: String): Flow<String> = callbackFlow {
        val eng = engine
        if (eng == null) { close(IllegalStateException("Ксюша ещё не проснулась")); return@callbackFlow }
        gate.lock()
        val finished = AtomicBoolean(false)
        val session = try {
            LlmInferenceSession.createFromOptions(
                eng,
                LlmInferenceSession.LlmInferenceSessionOptions.builder().setTopK(20).setTemperature(0.7f).build()
            )
        } catch (t: Throwable) {
            gate.unlock(); close(t); return@callbackFlow
        }
        val sb = StringBuilder()
        try {
            session.addQueryChunk(prompt)
            session.generateResponseAsync { part, done ->
                if (part != null) sb.append(part)
                trySend(clean(sb.toString()))
                if (done) { finished.set(true); close() }
            }
        } catch (t: Throwable) {
            finished.set(true); close(t)
        }
        awaitClose {
            // Закрываем сессию вне потока коллектора: если генерация ещё идёт, сначала просим её остановиться.
            Thread {
                if (!finished.get()) {
                    runCatching { session.javaClass.getMethod("cancelGenerateResponseAsync").invoke(session) }
                    val t0 = System.currentTimeMillis()
                    while (!finished.get() && System.currentTimeMillis() - t0 < 4000) Thread.sleep(50)
                }
                runCatching { session.close() }
                gate.unlock()
            }.start()
        }
    }

    // ── установка модели ──
    suspend fun download(ctx: Context, url: String, progress: (Long, Long) -> Unit) = withContext(Dispatchers.IO) {
        unload()
        val dir = file(ctx).parentFile!!.apply { mkdirs() }
        val part = File(dir, "xusha.part")
        val have = if (part.exists()) part.length() else 0L
        val req = Request.Builder().url(url).apply { if (have > 0) header("Range", "bytes=$have-") }.build()
        val call = client.newCall(req)
        val h = currentCoroutineContext()[Job]?.invokeOnCompletion { if (it != null) call.cancel() }
        try {
            call.execute().use { r ->
                when {
                    r.code == 416 -> Unit   // файл уже докачан
                    r.code == 200 || r.code == 206 -> {
                        val append = r.code == 206
                        val body = r.body ?: throw IllegalStateException("Пустой ответ сервера")
                        val len = body.contentLength().takeIf { it > 0 } ?: 0L
                        val total = if (len == 0L) 0L else len + (if (append) have else 0L)
                        var done = if (append) have else 0L
                        FileOutputStream(part, append).use { out ->
                            val src = body.source()
                            val buf = ByteArray(128 * 1024)
                            var last = 0L
                            while (true) {
                                ensureActive()
                                val n = src.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                val now = System.nanoTime()
                                if (now - last > 150_000_000L) {
                                    last = now
                                    withContext(Dispatchers.Main) { progress(done, total) }
                                }
                            }
                        }
                    }
                    r.code == 401 || r.code == 403 -> throw IllegalStateException("Доступ закрыт (${r.code}). Выбери файл модели вручную.")
                    r.code == 404 -> throw IllegalStateException("Файл не найден (404). Выбери файл модели вручную.")
                    else -> throw IllegalStateException("Ошибка сервера ${r.code}")
                }
            }
        } finally { h?.dispose() }
        if (part.length() < 50_000_000L) { part.delete(); throw IllegalStateException("Файл модели повреждён, попробуй ещё раз") }
        file(ctx).delete()
        if (!part.renameTo(file(ctx))) throw IllegalStateException("Не удалось сохранить модель")
    }

    /** Модель, уже лежащая на телефоне (.task) — копируем в приватную папку приложения. Возвращает имя файла. */
    suspend fun importFrom(ctx: Context, uri: Uri, progress: (Long, Long) -> Unit): String = withContext(Dispatchers.IO) {
        unload()
        var name = "model.task"
        var size = 0L
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst()) { name = it.getString(0) ?: name; size = it.getLong(1) }
        }
        val dir = file(ctx).parentFile!!.apply { mkdirs() }
        val part = File(dir, "xusha.part")
        var done = 0L
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            FileOutputStream(part).use { out ->
                val buf = ByteArray(128 * 1024)
                var last = 0L
                while (true) {
                    ensureActive()
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    val now = System.nanoTime()
                    if (now - last > 150_000_000L) { last = now; withContext(Dispatchers.Main) { progress(done, size) } }
                }
            }
        } ?: throw IllegalStateException("Не удалось открыть файл")
        if (part.length() < 50_000_000L) { part.delete(); throw IllegalStateException("Это не похоже на файл модели (.task)") }
        file(ctx).delete()
        if (!part.renameTo(file(ctx))) throw IllegalStateException("Не удалось сохранить модель")
        name
    }
}
