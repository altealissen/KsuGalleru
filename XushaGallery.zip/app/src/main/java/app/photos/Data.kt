package app.photos

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

// ───────────────────────────── даты ─────────────────────────────

private val formatters = ConcurrentHashMap<String, DateTimeFormatter>()

/** Потокобезопасный форматтер с кэшем. */
fun fmt(p: String, ms: Long): String {
    val loc = Locale.getDefault()
    val f = formatters.getOrPut(p + "|" + loc.toLanguageTag()) { DateTimeFormatter.ofPattern(p, loc) }
    return f.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))
}

/**
 * Один элемент галереи. Для файлов из сейфа vaultId != null, uri пустой, а id отрицательный —
 * так они никогда не пересекаются с id из MediaStore.
 */
data class Item(
    val id: Long, val uri: Uri, val name: String, val ms: Long, val video: Boolean,
    val size: Long, val w: Int, val h: Int, val album: String, val dur: Long,
    val vaultId: String? = null
) {
    val day: String = fmt("d MMMM yyyy", ms)

    /** Заголовок группы в сетке: 0 — по дням, 1 — по месяцам, 2 — по годам. */
    fun label(g: Int): String = when (g) { 1 -> fmt("LLLL yyyy", ms); 2 -> fmt("yyyy", ms); else -> day }
}

// ───────────────────────────── медиатека ─────────────────────────────

object Media {
    fun load(ctx: Context, trashed: Boolean = false): List<Item> {
        val proj = arrayOf(
            MediaStore.Files.FileColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.MEDIA_TYPE, MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME, MediaStore.MediaColumns.DURATION
        )
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (1,3)")
            putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, if (trashed) MediaStore.MATCH_ONLY else MediaStore.MATCH_EXCLUDE)
        }
        val out = ArrayList<Item>()
        val c = runCatching {
            ctx.contentResolver.query(MediaStore.Files.getContentUri("external"), proj, args, null)
        }.getOrNull() ?: return out
        c.use {
            out.ensureCapacity(c.count)
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val vid = c.getInt(2) == 3
                val taken = c.getLong(3)
                val added = c.getLong(4) * 1000
                val base = if (vid) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                out += Item(
                    id, ContentUris.withAppendedId(base, id), c.getString(1) ?: "",
                    if (taken > 0) taken else added, vid, c.getLong(5), c.getInt(6), c.getInt(7),
                    c.getString(8) ?: "", c.getLong(9)
                )
            }
        }
        out.sortByDescending { it.ms }
        return out
    }
}

/** LRU-кэш превью + ограничение параллельных декодирований. Превью сейфа расшифровываются здесь же. */
object ThumbCache {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 6).toInt().coerceAtMost(96 shl 20)
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val gate = Semaphore(4)

    fun peek(m: Item, px: Int): Bitmap? = cache.get("${m.id}:$px")

    /** Когда файл покидает сейф, его превью нужно убрать из памяти. */
    fun evictVault() { cache.snapshot().keys.filter { it.startsWith("-") }.forEach { cache.remove(it) } }

    suspend fun get(ctx: Context, m: Item, px: Int): Bitmap? {
        peek(m, px)?.let { return it }
        val b = gate.withPermit {
            withContext(Dispatchers.IO) {
                val vid = m.vaultId
                if (vid != null) Vault.thumb(ctx, vid)
                else runCatching { ctx.contentResolver.loadThumbnail(m.uri, Size(px, px), null) }.getOrNull()
            }
        } ?: return null
        cache.put("${m.id}:$px", b)
        return b
    }
}

// ───────────────────────────── хранилище настроек ─────────────────────────────

/** Человек или папка, собранные вручную: name + набор id фото. type = "person" | "folder". */
class UGroup(val id: String, val name: String, val type: String, val ids: Set<Long>)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("gallery", Context.MODE_PRIVATE)
    /** Метки и заметки лежат в отдельном файле: основной не раздувается тысячами ключей. */
    private val lp = ctx.getSharedPreferences("labels", Context.MODE_PRIVATE)

    init {
        if (!p.getBoolean("mig1", false)) {
            val e = p.edit()
            val le = lp.edit()
            for ((k, v) in p.all) {
                if (k.length > 1 && k[0] == 'l' && k.substring(1).all { it.isDigit() } && v is String) {
                    le.putString(k, v); e.remove(k)
                }
            }
            le.apply()
            e.putBoolean("mig1", true).apply()
        }
        // Старые версии хранили ключ DeepSeek — стираем: облака в приложении больше нет.
        if (p.contains("key") || p.contains("model") || p.contains("think")) {
            p.edit().remove("key").remove("model").remove("think").apply()
        }
    }

    fun ids(k: String): Set<Long> = (p.getStringSet(k, emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()

    /** Одна запись на всю пачку, а не по одной на каждое фото. */
    fun toggleAll(k: String, ids: List<Long>, on: Boolean) {
        val s = (p.getStringSet(k, emptySet()) ?: emptySet()).toMutableSet()
        ids.forEach { if (on) s.add(it.toString()) else s.remove(it.toString()) }
        p.edit().putStringSet(k, s).apply()
    }

    // ── безопасность ──
    fun hasPin(): Boolean = p.getString("pin_h", null) != null

    private fun hash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun ByteArray.hex() = joinToString("") { "%02x".format(it) }
    private fun String.unhex() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()

    /** Тяжёлая операция (PBKDF2, ~0.1 c): вызывать не на главном потоке. */
    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit().putString("pin_s", salt.hex()).putString("pin_h", hash(pin, salt).hex()).apply()
    }

    fun checkPin(pin: String): Boolean {
        val s = p.getString("pin_s", null) ?: return false
        val h = p.getString("pin_h", null) ?: return false
        return MessageDigest.isEqual(hash(pin, s.unhex()), h.unhex())
    }

    var bio: Boolean
        get() = p.getBoolean("bio", false)
        set(v) { p.edit().putBoolean("bio", v).apply() }

    var lockTrash: Boolean
        get() = p.getBoolean("lock_trash", false)
        set(v) { p.edit().putBoolean("lock_trash", v).apply() }

    var fails: Int
        get() = p.getInt("fails", 0)
        set(v) { p.edit().putInt("fails", v).apply() }

    var lockedUntil: Long
        get() = p.getLong("locked_until", 0L)
        set(v) { p.edit().putLong("locked_until", v).apply() }

    // ── люди и папки (виртуальные коллекции) ──
    fun groups(): List<UGroup> {
        val raw = p.getString("groups", null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val ids = o.getJSONArray("ids")
                UGroup(o.getString("id"), o.getString("name"), o.getString("type"), (0 until ids.length()).map { ids.getLong(it) }.toSet())
            }
        }.getOrDefault(emptyList())
    }

    private fun saveGroups(l: List<UGroup>) {
        val a = JSONArray()
        l.forEach { g -> a.put(JSONObject().put("id", g.id).put("name", g.name).put("type", g.type).put("ids", JSONArray(g.ids.toList()))) }
        p.edit().putString("groups", a.toString()).apply()
    }

    fun createGroup(name: String, type: String): String {
        val id = java.util.UUID.randomUUID().toString().take(8)
        saveGroups(groups() + UGroup(id, name.trim(), type, emptySet()))
        return id
    }

    fun deleteGroup(id: String) {
        saveGroups(groups().filter { it.id != id })
        setPinned(pinned().filter { it != "g:$id" })
    }

    fun renameGroup(id: String, name: String) =
        saveGroups(groups().map { if (it.id == id) UGroup(it.id, name.trim(), it.type, it.ids) else it })

    fun addToGroup(id: String, ids: Collection<Long>) =
        saveGroups(groups().map { if (it.id == id) UGroup(it.id, it.name, it.type, it.ids + ids) else it })

    fun removeFromGroup(id: String, ids: Collection<Long>) =
        saveGroups(groups().map { if (it.id == id) UGroup(it.id, it.name, it.type, it.ids - ids.toSet()) else it })

    /** Закреплённые коллекции в экране «Коллекции» (как в айфоне). */
    fun pinned(): List<String> {
        val raw = p.getString("pinned", null) ?: return listOf("fav", "recent", "video")
        return runCatching { val a = JSONArray(raw); (0 until a.length()).map { a.getString(it) } }.getOrDefault(emptyList())
    }

    fun setPinned(l: List<String>) { p.edit().putString("pinned", JSONArray(l).toString()).apply() }

    // ── ИИ ──
    /** Ускорение нейросети на GPU: быстрее, но на части телефонов не заводится (тогда сам вернёмся на процессор). */
    var useGpu: Boolean
        get() = p.getBoolean("use_gpu", false)
        set(v) { p.edit().putBoolean("use_gpu", v).apply() }

    /** "qwen" или "gemma": от этого зависит формат диалога для модели. */
    var modelKind: String
        get() = p.getString("model_kind", "qwen") ?: "qwen"
        set(v) { p.edit().putString("model_kind", v).apply() }

    var modelName: String
        get() = p.getString("model_name", "") ?: ""
        set(v) { p.edit().putString("model_name", v).apply() }

    fun label(id: Long): String? = lp.getString("l$id", null)
    fun setLabel(id: Long, v: String) = setLabels(mapOf(id to v))
    fun setLabels(m: Map<Long, String>) {
        if (m.isEmpty()) return
        val e = lp.edit()
        m.forEach { (id, v) -> e.putString("l$id", v) }
        e.apply()
    }

    /** Заметка (например, описание от Ксюши) — участвует в поиске. */
    fun note(id: Long): String? = lp.getString("n$id", null)
    fun setNote(id: Long, v: String) { lp.edit().putString("n$id", v).apply() }

    fun hay(m: Item): String = "${m.name} ${m.album} ${label(m.id).orEmpty()} ${note(m.id).orEmpty()}".lowercase()
}

// ───────────────────────────── локальная «умность» ─────────────────────────────

object Smart {
    /** Одинаковые размер в байтах + разрешение + длительность — почти наверняка копии. */
    fun duplicates(items: List<Item>): List<Item> =
        items.filter { it.size > 0 }
            .groupBy { Triple(it.size, it.w.toLong() * 100_000L + it.h, it.dur) }
            .values.filter { it.size > 1 }.flatten()
            .sortedWith(compareBy<Item> { it.size }.thenByDescending { it.ms })

    fun bigVideos(items: List<Item>, minBytes: Long = 200_000_000L): List<Item> =
        items.filter { it.video && it.size > minBytes }.sortedByDescending { it.size }

    /** Кадры, снятые в этот же день и месяц в прошлые годы. */
    fun onThisDay(items: List<Item>): List<Item> {
        val today = LocalDate.now()
        val zone = ZoneId.systemDefault()
        return items.filter {
            val d = Instant.ofEpochMilli(it.ms).atZone(zone).toLocalDate()
            d.monthValue == today.monthValue && d.dayOfMonth == today.dayOfMonth && d.year < today.year
        }
    }

    fun recent(items: List<Item>): List<Item> = items.take(100)

    fun panoramas(items: List<Item>): List<Item> = items.filter {
        !it.video && it.w > 0 && it.h > 0 && (it.w.toFloat() / it.h >= 2.4f || it.h.toFloat() / it.w >= 2.4f)
    }

    fun screenRecords(items: List<Item>): List<Item> = items.filter {
        it.video && (it.album.contains("screenrecord", true) || it.album.contains("запис", true) || it.name.startsWith("Screen", true))
    }

    /** «Подборка фото»: месяцы, в которые снято не меньше 6 кадров (свежие первыми). */
    fun memories(items: List<Item>): List<Pair<String, List<Item>>> =
        items.groupBy { fmt("LLLL yyyy", it.ms) }.entries.filter { it.value.size >= 6 }.take(10).map { it.key to it.value }

    fun isShot(m: Item) = m.album.contains("screenshot", true) || m.album.contains("скриншот", true) ||
        m.name.startsWith("Screenshot", true)
}

// ───────────────────────────── умный поиск без интернета ─────────────────────────────

data class Found(val items: List<Item>, val note: String)

/**
 * Разбирает запрос обычными словами («видео с морем прошлым летом») правилами, без облака и без нейросети:
 * мгновенно, предсказуемо и ничего не отправляет наружу. Русские слова переводятся в английские метки ML Kit.
 */
object QueryParser {
    private val zone get() = ZoneId.systemDefault()
    private fun ms(d: LocalDate) = d.atStartOfDay(zone).toInstant().toEpochMilli()

    /** Каждый месяц — отдельный шаблон «слово целиком», чтобы «май» не срабатывал на «машина». */
    private val monthNames = listOf("январь", "февраль", "март", "апрель", "май", "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь")
    private val monthRx = listOf(
        "январ\\p{L}*", "феврал\\p{L}*", "март\\p{L}*", "апрел\\p{L}*", "(май|мая|мае|маю)", "июн\\p{L}*",
        "июл\\p{L}*", "август\\p{L}*", "сентябр\\p{L}*", "октябр\\p{L}*", "ноябр\\p{L}*", "декабр\\p{L}*"
    ).map { Regex("(^|[^\\p{L}])$it($|[^\\p{L}])") }

    private val dict: List<Pair<Regex, List<String>>> = listOf(
        Regex("^мор|^океан") to listOf("sea", "beach", "ocean", "wave", "water", "coast"),
        Regex("^пляж") to listOf("beach", "sand", "sea", "coast"),
        Regex("^еда|^ед[ауы]|^ужин|^обед|^завтрак|^блюд|^пицц|^десерт") to listOf("food", "dish", "meal", "cuisine", "dessert", "pizza", "fast food"),
        Regex("^кош|^кот") to listOf("cat", "kitten", "whiskers", "pet"),
        Regex("^собак|^пёс|^пес|^щен") to listOf("dog", "puppy", "pet"),
        Regex("^животн|^зверь|^питом") to listOf("animal", "dog", "cat", "bird", "pet", "mammal"),
        Regex("^птиц") to listOf("bird", "beak"),
        Regex("^машин|^авто") to listOf("car", "vehicle", "wheel", "automotive"),
        Regex("^закат|^рассвет") to listOf("sunset", "sunrise", "sky", "dusk", "horizon"),
        Regex("^гор[аыуе]|^горн") to listOf("mountain", "hill", "peak", "mountainous"),
        Regex("^цвет") to listOf("flower", "petal", "plant", "bouquet"),
        Regex("^лес|^дерев|^деревь") to listOf("tree", "forest", "plant", "woodland"),
        Regex("^небо|^облак") to listOf("sky", "cloud", "cloudy"),
        Regex("^людь|^человек|^друз|^селфи|^портрет|^лиц") to listOf("person", "people", "face", "smile", "selfie", "portrait"),
        Regex("^ребен|^ребён|^дет|^малыш") to listOf("child", "toddler", "baby", "kid"),
        Regex("^здани|^дом|^город|^архитект") to listOf("building", "city", "architecture", "house", "skyscraper", "tower"),
        Regex("^ноч") to listOf("night", "darkness"),
        Regex("^снег|^зим") to listOf("snow", "winter", "ice", "frost"),
        Regex("^документ|^чек|^текст|^бумаг") to listOf("text", "document", "paper", "font", "handwriting"),
        Regex("^природ") to listOf("nature", "plant", "tree", "sky", "mountain", "grass", "landscape"),
        Regex("^озер|^озёр|^река|^рек[аи]|^вод") to listOf("lake", "river", "water", "pond"),
        Regex("^спорт|^трениров|^зал") to listOf("sport", "gym", "exercise", "fitness"),
        Regex("^музык|^концерт") to listOf("concert", "music", "stage", "guitar"),
        Regex("^самол|^аэро") to listOf("airplane", "aircraft", "airport", "sky"),
        Regex("^велосипед") to listOf("bicycle", "bike", "wheel"),
        Regex("^игр") to listOf("game", "toy", "screenshot")
    )

    private val dateWord = Regex(
        "^(сегодня|вчера|недел|месяц|год|году|года|лет|зим|весн|осен|прошл|эт(от|ой|ом|у|их)|последн|20\\d\\d|январ|феврал|март|апрел|ма[йяе]|июн|июл|август|сентябр|октябр|ноябр|декабр)"
    )
    private val stopWord = Regex(
        "^(видео|ролик|клип|фото|снимк|фотограф|картин|скрин|избран|любим|покаж|найд|все|мои|мо[ёе]|мой|фотк|без|для|или|при|про|где|что|как|мне|это|был|было|были|есть|the|and|with|show|find|photo|video)"
    )

    fun search(st: Store, q: String, items: List<Item>, favs: Set<Long>, people: List<UGroup> = emptyList()): Found {
        val low = q.lowercase().trim()
        val parts = ArrayList<String>()
        val today = LocalDate.now()

        var video: Boolean? = null
        if (Regex("видео|ролик|клип|video").containsMatchIn(low)) { video = true; parts += "видео" }
        else if (Regex("фото|снимк|картин|photo|picture").containsMatchIn(low)) { video = false; parts += "фото" }
        val shots = Regex("скриншот|скрин|screenshot").containsMatchIn(low)
        if (shots) { parts += "скриншоты"; video = null }
        val favOnly = Regex("избранн|любим|favorite").containsMatchIn(low)
        if (favOnly) parts += "избранное"

        // Имя человека из «Коллекций» в запросе («фото с Олечкой») ограничивает поиск его папкой.
        val personIds = HashSet<Long>()
        val usedStems = ArrayList<String>()
        for (g in people) {
            val nm = g.name.lowercase().trim()
            if (nm.length < 2) continue
            val stem = nm.take(maxOf(3, nm.length - 2))
            if (low.contains(stem)) { personIds += g.ids; usedStems += stem; parts += "человек: ${g.name}" }
        }

        var from: Long? = null
        var to: Long? = null
        fun range(a: LocalDate, b: LocalDate, label: String) { from = ms(a); to = ms(b); parts += label }

        val prev = low.contains("прошл")
        val month = monthRx.indexOfFirst { it.containsMatchIn(low) }
        val yearMatch = Regex("(20\\d\\d)").find(low)?.groupValues?.get(1)?.toIntOrNull()

        when {
            low.contains("сегодня") -> range(today, today.plusDays(1), "сегодня")
            low.contains("вчера") -> range(today.minusDays(1), today, "вчера")
            Regex("прошл\\p{L}* недел|на прошлой неделе").containsMatchIn(low) -> {
                val mon = today.with(DayOfWeek.MONDAY).minusWeeks(1); range(mon, mon.plusWeeks(1), "прошлая неделя")
            }
            Regex("эт\\p{L}* недел|за недел").containsMatchIn(low) -> {
                val mon = today.with(DayOfWeek.MONDAY); range(mon, mon.plusWeeks(1), "эта неделя")
            }
            Regex("прошл\\p{L}* месяц").containsMatchIn(low) -> {
                val s = today.withDayOfMonth(1).minusMonths(1); range(s, s.plusMonths(1), "прошлый месяц")
            }
            Regex("эт\\p{L}* месяц|за месяц").containsMatchIn(low) -> {
                val s = today.withDayOfMonth(1); range(s, s.plusMonths(1), "этот месяц")
            }
            month >= 0 -> {
                val mv = month + 1
                val y = yearMatch ?: if (mv > today.monthValue) today.year - 1 else today.year
                val s = LocalDate.of(y, mv, 1); range(s, s.plusMonths(1), "${monthNames[month]} $y")
            }
            Regex("(^|[^\\p{L}])зим").containsMatchIn(low) -> {
                val y = (if (today.monthValue == 12) today.year else today.year - 1) - (if (prev) 1 else 0)
                range(LocalDate.of(y, 12, 1), LocalDate.of(y + 1, 3, 1), "зима $y")
            }
            Regex("(^|[^\\p{L}])весн").containsMatchIn(low) -> {
                val y = (if (today.monthValue >= 3) today.year else today.year - 1) - (if (prev) 1 else 0)
                range(LocalDate.of(y, 3, 1), LocalDate.of(y, 6, 1), "весна $y")
            }
            Regex("(^|[^\\p{L}])(лето|летом|летний|летняя|летние)($|[^\\p{L}])").containsMatchIn(low) -> {
                val y = (if (today.monthValue >= 6) today.year else today.year - 1) - (if (prev) 1 else 0)
                range(LocalDate.of(y, 6, 1), LocalDate.of(y, 9, 1), "лето $y")
            }
            Regex("(^|[^\\p{L}])осен").containsMatchIn(low) -> {
                val y = (if (today.monthValue >= 9) today.year else today.year - 1) - (if (prev) 1 else 0)
                range(LocalDate.of(y, 9, 1), LocalDate.of(y, 12, 1), "осень $y")
            }
            Regex("прошл\\p{L}* год").containsMatchIn(low) -> range(LocalDate.of(today.year - 1, 1, 1), LocalDate.of(today.year, 1, 1), "${today.year - 1} год")
            Regex("эт\\p{L}* год|за год").containsMatchIn(low) -> range(LocalDate.of(today.year, 1, 1), LocalDate.of(today.year + 1, 1, 1), "${today.year} год")
            yearMatch != null -> range(LocalDate.of(yearMatch, 1, 1), LocalDate.of(yearMatch + 1, 1, 1), "$yearMatch год")
        }

        // Слова для поиска: всё, что не дата и не служебное. Каждое слово ищется как есть и через словарь меток.
        val groups: List<Pair<String, List<String>>> = low.split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { t -> t.length >= 3 && !dateWord.containsMatchIn(t) && !stopWord.containsMatchIn(t) && usedStems.none { t.startsWith(it) } }
            .map { tok ->
                val stem = if (tok.any { it in 'a'..'z' }) tok else tok.take(maxOf(3, tok.length - 3))
                val tags = dict.filter { it.first.containsMatchIn(tok) }.flatMap { it.second }
                stem to tags
            }
        if (groups.isNotEmpty()) parts += "слова: " + groups.joinToString(", ") { it.first }

        val scored = ArrayList<Pair<Item, Int>>()
        for (m in items) {
            if (video != null && video != m.video) continue
            if (shots && !Smart.isShot(m)) continue
            if (favOnly && m.id !in favs) continue
            if (usedStems.isNotEmpty() && m.id !in personIds) continue
            if (from != null && m.ms < from!!) continue
            if (to != null && m.ms >= to!!) continue
            if (groups.isEmpty()) { scored += m to 1; continue }
            val hay = st.hay(m)
            val s = groups.count { (stem, tags) -> hay.contains(stem) || tags.any { hay.contains(it) } }
            if (s > 0) scored += m to s
        }
        scored.sortWith(compareByDescending<Pair<Item, Int>> { it.second }.thenByDescending { it.first.ms })
        return Found(scored.map { it.first }, parts.joinToString(" · ").ifBlank { "без фильтров" })
    }
}

// ───────────────────────────── распознавание на устройстве ─────────────────────────────

object AI {
    private val labeler by lazy { ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS) }
    private val gate = Semaphore(3)

    /** Метки считаем по маленькому превью (480 px), а не по полноразмерному снимку. Всё локально, ML Kit работает офлайн. */
    private suspend fun labelOne(ctx: Context, m: Item): String? = gate.withPermit {
        runCatching {
            val bmp = withContext(Dispatchers.IO) { ctx.contentResolver.loadThumbnail(m.uri, Size(480, 480), null) }
            labeler.process(InputImage.fromBitmap(bmp, 0)).await()
                .filter { it.confidence > 0.6f }.take(8).joinToString { it.text }
        }.onFailure { if (it is CancellationException) throw it }.getOrNull()
    }

    suspend fun labels(ctx: Context, st: Store, m: Item): String {
        st.label(m.id)?.let { return it }
        if (m.video || m.vaultId != null) return ""
        val r = labelOne(ctx, m) ?: return ""
        st.setLabel(m.id, r)
        return r
    }

    /** Параллельная индексация (3 потока), запись на диск пачками по 25 фото. */
    suspend fun index(ctx: Context, st: Store, items: List<Item>, limit: Int = 500, progress: (Int, Int) -> Unit) =
        coroutineScope {
            val todo = items.filter { !it.video && st.label(it.id) == null }.take(limit)
            val cnt = AtomicInteger(0)
            val buf = ConcurrentHashMap<Long, String>()
            fun flush() {
                val snap = HashMap(buf)
                st.setLabels(snap)
                snap.keys.forEach { buf.remove(it) }
            }
            try {
                todo.map { m ->
                    async {
                        ensureActive()
                        labelOne(ctx, m)?.let { buf[m.id] = it }
                        val n = cnt.incrementAndGet()
                        if (n % 25 == 0) flush()
                        withContext(Dispatchers.Main) { progress(n, todo.size) }
                    }
                }.awaitAll()
            } finally { flush() }
        }

    /** Описание одного фото для Ксюши: метаданные и метки, но не пиксели. */
    suspend fun photoContext(ctx: Context, st: Store, m: Item): String {
        val l = labels(ctx, st, m)
        val note = st.note(m.id)
        return "Файл: ${m.name}; дата: ${fmt("d MMMM yyyy HH:mm", m.ms)}; тип: ${if (m.video) "видео" else "фото"}; " +
            "${m.w}x${m.h}; альбом: ${m.album}; метки: ${l.ifBlank { "нет" }}" +
            (if (note.isNullOrBlank()) "" else "; заметка: $note")
    }

    /** Очень короткая сводка для Ксюши: чем меньше токенов на входе, тем быстрее первый ответ. */
    fun summary(st: Store, items: List<Item>, favs: Set<Long>): String {
        val albums = items.groupBy { it.album }.entries.sortedByDescending { it.value.size }.take(3)
            .joinToString { "${it.key}: ${it.value.size}" }
        val labs = items.mapNotNull { st.label(it.id) }.flatMap { it.split(", ") }.filter { it.isNotBlank() }
            .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(5).joinToString { it.key }
        return "Всего ${items.size} (видео ${items.count { it.video }}), избранных ${favs.size}, скриншотов ${items.count { Smart.isShot(it) }}, " +
            "дублей ${Smart.duplicates(items).size}. Альбомы: $albums." + if (labs.isBlank()) "" else " Часто на фото: $labs."
    }
}
