@file:OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package app.photos

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Коллекция: умная («Видео», «Скриншоты»), папка устройства (b:), человек/папка пользователя (g:) или подборка (m:). */
class Aset(val key: String, val name: String, val items: List<Item>) {
    val mode: String get() = when {
        key == "vault" -> "vault"
        key == "trash" -> "trash"
        key.startsWith("g:") -> key
        else -> "normal"
    }
}

class Section(val key: String, val title: String, val sets: List<Aset>)

// ───────────────────────────── значки (рисуем сами, в духе Nothing) ─────────────────────────────

/** 0 — медиатека, 1 — коллекции, 2 — Ксюша (искра), 3 — фильтр. */
@Composable
fun NtIcon(kind: Int, tint: Color, modifier: Modifier = Modifier.size(26.dp)) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * 0.085f
        val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            0 -> {
                drawRoundRect(tint, Offset(w * .08f, w * .16f), Size(w * .84f, w * .68f), CornerRadius(w * .14f), style = st)
                drawCircle(tint, w * .06f, Offset(w * .34f, w * .38f))
                val p = Path().apply {
                    moveTo(w * .12f, w * .78f); lineTo(w * .40f, w * .54f); lineTo(w * .58f, w * .68f)
                    lineTo(w * .72f, w * .56f); lineTo(w * .88f, w * .74f)
                }
                drawPath(p, tint, style = st)
            }
            1 -> {
                drawLine(tint, Offset(w * .24f, w * .14f), Offset(w * .76f, w * .14f), sw, StrokeCap.Round)
                drawLine(tint, Offset(w * .16f, w * .28f), Offset(w * .84f, w * .28f), sw, StrokeCap.Round)
                drawRoundRect(tint, Offset(w * .08f, w * .40f), Size(w * .84f, w * .46f), CornerRadius(w * .12f), style = st)
            }
            2 -> {
                val p = Path().apply {
                    moveTo(w * .5f, w * .08f)
                    quadraticBezierTo(w * .55f, w * .45f, w * .92f, w * .5f)
                    quadraticBezierTo(w * .55f, w * .55f, w * .5f, w * .92f)
                    quadraticBezierTo(w * .45f, w * .55f, w * .08f, w * .5f)
                    quadraticBezierTo(w * .45f, w * .45f, w * .5f, w * .08f)
                    close()
                }
                drawPath(p, tint, style = st)
                drawCircle(tint, w * .05f, Offset(w * .82f, w * .2f))
            }
            else -> {
                drawLine(tint, Offset(w * .12f, w * .28f), Offset(w * .88f, w * .28f), sw, StrokeCap.Round)
                drawLine(tint, Offset(w * .26f, w * .5f), Offset(w * .74f, w * .5f), sw, StrokeCap.Round)
                drawLine(tint, Offset(w * .40f, w * .72f), Offset(w * .60f, w * .72f), sw, StrokeCap.Round)
            }
        }
    }
}

// ───────────────────────────── плавающая панель как в айфоне ─────────────────────────────

/** Слева «таблетка» с вкладками (Медиатека / Коллекции / Ксюша), справа отдельная круглая кнопка поиска. */
@Composable
fun FloatingBar(tab: Int, onTab: (Int) -> Unit) {
    val c = LocalNt.current
    val names = listOf("Медиатека", "Коллекции", "Ксюша")
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
        Arrangement.SpaceBetween, Alignment.CenterVertically
    ) {
        Row(
            Modifier.clip(RoundedCornerShape(36.dp)).background(c.surface.copy(alpha = 0.96f)).padding(5.dp)
        ) {
            names.forEachIndexed { i, n ->
                val sel = tab == i
                val tint by androidx.compose.animation.animateColorAsState(if (sel) c.red else c.dim, tween(200), label = "tabTint")
                val bg by androidx.compose.animation.animateColorAsState(if (sel) c.surface2 else Color.Transparent, tween(200), label = "tabBg")
                Column(
                    Modifier.width(96.dp).height(56.dp).clip(RoundedCornerShape(30.dp)).background(bg).pressable { onTab(i) },
                    Arrangement.Center, Alignment.CenterHorizontally
                ) {
                    NtIcon(i, tint, Modifier.size(24.dp))
                    Spacer(Modifier.height(3.dp))
                    Text(n, color = tint, fontFamily = Mono, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
        val sel = tab == 3
        val tint by androidx.compose.animation.animateColorAsState(if (sel) c.red else c.text, tween(200), label = "searchTint")
        Box(
            Modifier.size(66.dp).clip(CircleShape).background(c.surface.copy(alpha = 0.96f)).pressable { onTab(3) },
            Alignment.Center
        ) { Icon(Icons.Default.Search, null, tint = tint, modifier = Modifier.size(28.dp)) }
    }
}

// ───────────────────────────── карточки ─────────────────────────────

@Composable
private fun jiggle(editing: Boolean): Float {
    if (!editing) return 0f
    val t = rememberInfiniteTransition(label = "jiggle")
    val r by t.animateFloat(-1.3f, 1.3f, infiniteRepeatable(tween(120, easing = LinearEasing), RepeatMode.Reverse), label = "r")
    return r
}

/** badge: 0 — нет, 1 — открепить, 2 — удалить (показываются только в режиме «Изменить»). */
@Composable
fun CollectionCard(
    s: Aset, modifier: Modifier, coverHidden: Boolean, editing: Boolean, badge: Int,
    onClick: () -> Unit, onLong: () -> Unit, onBadge: () -> Unit
) {
    val c = LocalNt.current
    val rot = jiggle(editing)
    Box(modifier.graphicsLayer { rotationZ = rot }) {
        Box(
            Modifier.fillMaxSize().clip(RoundedCornerShape(22.dp)).background(c.surface2)
                .pressable(onLongClick = onLong, onClick = onClick)
        ) {
            val showCover = !coverHidden && s.items.isNotEmpty()
            if (showCover) {
                Thumb(s.items[0], Modifier.fillMaxSize(), 400)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .72f)))))
            } else Box(Modifier.align(Alignment.Center)) {
                if (s.key == "vault" || s.key == "trash" && coverHidden) Icon(Icons.Default.Lock, null, tint = c.dim, modifier = Modifier.size(34.dp))
                else NtIcon(0, c.dim, Modifier.size(38.dp))
            }
            Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
                Text(
                    s.name.uppercase(), color = if (showCover) Color.White else c.text,
                    fontFamily = Dot, fontSize = 14.sp, maxLines = 2, lineHeight = 16.sp
                )
                Spacer(Modifier.height(2.dp))
                Cap("${s.items.size}", color = if (showCover) Color.White.copy(alpha = .8f) else c.dim, size = 10.sp)
            }
        }
        if (editing && badge != 0) {
            Box(
                Modifier.align(Alignment.TopStart).offset((-4).dp, (-4).dp).size(28.dp).clip(CircleShape)
                    .background(c.red).pressable(onClick = onBadge),
                Alignment.Center
            ) { Icon(if (badge == 1) Icons.Default.Close else Icons.Default.Delete, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
        }
    }
}

@Composable
private fun NewCard(label: String, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalNt.current
    Column(
        modifier.clip(RoundedCornerShape(22.dp)).background(c.surface).pressable(onClick = onClick),
        Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Add, null, tint = c.red, modifier = Modifier.size(34.dp))
        Spacer(Modifier.height(6.dp))
        Cap(label, color = c.text)
    }
}

// ───────────────────────────── экран «Коллекции» ─────────────────────────────

@Composable
fun CollectionsScreen(
    sections: List<Section>, lockTrash: Boolean, editing: Boolean, collapsed: Set<String>, subtitle: String,
    onEditing: (Boolean) -> Unit, onToggle: (String) -> Unit,
    onOpen: (Aset) -> Unit, onSection: (Section) -> Unit,
    onLong: (Section, Aset) -> Unit, onBadge: (Section, Aset) -> Unit,
    onNew: (String) -> Unit, onSecurity: () -> Unit
) {
    val c = LocalNt.current
    var menu by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item(key = "head") {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    DotText("Коллекции", size = 30.sp)
                    Spacer(Modifier.height(2.dp))
                    Cap(subtitle)
                }
                Box {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(c.surface).pressable { menu = true }, Alignment.Center) {
                        Icon(Icons.Default.MoreVert, null, tint = c.text)
                    }
                    DropdownMenu(menu, { menu = false }, Modifier.background(c.surface)) {
                        DropdownMenuItem({ Text("Новый человек") }, { menu = false; onNew("person") })
                        DropdownMenuItem({ Text("Новая папка") }, { menu = false; onNew("folder") })
                        DropdownMenuItem({ Text("Защита и сейф") }, { menu = false; onSecurity() })
                    }
                }
            }
        }
        for (sec in sections) {
            val open = sec.key !in collapsed
            item(key = "t:${sec.key}") {
                val rot by animateFloatAsState(if (open) 0f else -90f, tween(220), label = "chev")
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 22.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(Modifier.weight(1f).pressable { onSection(sec) }, verticalAlignment = Alignment.CenterVertically) {
                        DotText(sec.title, size = 19.sp)
                        Icon(Icons.Default.KeyboardArrowRight, null, tint = c.dim)
                    }
                    if (sec.key == "pinned") {
                        Pill(if (editing) "Готово" else "Изменить", { onEditing(!editing) }, filled = editing)
                        Spacer(Modifier.width(8.dp))
                    }
                    Box(Modifier.size(40.dp).clip(CircleShape).background(c.surface).pressable { onToggle(sec.key) }, Alignment.Center) {
                        Icon(Icons.Default.KeyboardArrowDown, null, tint = c.red, modifier = Modifier.size(24.dp).graphicsLayer { rotationZ = rot })
                    }
                }
            }
            item(key = "r:${sec.key}") {
                AnimatedVisibility(open, enter = expandVertically(tween(240)) + fadeIn(tween(240)), exit = shrinkVertically(tween(220)) + fadeOut(tween(160))) {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(sec.sets, key = { it.key }) { s ->
                            val deletable = s.key.startsWith("b:") || s.key.startsWith("g:")
                            val badge = if (sec.key == "pinned") 1 else if (deletable) 2 else 0
                            CollectionCard(
                                s, Modifier.size(150.dp),
                                coverHidden = s.key == "vault" || (s.key == "trash" && lockTrash),
                                editing = editing, badge = badge,
                                onClick = { if (!editing) onOpen(s) }, onLong = { onLong(sec, s) }, onBadge = { onBadge(sec, s) }
                            )
                        }
                        if (sec.key == "people") item(key = "new-person") { NewCard("Человек", Modifier.size(150.dp)) { onNew("person") } }
                        if (sec.key == "folders") item(key = "new-folder") { NewCard("Папка", Modifier.size(150.dp)) { onNew("folder") } }
                    }
                }
            }
        }
        item(key = "hint") {
            Text(
                if (editing) "Минус открепляет, корзина удаляет папку. Зажми карточку — откроется меню."
                else "Зажми карточку — закрепить, переименовать или удалить.",
                Modifier.padding(horizontal = 20.dp, vertical = 18.dp), color = c.dim, fontSize = 12.sp
            )
        }
    }
}

/** Страница «все карточки секции» (шеврон рядом с названием). */
@Composable
fun SetsGrid(
    title: String, sets: List<Aset>, lockTrash: Boolean, editing: Boolean,
    onBack: () -> Unit, onOpen: (Aset) -> Unit, onLong: (Aset) -> Unit, onBadge: (Aset) -> Unit
) {
    val c = LocalNt.current
    LazyVerticalGrid(
        GridCells.Fixed(2), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 120.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = c.text) }
                Column {
                    DotText(title, size = 24.sp)
                    Cap("${sets.size} шт.")
                }
            }
        }
        gridItems(sets.size, key = { sets[it].key }) { i ->
            val s = sets[i]
            val deletable = s.key.startsWith("b:") || s.key.startsWith("g:")
            CollectionCard(
                s, Modifier.aspectRatio(1f).animateItemPlacement(),
                coverHidden = s.key == "vault" || (s.key == "trash" && lockTrash),
                editing = editing && deletable, badge = if (deletable) 2 else 0,
                onClick = { onOpen(s) }, onLong = { onLong(s) }, onBadge = { onBadge(s) }
            )
        }
    }
}

// ───────────────────────────── диалоги ─────────────────────────────

@Composable
fun NameDialog(title: String, initial: String, hint: String, onOk: (String) -> Unit, onClose: () -> Unit) {
    val c = LocalNt.current
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onClose, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
        title = { DotText(title, size = 20.sp) },
        text = {
            NtField(v, { v = it }, hint, Modifier.fillMaxWidth(), ime = ImeAction.Done, onAction = { if (v.isNotBlank()) onOk(v.trim()) })
        },
        confirmButton = { Pill("Готово", { if (v.isNotBlank()) onOk(v.trim()) }, filled = true, enabled = v.isNotBlank()) },
        dismissButton = { Pill("Отмена", onClose) }
    )
}

/** «Добавить в…»: выбрать существующего человека/папку или создать нового. */
@Composable
fun GroupPickerDialog(groups: List<UGroup>, count: Int, onPick: (UGroup) -> Unit, onNew: (String) -> Unit, onClose: () -> Unit) {
    val c = LocalNt.current
    AlertDialog(
        onDismissRequest = onClose, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
        title = { DotText("Добавить: $count", size = 20.sp) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                groups.forEach { g ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.surface2)
                            .pressable { onPick(g) }.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(g.name, color = c.text, modifier = Modifier.weight(1f), maxLines = 1)
                        Cap(if (g.type == "person") "человек" else "папка")
                    }
                }
                if (groups.isEmpty()) Text("Пока нет ни людей, ни папок. Создай первую.", color = c.dim, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("+ Человек", { onNew("person") }, filled = true)
                    Pill("+ Папка", { onNew("folder") })
                }
            }
        },
        confirmButton = { Pill("Закрыть", onClose) }
    )
}

/** Меню действий по долгому нажатию на карточку: (подпись, опасное?, действие). */
@Composable
fun ActionSheet(title: String, actions: List<Triple<String, Boolean, () -> Unit>>, onClose: () -> Unit) {
    val c = LocalNt.current
    AlertDialog(
        onDismissRequest = onClose, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
        title = { DotText(title, size = 18.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                actions.forEach { (label, danger, act) ->
                    Pill(label, { onClose(); act() }, Modifier.fillMaxWidth(), filled = danger)
                }
            }
        },
        confirmButton = { Pill("Отмена", onClose) }
    )
}

// ───────────────────────────── сборка коллекций ─────────────────────────────

/** Все коллекции по ключам: умные, папки устройства (b:), люди и папки пользователя (g:), подборки по месяцам (m:). */
fun buildCatalog(
    st: Store, all: List<Item>, favs: Set<Long>, trash: List<Item>, vault: List<Item>, groups: List<UGroup>
): Map<String, Aset> {
    val m = LinkedHashMap<String, Aset>()
    fun put(k: String, n: String, l: List<Item>) { m[k] = Aset(k, n, l) }
    fun lab(x: Item) = st.label(x.id)?.lowercase().orEmpty()
    put("fav", "Избранное", all.filter { it.id in favs })
    put("recent", "Сохранены недавно", Smart.recent(all))
    put("video", "Видео", all.filter { it.video })
    put("shots", "Скриншоты", all.filter { Smart.isShot(it) })
    put("pano", "Панорамы", Smart.panoramas(all))
    put("rec", "Записи экрана", Smart.screenRecords(all))
    put("selfie", "Селфи", all.filter { lab(it).contains("selfie") })
    put("faces", "С людьми", all.filter { val l = lab(it); l.contains("person") || l.contains("face") || l.contains("smile") || l.contains("people") })
    put("docs", "Документы", all.filter { val l = lab(it); l.contains("text") || l.contains("document") || l.contains("paper") })
    put("today", "В этот день", Smart.onThisDay(all))
    put("big", "Большие видео", Smart.bigVideos(all))
    put("dups", "Дубликаты", Smart.duplicates(all))
    put("vault", "Сейф", vault)
    put("trash", "Корзина", trash)
    all.groupBy { it.album }.forEach { (k, v) -> put("b:$k", k, v) }
    groups.forEach { g -> put("g:" + g.id, g.name, all.filter { it.id in g.ids }) }
    Smart.memories(all).forEach { (k, v) -> put("m:$k", k, v) }
    return m
}

fun buildSections(cat: Map<String, Aset>, groups: List<UGroup>, pinned: List<String>): List<Section> {
    val months = cat.values.filter { it.key.startsWith("m:") }
    val memories = listOfNotNull(cat["today"]?.takeIf { it.items.isNotEmpty() }) + months
    val types = listOf("video", "faces", "selfie", "pano", "shots", "rec", "docs").mapNotNull { cat[it] }
        .filter { it.items.isNotEmpty() || it.key == "video" || it.key == "shots" }
    val utils = listOf("dups", "big", "vault", "trash").mapNotNull { cat[it] }
        .filter { it.items.isNotEmpty() || it.key == "vault" || it.key == "trash" }
    return listOf(
        Section("pinned", "Закрепленные", pinned.mapNotNull { cat[it] }),
        Section("albums", "Альбомы", cat.values.filter { it.key.startsWith("b:") }.sortedByDescending { it.items.size }),
        Section("people", "Люди", groups.filter { it.type == "person" }.mapNotNull { cat["g:" + it.id] }),
        Section("folders", "Мои папки", groups.filter { it.type == "folder" }.mapNotNull { cat["g:" + it.id] }),
        Section("memories", "Подборка фото", memories),
        Section("types", "Типы медиафайлов", types),
        Section("utils", "Утилиты", utils)
    ).filter { it.sets.isNotEmpty() || it.key == "people" || it.key == "pinned" }
}
