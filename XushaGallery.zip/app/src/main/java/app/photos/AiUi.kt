@file:OptIn(ExperimentalLayoutApi::class)

package app.photos

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Состояние фоновой индексации живёт на уровне приложения: переключение вкладок её не прерывает. */
class IdxState {
    var running by mutableStateOf(false)
    var done by mutableIntStateOf(0)
    var total by mutableIntStateOf(0)
    var job: Job? = null
}

/** Установка модели тоже живёт на уровне приложения, чтобы скачивание не обрывалось при смене вкладки. */
class InstallState {
    var progress by mutableStateOf<Pair<Long, Long>?>(null)
    var error by mutableStateOf("")
    var version by mutableIntStateOf(0)
    var job: Job? = null
}

/** Текстовое поле в стиле Nothing: скруглённая «таблетка» без рамки. */
@Composable
fun NtField(
    value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier,
    singleLine: Boolean = true, ime: ImeAction = ImeAction.Default, onAction: () -> Unit = {}
) {
    val c = LocalNt.current
    BasicTextField(
        value, onChange,
        modifier = modifier.clip(RoundedCornerShape(24.dp)).background(c.surface).padding(horizontal = 16.dp, vertical = 12.dp),
        textStyle = TextStyle(color = c.text, fontSize = 15.sp),
        singleLine = singleLine,
        maxLines = if (singleLine) 1 else 4,
        cursorBrush = SolidColor(c.red),
        visualTransformation = VisualTransformation.None,
        keyboardOptions = KeyboardOptions(imeAction = ime),
        keyboardActions = KeyboardActions(onSearch = { onAction() }, onSend = { onAction() }, onDone = { onAction() }),
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) Text(placeholder, color = c.dim, fontSize = 15.sp, maxLines = 1)
                inner()
            }
        }
    )
}

// ───────────────────────────── Ксюша по одному фото ─────────────────────────────

@Composable
fun AiDialog(m: Item, st: Store, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val c = LocalNt.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var out by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    var ask by remember { mutableStateOf("") }
    var job by remember { mutableStateOf<Job?>(null) }
    val ready = LocalLlm.state == LocalLlm.S.READY
    val tasks = listOf(
        "Описание" to "Напиши красивое описание этого фото в 2 предложениях.",
        "Теги" to "Дай 10 тегов через запятую для поиска этого фото.",
        "Подпись" to "Напиши 3 варианта подписи для соцсетей с хэштегами.",
        "Воспоминание" to "Придумай короткое название воспоминания для этого момента.",
        "Обработка" to "Дай 3 совета по обработке (цвет, кадрирование, фильтр) исходя из данных.",
        "English" to "Write a short English caption for this photo.",
        "Мини-рассказ" to "Придумай мини-рассказ из 3 предложений по этому кадру, опираясь только на данные.",
        "Имя файла" to "Предложи 3 понятных имени файла латиницей через подчёркивание."
    )

    fun runTask(task: String) {
        if (!ready) { out = "Ксюша ещё не готова: установи её или дождись загрузки во вкладке «Ксюша»."; return }
        job?.cancel()
        busy = true; out = ""; saved = false
        job = scope.launch {
            try {
                val meta = AI.photoContext(ctx, st, m)
                val prompt = Persona.build(st.modelKind, Persona.SYSTEM, listOf("user" to "$task\n\nДанные: $meta"))
                LocalLlm.generate(prompt).collect { out = it }
            } catch (e: CancellationException) {
            } catch (e: Exception) {
                out = "Ошибка: ${e.message ?: e.toString()}"
            } finally { busy = false }
        }
    }

    AlertDialog(
        onDismissRequest = { job?.cancel(); onClose() },
        containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
        confirmButton = { Pill("Закрыть", { job?.cancel(); onClose() }, filled = true) },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                XushaAvatar(Modifier.width(40.dp), if (busy) (if (out.isEmpty()) Mood.THINK else Mood.TALK) else Mood.IDLE)
                Spacer(Modifier.width(10.dp))
                DotText("Ксюша", size = 20.sp)
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    tasks.forEach { (n, p) -> Pill(n, { runTask(p) }, enabled = !busy) }
                }
                Spacer(Modifier.height(12.dp))
                NtField(
                    ask, { ask = it }, "Свой вопрос об этом кадре", Modifier.fillMaxWidth(),
                    ime = ImeAction.Send, onAction = { if (ask.isNotBlank() && !busy) { runTask(ask.trim()); ask = "" } }
                )
                if (busy) { Spacer(Modifier.height(14.dp)); DotProgress() }
                if (out.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    SelectionContainer { Text(out, color = c.text) }
                }
                if (out.isNotBlank() && !busy && !out.startsWith("Ошибка") && !out.startsWith("Ксюша ещё")) {
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Копировать", { clip.setText(AnnotatedString(out)) })
                        // Сохранённый ответ попадает в заметку фото и находится обычным поиском.
                        Pill(if (saved) "Сохранено" else "В поиск", { st.setNote(m.id, out.take(500)); saved = true }, enabled = !saved)
                    }
                }
            }
        }
    )
}

// ───────────────────────────── поиск ─────────────────────────────

private suspend fun localSearch(st: Store, q: String, items: List<Item>): List<Item> = withContext(Dispatchers.Default) {
    val ws = q.trim().lowercase().split(' ').filter { it.isNotBlank() }
    items.filter { m -> val hay = st.hay(m); ws.all { hay.contains(it) } }
}

@Composable
fun SearchTab(
    st: Store, items: List<Item>, favs: Set<Long>, h: Host, people: List<UGroup>,
    initialQuery: String, initialKey: Int, onSelMode: (Boolean) -> Unit
) {
    val c = LocalNt.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var smart by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var res by remember { mutableStateOf<List<Item>?>(null) }
    var note by remember { mutableStateOf("") }
    val examples = listOf("Видео за прошлый месяц", "Скриншоты этого года", "Избранное с едой", "Фото с животными летом", "Фото с Олечкой")

    fun go(query: String) {
        if (query.isBlank()) return
        busy = true; note = ""
        scope.launch {
            try {
                if (smart) {
                    val f = withContext(Dispatchers.Default) { QueryParser.search(st, query, items, favs, people) }
                    res = f.items; note = f.note
                } else res = localSearch(st, query, items)
            } finally { busy = false }
        }
    }

    // Запрос может прийти от Ксюши («найди скриншоты за месяц») — выполняем сразу.
    LaunchedEffect(initialKey) {
        if (initialQuery.isNotBlank()) { q = initialQuery; smart = true; go(initialQuery) }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            NtField(
                q, { q = it }, if (smart) "Видео с морем прошлым летом" else "Название, альбом, метка",
                Modifier.weight(1f), ime = ImeAction.Search, onAction = { go(q) }
            )
            Spacer(Modifier.width(8.dp))
            Pill("Умный", { smart = !smart }, filled = smart)
        }
        if (busy) DotProgress(Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        AnimatedVisibility(note.isNotEmpty(), enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
            Text(
                "Поняла так: $note", Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                color = c.dim, fontFamily = Mono, fontSize = 11.sp, maxLines = 2
            )
        }
        val r = res
        if (r == null) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                DotText("Поиск", size = 30.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Ищите по названию, альбому, меткам и заметкам. В умном режиме пишите обычными словами: даты, «видео», «скриншоты», «избранное» " +
                        "и предметы на фото я пойму сама, прямо на телефоне.",
                    color = c.dim
                )
                Spacer(Modifier.height(20.dp))
                Cap("Попробуйте")
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    examples.forEach { e -> Pill(e, { q = e; smart = true; go(e) }) }
                }
            }
        } else {
            // Массовые действия над результатом умного запроса: «убери все скриншоты старше года» и т.п.
            if (smart && r.isNotEmpty()) Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("В избранное", { h.fav(r) })
                Pill("В сейф", { h.toVault(r) })
                Pill("В корзину", { h.trash(r, true) })
            }
            GridScreen("Найдено", r, favs, "normal", h, onSelMode = onSelMode)
        }
    }
}

// ───────────────────────────── вкладка Ксюши ─────────────────────────────

@Composable
fun AiTab(
    st: Store, items: List<Item>, favs: Set<Long>,
    msgs: SnapshotStateList<Pair<String, String>>, idx: IdxState, inst: InstallState, appScope: CoroutineScope,
    onIndex: () -> Unit, onStopIndex: () -> Unit, onSearch: (String) -> Unit
) {
    val ctx = LocalContext.current
    val c = LocalNt.current
    val scope = rememberCoroutineScope()
    val installed = remember(inst.version) { LocalLlm.installed(ctx) }
    val llm = LocalLlm.state
    var settings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    val pending = remember(items, idx.running) { items.count { !it.video && st.label(it.id) == null } }

    // Модель грузим в области приложения: уход с вкладки не должен бросать загрузку на полпути.
    LaunchedEffect(installed, llm) {
        if (installed && llm == LocalLlm.S.NONE) appScope.launch { LocalLlm.load(ctx, st.useGpu) }
    }

    fun startInstall(block: suspend () -> Pair<String, String>) {
        if (inst.job?.isActive == true) return
        inst.error = ""; inst.progress = 0L to 0L
        inst.job = appScope.launch {
            try {
                val (kind, name) = block()
                st.modelKind = kind; st.modelName = name
                inst.version++
            } catch (e: CancellationException) {
            } catch (e: Throwable) {
                inst.error = e.message ?: e.toString()
            } finally { inst.progress = null }
        }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) startInstall {
            val n = LocalLlm.importFrom(ctx, uri) { a, b -> inst.progress = a to b }
            (if (n.contains("gemma", true)) "gemma" else "qwen") to n
        }
    }

    fun send(t: String) {
        if (busy) return
        // «Найди/покажи …» — это поиск, а не разговор: решаем мгновенно правилами, нейросеть не нужна.
        val m = Regex("^\\s*(найди|найти|покажи|показать|поищи|где)\\s+(.+)", RegexOption.IGNORE_CASE).find(t)
        if (m != null) {
            msgs += "user" to t
            msgs += "assistant" to "Ищу «${m.groupValues[2].trim()}» — открываю результаты, ня!"
            onSearch(m.groupValues[2].trim())
            return
        }
        if (LocalLlm.state != LocalLlm.S.READY) return
        msgs += "user" to t
        // Окно контекста у маленькой модели всего 1280 токенов, поэтому историю режем жёстко.
        val hist = msgs.toList().filter { it.second.isNotBlank() && !it.second.startsWith("Ошибка") }
            .takeLast(2).map { (r, x) -> r to x.take(240) }
        msgs += "assistant" to ""
        val at = msgs.lastIndex
        busy = true
        job = scope.launch {
            try {
                val sys = withContext(Dispatchers.Default) { Persona.SYSTEM + "\nДанные галереи:\n" + AI.summary(st, items, favs) }
                LocalLlm.generate(Persona.build(st.modelKind, sys, hist)).collect { msgs[at] = "assistant" to it }
            } catch (e: CancellationException) {
            } catch (e: Exception) {
                msgs[at] = "assistant" to "Ошибка: ${e.message ?: e.toString()}"
            } finally { busy = false }
        }
    }

    val presets = listOf(
        "Воспоминания" to "Придумай 3 «воспоминания» (название и короткий текст) по годам и меткам моей библиотеки.",
        "В этот день" to "Расскажи, что у меня есть «в этот день» за прошлые годы.",
        "Умные альбомы" to "Предложи 5 умных альбомов по частым меткам и опиши критерии.",
        "Чистка" to "Дай советы по очистке библиотеки: скриншоты, большие видео, дубли. Используй цифры из данных.",
        "Итоги" to "Составь краткие итоги моей фото-активности по годам.",
        "Идеи съёмки" to "Предложи 5 идей для новых съёмок по тому, что я обычно снимаю."
    )

    val lastEmpty = msgs.lastOrNull()?.second.isNullOrEmpty()
    val mood = if (busy) (if (lastEmpty) Mood.THINK else Mood.TALK) else Mood.IDLE

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            XushaAvatar(Modifier.width(60.dp), mood)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                DotText("Ксюша", size = 26.sp)
                Cap(
                    when {
                        !installed -> "нужен «мозг»"
                        llm == LocalLlm.S.LOADING || llm == LocalLlm.S.NONE -> "просыпается…"
                        llm == LocalLlm.S.ERROR -> "не получилось"
                        busy -> "печатает…"
                        else -> "на связи · офлайн"
                    }
                )
            }
            if (installed) Pill("Настройки", { settings = !settings }, filled = settings)
        }

        if (!installed) {
            Onboarding(inst,
                onModel = { o ->
                    startInstall {
                        LocalLlm.download(ctx, o.url) { a, b -> inst.progress = a to b }
                        o.kind to o.label
                    }
                },
                onPick = { pick.launch(arrayOf("*/*")) })
            return@Column
        }

        AnimatedVisibility(settings, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
            Column(Modifier.padding(bottom = 10.dp)) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(c.surface).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Cap("Модель на устройстве")
                            Text(st.modelName.ifBlank { "установлена" }, color = c.text, fontFamily = Mono, fontSize = 13.sp)
                        }
                        Pill("Удалить", { job?.cancel(); LocalLlm.remove(ctx); msgs.clear(); inst.version++ })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Cap("Ускорение GPU · эксперимент")
                            Text(
                                if (LocalLlm.usingGpu) "Работает на GPU" else "Быстрее на новых телефонах; не заведётся — вернусь на процессор",
                                color = c.text, fontSize = 12.sp
                            )
                        }
                        var gpu by remember { mutableStateOf(st.useGpu) }
                        Pill(if (gpu) "Вкл" else "Выкл", {
                            gpu = !gpu; st.useGpu = gpu
                            appScope.launch { LocalLlm.unload(); LocalLlm.load(ctx, gpu) }
                        }, filled = gpu)
                    }
                    Text(
                        "Нейросеть работает прямо в телефоне. Фото, метки и вопросы никуда не отправляются: интернет нужен только для разовой загрузки модели.",
                        color = c.dim, fontSize = 12.sp
                    )
                    if (idx.running) {
                        Column {
                            DotProgress(fraction = if (idx.total == 0) 0f else idx.done.toFloat() / idx.total)
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Cap("Анализ ${idx.done} / ${idx.total}", Modifier.weight(1f))
                                Pill("Стоп", onStopIndex)
                            }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Cap("Распознавание на устройстве")
                                Text(if (pending == 0) "Все фото проанализированы" else "Ждут анализа: $pending", color = c.text, fontSize = 13.sp)
                            }
                            Pill("Анализ", onIndex, filled = true, enabled = pending > 0)
                        }
                    }
                }
            }
        }

        if (llm == LocalLlm.S.ERROR) {
            Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Не удалось запустить модель: ${LocalLlm.error}", color = c.red, fontSize = 13.sp)
                Text("Возможно, не хватает памяти или файл модели не подходит. Попробуй модель поменьше (0.5B).", color = c.dim, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Повторить", { appScope.launch { LocalLlm.unload(); LocalLlm.load(ctx, st.useGpu) } }, filled = true)
                    Pill("Удалить модель", { LocalLlm.remove(ctx); inst.version++ })
                }
            }
        } else if (llm != LocalLlm.S.READY) {
            Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                DotProgress()
                Spacer(Modifier.height(8.dp))
                Cap("Ксюша просыпается… первый запуск занимает до минуты")
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (msgs.isNotEmpty()) item { Pill("Очистить", { job?.cancel(); msgs.clear() }) }
            items(presets) { (n, p) -> Pill(n, { send(p) }, enabled = !busy && llm == LocalLlm.S.READY) }
        }

        val ls = rememberLazyListState()
        LaunchedEffect(msgs.size, msgs.lastOrNull()?.second?.length) {
            if (msgs.isNotEmpty()) ls.animateScrollToItem(msgs.lastIndex)
        }
        if (msgs.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), Arrangement.Center) {
                Row(Modifier.fillMaxWidth()) {
                    RedDot(Modifier.padding(top = 8.dp, end = 10.dp))
                    Text(Persona.GREETING, color = c.text)
                }
                Spacer(Modifier.height(10.dp))
                Text("Я вижу метаданные и метки распознавания, но не сами пиксели.", color = c.dim, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), state = ls,
                verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 14.dp)
            ) {
                items(msgs.size) { i ->
                    val (role, text) = msgs[i]
                    if (role == "user") Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Box(Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(20.dp)).background(c.surface2).padding(horizontal = 14.dp, vertical = 10.dp)) {
                            Text(text, color = c.text)
                        }
                    } else Row(Modifier.fillMaxWidth()) {
                        RedDot(Modifier.padding(top = 8.dp, end = 10.dp))
                        if (text.isEmpty()) DotProgress(Modifier.weight(1f).padding(top = 4.dp))
                        else SelectionContainer(Modifier.weight(1f)) { Text(text, color = c.text) }
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            NtField(
                input, { input = it }, "Спроси Ксюшу о галерее", Modifier.weight(1f), singleLine = false,
                ime = ImeAction.Send, onAction = { if (input.isNotBlank()) { send(input.trim()); input = "" } }
            )
            Spacer(Modifier.width(8.dp))
            if (busy) Pill("Стоп", { job?.cancel() })
            else Box(
                Modifier.size(48.dp).clip(CircleShape).background(if (llm == LocalLlm.S.READY) c.red else c.surface2)
                    .pressable(enabled = llm == LocalLlm.S.READY) { if (input.isNotBlank()) { send(input.trim()); input = "" } },
                Alignment.Center
            ) { Icon(Icons.Default.Send, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
        }
    }
}

/** Первый запуск: Ксюше нужен «мозг» — выбираем, скачать или взять уже лежащий на телефоне файл. */
@Composable
private fun Onboarding(inst: InstallState, onModel: (Models.Opt) -> Unit, onPick: () -> Unit) {
    val c = LocalNt.current
    val p = inst.progress
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.Center) {
            XushaAvatar(Modifier.width(170.dp), if (p != null) Mood.THINK else Mood.IDLE)
        }
        Spacer(Modifier.height(10.dp))
        DotText("Привет!", size = 30.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Я Ксюша, ИИ-ассистент твоей галереи. Чтобы я заработала, нужно один раз загрузить маленькую нейросеть. " +
                "Она бесплатная и живёт прямо в телефоне: после загрузки интернет не нужен, а твои фото и вопросы никуда не уходят.",
            color = c.dim
        )
        Spacer(Modifier.height(16.dp))

        if (p != null) {
            Cap(if (p.second > 0) "Загрузка %.0f / %.0f МБ".format(p.first / 1e6, p.second / 1e6) else "Копирую… %.0f МБ".format(p.first / 1e6))
            Spacer(Modifier.height(8.dp))
            DotProgress(fraction = if (p.second > 0) (p.first.toFloat() / p.second).coerceIn(0f, 1f) else null)
            Spacer(Modifier.height(12.dp))
            Pill("Отмена", { inst.job?.cancel() })
        } else {
            for (o in listOf(Models.Q15, Models.Q05)) {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(24.dp)).background(c.surface)
                        .pressable { onModel(o) }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        DotText(o.label, size = 17.sp)
                        Spacer(Modifier.height(2.dp))
                        Cap(o.sub)
                    }
                    RedDot(size = 10.dp)
                }
            }
            Pill("Выбрать файл .task с телефона", onPick)
            Spacer(Modifier.height(10.dp))
            Text("Рекомендую 1.5B, если в телефоне 8 ГБ памяти и больше. Загружай по Wi-Fi.", color = c.dim, fontSize = 12.sp)
        }
        if (inst.error.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(inst.error, color = c.red, fontSize = 13.sp)
        }
    }
}
