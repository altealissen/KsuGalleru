package app.photos

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

enum class Mood { IDLE, TALK, THINK }

private const val COLS = 40
private const val ROWS = 44

// Коды ячеек точечной матрицы
private const val NONE: Byte = 0
private const val SKIN: Byte = 1   // мелкие бледные точки — кожа
private const val HAIR: Byte = 2   // крупные точки — волосы
private const val RED: Byte = 3    // красный акцент Nothing — глаза, румянец, заколки
private const val LINE: Byte = 4   // линии — брови, рот, нос, контур глаз

private fun ell(x: Float, y: Float, cx: Float, cy: Float, rx: Float, ry: Float): Boolean {
    val a = (x - cx) / rx
    val b = (y - cy) / ry
    return a * a + b * b <= 1f
}

private fun eyeDist(x: Float, y: Float, cx: Float, cy: Float, rx: Float, ry: Float): Float {
    val a = (x - cx) / rx
    val b = (y - cy) / ry
    return a * a + b * b
}

/** Пилообразная «чёлка»: зубчики на лбу. */
private fun fringe(x: Float): Float {
    val a = (x * 7f) % 1f
    return 0.40f + 0.07f * (abs(a - 0.5f) * 2f)
}

private fun classify(u: Float, v: Float, blink: Boolean, mouth: Int, mood: Mood, phase: Int): Byte {
    val x = u
    val y = v * (ROWS.toFloat() / COLS)   // переводим в «квадратные» единицы: ячейки на экране квадратные

    // Мысли: три пульсирующие красные точки справа сверху
    if (mood == Mood.THINK) {
        for (k in 0..2) {
            if (ell(x, y, 0.80f + k * 0.07f, 0.08f, 0.028f, 0.028f) && k <= phase) return RED
        }
    }

    val eyeY = 0.64f
    val eyeRx = 0.062f
    val eyeRy = 0.078f
    val lx = 0.385f
    val rx = 0.615f

    val hairBack = ell(x, y, 0.5f, 0.52f, 0.43f, 0.50f) && (y < 0.80f || abs(x - 0.5f) > 0.26f)
    val tails = ell(x, y, 0.085f, 0.80f, 0.075f, 0.26f) || ell(x, y, 0.915f, 0.80f, 0.075f, 0.26f)
    val face = ell(x, y, 0.5f, 0.62f, 0.28f, 0.34f)
    val skin = face && y >= fringe(x) && !(abs(x - 0.5f) > 0.235f && y < 0.82f)

    // Красные заколки
    if (ell(x, y, 0.135f, 0.50f, 0.034f, 0.034f) || ell(x, y, 0.865f, 0.50f, 0.034f, 0.034f)) return RED

    if (skin) {
        // Глаза
        for (cx in floatArrayOf(lx, rx)) {
            val d = eyeDist(x, y, cx, eyeY, eyeRx, eyeRy)
            if (blink) {
                if (abs(x - cx) < eyeRx && abs(y - (eyeY + 0.012f + 1.6f * (x - cx) * (x - cx))) < 0.012f) return LINE
            } else if (d <= 1f) {
                if (ell(x, y, cx - 0.02f, eyeY - 0.03f, 0.014f, 0.014f)) return NONE   // блик
                return if (d > 0.72f) LINE else RED
            }
        }
        // Брови
        if (abs(y - 0.545f) < 0.009f && ((x > 0.335f && x < 0.435f) || (x > 0.565f && x < 0.665f))) return LINE
        // Румянец
        if (ell(x, y, 0.33f, 0.76f, 0.05f, 0.022f) || ell(x, y, 0.67f, 0.76f, 0.05f, 0.022f)) return RED
        // Нос
        if (ell(x, y, 0.5f, 0.755f, 0.012f, 0.012f)) return LINE
        // Рот
        when (mouth) {
            0 -> if (abs(x - 0.5f) < 0.06f && abs(y - (0.815f + 14f * (x - 0.5f) * (x - 0.5f))) < 0.012f) return LINE
            1 -> if (ell(x, y, 0.5f, 0.835f, 0.032f, 0.016f)) return LINE
            else -> if (ell(x, y, 0.5f, 0.84f, 0.04f, 0.03f)) return LINE
        }
        return SKIN
    }
    if (hairBack || tails) return HAIR
    return NONE
}

private fun buildGrid(blink: Boolean, mouth: Int, mood: Mood, phase: Int): ByteArray {
    val g = ByteArray(COLS * ROWS)
    for (j in 0 until ROWS) for (i in 0 until COLS) {
        g[j * COLS + i] = classify((i + 0.5f) / COLS, (j + 0.5f) / ROWS, blink, mouth, mood, phase)
    }
    return g
}

/**
 * Ксюша — аниме-девушка, нарисованная точечной матрицей в духе Nothing: волосы — крупные точки,
 * кожа — бледные, красные глаза и заколки. Моргает, «дышит», шевелит ртом во время ответа и «думает» точками.
 */
@Composable
fun XushaAvatar(modifier: Modifier = Modifier, mood: Mood = Mood.IDLE) {
    val c = LocalNt.current
    val t by rememberInfiniteTransition(label = "xusha").animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "t"
    )
    var blink by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(Random.nextLong(2200, 5200))
            blink = true
            delay(150)
            blink = false
        }
    }
    // Эти значения меняются редко, поэтому перекомпоновка идёт только при смене, а не на каждом кадре.
    val mouth by remember(mood) {
        derivedStateOf { if (mood == Mood.TALK) (abs(sin(t * 2f * PI.toFloat() * 4f)) * 2.99f).toInt() else 0 }
    }
    val phase by remember(mood) { derivedStateOf { if (mood == Mood.THINK) (t * 3.99f).toInt() else 0 } }
    val grid = remember(blink, mouth, mood, phase) { buildGrid(blink, mouth, mood, phase) }

    Canvas(modifier.aspectRatio(COLS.toFloat() / ROWS)) {
        val step = size.width / COLS
        val bob = sin(t * 2f * PI.toFloat()) * step * 0.45f   // лёгкое «дыхание»
        for (j in 0 until ROWS) {
            val shade = 1f - j.toFloat() / ROWS * 0.45f
            for (i in 0 until COLS) {
                val code = grid[j * COLS + i]
                if (code == NONE) continue
                val center = Offset(step * (i + 0.5f), step * (j + 0.5f) + bob)
                when (code) {
                    SKIN -> drawCircle(c.text.copy(alpha = 0.20f), step * 0.16f, center)
                    HAIR -> drawCircle(c.text.copy(alpha = 0.55f + 0.45f * shade), step * (0.20f + 0.18f * shade), center)
                    RED -> drawCircle(c.red, step * 0.38f, center)
                    LINE -> drawCircle(c.text, step * 0.30f, center)
                }
            }
        }
    }
}
