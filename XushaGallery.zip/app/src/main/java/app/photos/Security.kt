package app.photos

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.keyframes
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class LockMode { ENTER, SETUP, CHANGE }

fun bioAvailable(ctx: Context): Boolean =
    BiometricManager.from(ctx).canAuthenticate(BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

fun bioPrompt(act: FragmentActivity, title: String, ok: () -> Unit) {
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setNegativeButtonText("ПИН-код")
        .setAllowedAuthenticators(BIOMETRIC_WEAK)
        .build()
    BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { ok() }
    }).authenticate(info)
}

@Composable
private fun PadKey(label: String, onClick: () -> Unit) {
    val c = LocalNt.current
    Box(
        Modifier.size(76.dp).clip(CircleShape).background(c.surface).pressable(onClick = onClick),
        Alignment.Center
    ) { Text(label, color = c.text, fontFamily = Mono, fontSize = 26.sp) }
}

/**
 * Экран ПИН-кода на весь экран. ENTER — ввод, SETUP — создание (ввод + повтор + предложение биометрии),
 * CHANGE — сначала старый ПИН, потом новый. После 5 ошибок — пауза 30 секунд.
 */
@Composable
fun LockScreen(
    title: String, mode: LockMode, st: Store, act: FragmentActivity,
    onSuccess: () -> Unit, onCancel: () -> Unit
) {
    val c = LocalNt.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val bioOk = remember { bioAvailable(act) }
    // stage: 0 — ввод текущего, 1 — новый, 2 — повтор нового, 3 — предложение биометрии
    var stage by remember { mutableStateOf(if (mode == LockMode.SETUP) 1 else 0) }
    var pin by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf(if (mode == LockMode.SETUP) "Придумайте ПИН из 6 цифр" else "") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val shake = remember { Animatable(0f) }
    val locked = st.lockedUntil > now

    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(500) } }
    LaunchedEffect(stage) {
        if (stage == 0 && st.bio && bioOk && mode == LockMode.ENTER) bioPrompt(act, title) { onSuccess() }
    }

    suspend fun wrong(text: String) {
        msg = text
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        shake.animateTo(0f, keyframes {
            durationMillis = 360
            -18f at 50
            18f at 110
            -12f at 170
            12f at 230
            -6f at 290
        })
    }

    fun onDigit(d: String) {
        if (pin.length >= 6 || locked || stage == 3) return
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        pin += d
        if (pin.length < 6) return
        val entered = pin
        scope.launch {
            when (stage) {
                0 -> {
                    val ok = withContext(Dispatchers.Default) { st.checkPin(entered) }
                    if (ok) {
                        st.fails = 0
                        if (mode == LockMode.CHANGE) { stage = 1; pin = ""; msg = "Придумайте новый ПИН" } else onSuccess()
                    } else {
                        val f = st.fails + 1
                        if (f >= 5) { st.lockedUntil = System.currentTimeMillis() + 30_000L; st.fails = 0; now = System.currentTimeMillis() }
                        else st.fails = f
                        pin = ""
                        wrong(if (f >= 5) "Слишком много попыток" else "Неверный ПИН · осталось ${5 - f}")
                    }
                }
                1 -> { first = entered; pin = ""; stage = 2; msg = "Повторите ПИН" }
                2 -> if (entered == first) {
                    withContext(Dispatchers.Default) { st.setPin(entered) }
                    st.fails = 0
                    if (bioOk) { stage = 3; pin = "" } else onSuccess()
                } else {
                    pin = ""; stage = 1; first = ""
                    wrong("Не совпало. Придумайте ПИН заново")
                }
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(c.bg).pointerInput(Unit) { detectTapGestures { } }
    ) {
        IconButton(onCancel, Modifier.statusBarsPadding().padding(4.dp)) { Icon(Icons.Default.Close, null, tint = c.text) }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 32.dp),
            Arrangement.Center, Alignment.CenterHorizontally
        ) {
            RedDot(size = 10.dp)
            Spacer(Modifier.height(14.dp))
            DotText(if (stage == 3) "Биометрия" else title, size = 28.sp)
            Spacer(Modifier.height(8.dp))

            if (stage == 3) {
                Text(
                    "Открывать сейф отпечатком или лицом? ПИН-код останется запасным способом.",
                    color = c.dim, fontSize = 14.sp
                )
                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Pill("Включить", { st.bio = true; onSuccess() }, filled = true)
                    Pill("Позже", { onSuccess() })
                }
            } else {
                val shown = if (locked) "Подождите ${((st.lockedUntil - now) / 1000 + 1)} с" else msg
                Text(shown, color = if (locked || msg.startsWith("Неверный") || msg.startsWith("Не совп")) c.red else c.dim, fontSize = 13.sp, maxLines = 2)
                Spacer(Modifier.height(20.dp))
                Row(
                    Modifier.graphicsLayer { translationX = shake.value },
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    for (i in 0 until 6) {
                        Box(
                            Modifier.size(14.dp).clip(CircleShape).background(if (i < pin.length) c.red else c.line)
                        )
                    }
                }
                Spacer(Modifier.height(32.dp))
                val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
                Column(verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    rows.forEach { r ->
                        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) { r.forEach { d -> PadKey(d) { onDigit(d) } } }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (stage == 0 && st.bio && bioOk && mode == LockMode.ENTER)
                            Box(Modifier.size(76.dp).pressable { bioPrompt(act, title) { onSuccess() } }, Alignment.Center) { Cap("BIO", color = c.text, size = 13.sp) }
                        else Spacer(Modifier.size(76.dp))
                        PadKey("0") { onDigit("0") }
                        Box(Modifier.size(76.dp).pressable { if (pin.isNotEmpty()) pin = pin.dropLast(1) }, Alignment.Center) {
                            Icon(Icons.Default.Clear, null, tint = c.text, modifier = Modifier.size(26.dp))
                        }
                    }
                }
            }
        }
    }
}

/** Настройки защиты: ПИН, биометрия, замок на корзине. */
@Composable
fun SecurityDialog(
    st: Store, act: FragmentActivity, lockTrash: Boolean,
    onLockTrash: (Boolean) -> Unit, onPin: (LockMode) -> Unit, onClose: () -> Unit
) {
    val c = LocalNt.current
    val has = st.hasPin()
    val bioOk = remember { bioAvailable(act) }
    var bio by remember { mutableStateOf(st.bio) }

    AlertDialog(
        onDismissRequest = onClose, containerColor = c.surface, titleContentColor = c.text, textContentColor = c.text,
        confirmButton = { Pill("Готово", onClose, filled = true) },
        title = { DotText("Защита", size = 22.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Cap("ПИН-код")
                        Text(if (has) "Установлен" else "Не задан", color = c.text, fontSize = 14.sp)
                    }
                    Pill(if (has) "Сменить" else "Создать", { onPin(if (has) LockMode.CHANGE else LockMode.SETUP) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Cap("Биометрия")
                        Text(
                            if (!bioOk) "Нет на устройстве" else if (!has) "Сначала создайте ПИН" else "Отпечаток или лицо",
                            color = c.text, fontSize = 14.sp
                        )
                    }
                    Pill(if (bio) "Вкл" else "Выкл", { bio = !bio; st.bio = bio }, filled = bio, enabled = bioOk && has)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Cap("Замок на корзине")
                        Text(if (!has) "Сначала создайте ПИН" else "Спрашивать ПИН при входе", color = c.text, fontSize = 14.sp)
                    }
                    Pill(if (lockTrash) "Вкл" else "Выкл", { onLockTrash(!lockTrash) }, filled = lockTrash, enabled = has)
                }
                Text(
                    "Сейф шифрует файлы ключом из Android Keystore и убирает их из системной галереи. " +
                        "Если забудете ПИН, восстановить сейф нельзя.",
                    color = c.dim, fontSize = 12.sp
                )
            }
        }
    )
}
